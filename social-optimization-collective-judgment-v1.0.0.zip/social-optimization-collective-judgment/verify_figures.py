#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
verify_figures.py -- the reproducibility gate of this repository.

Rebuilds every workbook and every figure from source in a throwaway copy of the
repository and checks, without modifying anything, that

  (1) every data-driven figure of the book (listed in reference_figures/manifest.json)
      has a generator here;
  (2) re-running that generator reproduces the PDF printed in the book
      (reference_figures/<name>.pdf) exactly, comparing the decompressed PDF
      content streams so that embedded creation timestamps are ignored;
  (3) no generator, workbook, or rendered figure in this repository is an orphan.

The figures are rebuilt with drawing_code/run_all.py, which first rebuilds every
workbook from build_workbooks.py, so the workbooks themselves are verified as
reproducible.

    python verify_figures.py

Exit status is 0 only when every check passes.
"""
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zlib

HERE = os.path.dirname(os.path.abspath(__file__))
REF = os.path.join(HERE, "reference_figures")
DATA = os.path.join(HERE, "simulation_data")
OUT = os.path.join(HERE, "figures_out")
CODE = os.path.join(HERE, "drawing_code")


def pdf_streams_digest(path):
    """MD5 over the decompressed content streams -- ignores /CreationDate."""
    raw = open(path, "rb").read()
    h = hashlib.md5()
    i = 0
    while True:
        a = raw.find(b"stream", i)
        if a < 0:
            break
        a += 6
        if raw[a:a + 2] == b"\r\n":
            a += 2
        elif raw[a:a + 1] in (b"\n", b"\r"):
            a += 1
        b = raw.find(b"endstream", a)
        if b < 0:
            break
        chunk = raw[a:b]
        try:
            chunk = zlib.decompress(chunk)
        except zlib.error:
            pass
        h.update(chunk)
        i = b + 9
    return h.hexdigest()


def run(cmd, cwd, env=None):
    return subprocess.run(cmd, cwd=cwd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace",
                          env=env or dict(os.environ, MPLBACKEND="Agg",
                                          PYTHONIOENCODING="utf-8"))


def main():
    problems = []
    manifest = json.load(open(os.path.join(REF, "manifest.json"), encoding="utf-8"))
    figures = {m["file"]: m for m in manifest["figures"]}
    print("the book prints %d data-driven figures (reference_figures/manifest.json)" % len(figures))

    # --- 1. rebuild the workbooks and the data figures into a throwaway tree ---
    tmp = tempfile.mkdtemp(prefix="figverify_")
    try:
        sandbox = os.path.join(tmp, "repo")
        shutil.copytree(HERE, sandbox, ignore=shutil.ignore_patterns(
            "figures_out", "svg", "reference_figures", ".git", "__pycache__", "*.pyc"))
        # drop the shipped workbooks so the generator must rebuild every one
        for wb in os.listdir(os.path.join(sandbox, "simulation_data")):
            if wb.endswith(".xlsx"):
                os.remove(os.path.join(sandbox, "simulation_data", wb))
        os.makedirs(os.path.join(sandbox, "figures_out"), exist_ok=True)
        print("\nrebuilding workbooks and figures from scratch ...")
        r = run([sys.executable, "run_all.py"], os.path.join(sandbox, "drawing_code"))
        if r.returncode != 0:
            print(r.stdout[-3000:])
            print(r.stderr[-3000:])
            problems.append("run_all.py failed with exit %d" % r.returncode)
            fresh = OUT
        else:
            fresh = os.path.join(sandbox, "figures_out")
            print("   ok")

        generated = sorted(f[:-4] for f in os.listdir(fresh) if f.endswith(".pdf"))

        # --- 2. every printed figure must have a generator -----------------------
        print("\n-- printed figure -> generator --")
        for fig in sorted(figures, key=lambda f: figures[f]["order"]):
            if fig in generated:
                kind = "python"
            else:
                kind = "MISSING GENERATOR"
                problems.append("no generator for printed figure %s" % fig)
            if not os.path.exists(os.path.join(REF, fig + ".pdf")):
                problems.append("reference PDF missing for %s" % fig)
            print("   %-10s %-32s %s" % (figures[fig]["number"], fig, kind))

        # --- 3. reproduction: regenerated == printed ----------------------------
        print("\n-- reproduction check (python figures) --")
        for fig in generated:
            ref = os.path.join(REF, fig + ".pdf")
            if fig not in figures:
                print("   %-32s not printed in the book (orphan output)" % fig)
                problems.append("generated figure %s is not printed in the book" % fig)
                continue
            same = pdf_streams_digest(ref) == pdf_streams_digest(os.path.join(fresh, fig + ".pdf"))
            print("   %-32s %s" % (fig, "reproduces exactly" if same else "DIFFERS"))
            if not same:
                problems.append("regenerated %s does not match the printed figure" % fig)

        # --- 4. workbooks: rebuilt == shipped, and no orphans ---------------------
        print("\n-- workbook check --")
        code_text = "".join(
            open(os.path.join(CODE, f), encoding="utf-8", errors="replace").read()
            for f in os.listdir(CODE) if f.endswith(".py"))
        for wb in sorted(f for f in os.listdir(os.path.join(sandbox, "simulation_data")) if f.endswith(".xlsx")):
            used = wb in code_text
            role = "read by a figure script" if used else "table-only (no plot)"
            if not used and not wb.startswith("tab"):
                problems.append("workbook %s is neither read by a script nor a table" % wb)
                role = "ORPHAN"
            shipped = os.path.join(DATA, wb)
            if not os.path.exists(shipped):
                problems.append("rebuilt workbook %s is not shipped in simulation_data" % wb)
                role += ", NOT SHIPPED"
            print("   %-44s %s" % (wb, role))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    print("\n" + "=" * 66)
    if problems:
        print("FAILED -- %d problem(s):" % len(problems))
        for p in problems:
            print("  *", p)
        return 1
    print("PASSED -- every data-driven figure of the book has a generator here and reproduces exactly.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
