#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
fig6-12_hm_calsharp.py -- the diagnostic figure for the Section 6.6 exploratory
vignette on human-machine forecast aggregation. It places each forecaster on the
reliability-resolution plane: humans and calibrated machines cluster at low
reliability error, while the overconfident machines stand apart at high resolution
AND high reliability error (poor calibration) -- the central lesson that machine
confidence must not be mistaken for reliability.

All data are read from ../simulation_data/fig6-12_hm_calsharp.xlsx; nothing numeric
is hard-coded here. Since 2026-09-14 the workbook is GENERATED AND SOLVED by the
vignette block of build_workbooks.py (target series, eight forecasters, convex
CRPS program, leave-one-out re-solves, Hersbach split); the plotted columns
'resolution' (RES_i = UNC - POT_i) and 'reliability_error' (REL_i) of the
'forecasters' sheet are solved outputs, and the axis limits, the band and the
callout position in the config sheet are derived from them. The values are
ILLUSTRATIVE SYNTHETIC ones; the vignette reports no empirical magnitudes.

Note on terminology: the two channels of the CRPS decomposition are called
CALIBRATION and RESOLUTION throughout the book. The file name is legacy.

Output: ../figures_out/fig6-12_hm_calsharp.pdf  (copy into book/figures/)
Run: python fig6-12_hm_calsharp.py
"""
import numpy as np
from _common import PALETTE, save, load, config
import matplotlib.pyplot as plt

WB = "fig6-12_hm_calsharp.xlsx"
S = load(WB)
C = config(S)
SEED = int(C["seed"])

F = S["forecasters"]
# preserve workbook order of the groups
GROUP_ORDER = list(dict.fromkeys(F["group"].astype(str)))


def fig():
    fig, ax = plt.subplots(figsize=(7.0, 4.4))
    for name in GROUP_ORDER:
        sub = F[F["group"].astype(str) == name]
        col = PALETTE[str(sub["color"].iloc[0])]
        mk = str(sub["marker"].iloc[0])
        ax.scatter(list(sub["resolution"].astype(float)),
                   list(sub["reliability_error"].astype(float)),
                   c=col, marker=mk, s=70, edgecolor="white", lw=0.8,
                   label=name, zorder=3)
        # label each point by its id so the prose can refer to it
        for _, r in sub.iterrows():
            ax.annotate(str(r["id"]), (float(r["resolution"]), float(r["reliability_error"])),
                        xytext=(5, 3), textcoords="offset points", fontsize=7.5,
                        color=PALETTE["text"], zorder=4)
    # a guide: "well calibrated" region near the x-axis
    ax.axhspan(0, C["well_calibrated_cut"], color=PALETTE["band"], zorder=0)
    ax.text(C["band_label_x"], C["band_label_y"], C["band_label"],
            fontsize=8, color=PALETTE["text"])
    ax.annotate(C["callout_text"].replace("\\n", "\n"),
                xy=(C["callout_xy_x"], C["callout_xy_y"]),
                xytext=(C["callout_text_x"], C["callout_text_y"]),
                fontsize=8.5, color=PALETTE["text"], ha="center",
                arrowprops=dict(arrowstyle="->", color=PALETTE["red"], lw=1.0))
    ax.set_xlabel(C["x_label"])
    ax.set_ylabel(C["y_label"])
    ax.set_xlim(C["x_min"], C["x_max"]); ax.set_ylim(C["y_min"], C["y_max"])
    ax.legend(loc="upper left", fontsize=9)
    fig.tight_layout(); save(fig, "fig6-12_hm_calsharp")


if __name__ == "__main__":
    fig()
    n_h = int(C["n_human"]); n_m = int(C["n_machine"])
    print("saved fig6-12_hm_calsharp (seed %d, data %s); illustrative synthetic, "
          "no empirical magnitudes" % (SEED, WB))
    print("panel: %d human + %d machine forecasters over T=%d periods"
          % (n_h, n_m, int(C["horizon_T"])))
    for name in GROUP_ORDER:
        sub = F[F["group"].astype(str) == name]
        print("   %-24s n=%d  resolution %s  reliability error %s"
              % (name, len(sub),
                 [round(float(v), 3) for v in sub["resolution"]],
                 [round(float(v), 3) for v in sub["reliability_error"]]))
