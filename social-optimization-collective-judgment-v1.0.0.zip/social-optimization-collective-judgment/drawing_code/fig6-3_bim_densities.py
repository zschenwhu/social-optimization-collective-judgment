#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Figure 6.3 (fig:bim-densities): BIM-maturity expert and aggregate densities.
Data source: ../simulation_data/fig6-3_bim_densities.xlsx (the seven stated
experts and the two aggregates SOLVED by build_workbooks.py at delta = 0 and 0.5)"""
from _common import density_figure
density_figure("fig6-3_bim_densities.xlsx", "fig6-3_bim_densities")
