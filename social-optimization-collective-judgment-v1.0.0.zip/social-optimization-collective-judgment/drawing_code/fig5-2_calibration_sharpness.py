#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Figure 5.2 (fig:calsharp): calibration-sharpness profile of the synthetic
human-machine panel. Data source: ../simulation_data/fig5-2_calibration_sharpness.xlsx
(derived from the ex:hmpanel study of fig5-3_loo.xlsx; RES_i = UNC_grid - POT_i)"""
from _common import load, config, save, PALETTE, plt

s = load("fig5-2_calibration_sharpness.xlsx")
c = config(s)
pts = s["points"]

MARK = {"human experts": ("o", PALETTE["blue"], 6),
        "calibrated models": ("^", PALETTE["teal"], 8),
        "overconfident models": ("s", PALETTE["red"], 7)}

# annotation text is set in the neutral text gray; the marker colours alone
# carry the group coding, and the marker shapes repeat it for grayscale print
ANNOT_COL = {}

fig, ax = plt.subplots(figsize=(6.6, 4.4))
for grp, (mk, col, sz) in MARK.items():
    sub = pts[pts["group"] == grp]
    if grp == "calibrated models":
        # the three calibrated machines nearly coincide; keep the data
        # positions EXACT but draw open triangles of graded size so every
        # marker stays visible, and name the cluster with a leader line
        sizes = [12.5, 9.5, 6.5][:len(sub)]
        for k, (_, r) in enumerate(sub.iterrows()):
            ax.plot([r["RES"]], [r["REL"]], linestyle="none", marker=mk,
                    markersize=sizes[k], markerfacecolor="none",
                    markeredgecolor=col, markeredgewidth=1.4, alpha=0.95,
                    label=(grp if k == 0 else "_nolegend_"))
        cx = float(sub["RES"].mean())
        cy = float(sub["REL"].mean())
        ax.annotate("M1–M3\n(nearly coincident)",
                    xy=(cx, cy + 0.003), xytext=(cx - 0.004, cy + 0.040),
                    fontsize=8, color=PALETTE["text"], ha="left", va="center",
                    arrowprops=dict(arrowstyle="->", color=PALETTE["slate"], lw=0.9,
                                    shrinkA=2, shrinkB=2))
    else:
        ax.plot(sub["RES"], sub["REL"], linestyle="none", marker=mk, color=col,
                markersize=sz, markeredgecolor="white", markeredgewidth=0.6,
                label=grp)

for _, a in s["annotations"].iterrows():
    txt = str(a["text"]).replace("\\n", "\n")
    key = " ".join(str(a["text"]).replace("\\n", " ").lower().split())
    col = next((v for k, v in ANNOT_COL.items() if k in key), PALETTE["text"])
    ax.text(a["x"], a["y"], txt, fontsize=8,
            color=col, ha=str(a.get("ha", "center")), va="center")

ax.set_xlim(c["xmin"], c["xmax"]); ax.set_ylim(c["ymin"], c["ymax"])
ax.set_xlabel(c["x_label"]); ax.set_ylabel(c["y_label"])
ax.legend(loc="upper right", fontsize=9)
fig.tight_layout()
save(fig, "fig5-2_calibration_sharpness")
