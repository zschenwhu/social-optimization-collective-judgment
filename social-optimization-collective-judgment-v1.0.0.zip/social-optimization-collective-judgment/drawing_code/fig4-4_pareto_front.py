#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Figure 4.4 (fig:pareto): an illustrative non-convex Pareto front, its
convex-hull boundary, and an efficient point no weighted sum can reach.

Data source: ../data/fig4-4_pareto_front.xlsx, which stores only the curve.
The hull chord, the unsupported arc, and the marked point are DERIVED here, so
the figure cannot assert a geometry the curve does not have. The script asserts
the three properties the caption and Section 4.x claim:

  * the curve is strictly decreasing, hence every point on it is efficient;
  * part of it lies strictly below its least concave majorant, so those
    efficient points are unsupported;
  * the marked point is the deepest such point, and no weighted sum returns it.
"""
import numpy as np
from _common import load, config, save, PALETTE, plt

s = load("fig4-4_pareto_front.xlsx")
c = config(s)


def eval_piece(form, x):
    return eval(form, {"x": x, "pi": np.pi, "sin": np.sin, "sqrt": np.sqrt,
                       "clip": np.clip, "max": np.maximum})


def upper_hull(px, py):
    """Least concave majorant of the sampled front, as a list of vertices."""
    h = []
    for xi, yi in zip(px, py):
        while len(h) >= 2:
            (x1, y1), (x2, y2) = h[-2], h[-1]
            if (x2 - x1) * (yi - y1) - (y2 - y1) * (xi - x1) >= 0:
                h.pop()
            else:
                break
        h.append((xi, yi))
    return h


# ------------------------------------------------------------------ the front --
pieces = s["front_pieces"]
n = int(c["grid_points"])
x = np.concatenate([np.linspace(r["x_min"], r["x_max"], n) for _, r in pieces.iterrows()])
y = np.concatenate([eval_piece(r["form"], np.linspace(r["x_min"], r["x_max"], n))
                    for _, r in pieces.iterrows()])
order = np.argsort(x, kind="stable")
x, y = x[order], y[order]

# A front must be strictly decreasing; otherwise a plotted point would dominate
# another and the curve would not be a Pareto front at all.
assert np.all(np.diff(y) < 0), "the plotted curve is not strictly decreasing"

# -------------------------------------------------- hull, arc, marked point --
hull = upper_hull(x, y)
hx = np.array([p[0] for p in hull])
hy = np.array([p[1] for p in hull])
gap = np.interp(x, hx, hy) - y
unsupported = gap > 1e-9
assert unsupported.any(), "the front is concave everywhere: nothing is unsupported"

seg = int(np.argmax(np.diff(hx)))          # the single chord that skips the dip
chord_x = [hx[seg], hx[seg + 1]]
chord_y = [hy[seg], hy[seg + 1]]

k = int(np.argmax(gap))                     # deepest departure from the hull
mx, my = float(x[k]), float(y[k])

# ------------------------------------------------------------------- drawing --
fig, ax = plt.subplots(figsize=(6.4, 4.4))
ax.fill_between(x, 0, y, color=PALETTE["gray_l"], alpha=0.45, zorder=0)
ax.plot(x, y, color=PALETTE["ink"], lw=2.6, label=c["front_legend"], zorder=3)
ax.plot(x[unsupported], y[unsupported], color=PALETTE["blue"], lw=3.2,
        solid_capstyle="round", label=c["arc_legend"], zorder=4)
ax.plot(chord_x, chord_y, color=PALETTE["slate"], lw=2.2, ls="--",
        label=c["hull_legend"], zorder=5)
ax.plot([mx], [my], "o", color=PALETTE["red"], ms=6,
        markeredgecolor="white", markeredgewidth=0.6, zorder=6)
# placed into the empty interior of the feasible region, with a leader, so the
# text crosses neither the front, the unsupported arc, nor the hull chord
ax.annotate(str(c["marked_label"]), (mx, my), xytext=(mx - 0.42, my - 0.17),
            fontsize=8, color=PALETTE["text"], ha="left", va="center", zorder=6,
            arrowprops=dict(arrowstyle="->", color=PALETTE["red"], lw=0.9,
                            shrinkA=2, shrinkB=4))

ax.set_xlim(0, 1.08); ax.set_ylim(0, 1.18)
ax.set_xticks([]); ax.set_yticks([])
ax.set_xlabel(c["x_label"]); ax.set_ylabel(c["y_label"])
ax.legend(loc="upper right", fontsize=9)
fig.tight_layout()
save(fig, "fig4-4_pareto_front")

if __name__ == "__main__":
    lo, hi = float(x[unsupported].min()), float(x[unsupported].max())
    print("front: strictly decreasing, %d sample points, y(0)=%.3f y(1)=%.3f"
          % (len(x), y[0], y[-1]))
    print("hull chord (double tangent): (%.4f, %.4f) -> (%.4f, %.4f)"
          % (chord_x[0], chord_y[0], chord_x[1], chord_y[1]))
    print("unsupported arc: f1 in [%.4f, %.4f]  (%.1f%% of the front)"
          % (lo, hi, 100.0 * unsupported.mean()))
    print("marked point: (%.4f, %.4f), %.4f below the hull" % (mx, my, gap[k]))
    # the two claims the surrounding prose makes about this point
    reach = {round(float(x[int(np.argmax(lam * x + (1 - lam) * y))]), 4)
             for lam in np.linspace(0, 1, 2001)}
    print("weighted sum never returns it:", not any(abs(v - mx) < 1e-3 for v in reach))
    print("epsilon-constraint (max f1 s.t. f2 >= %.4f) returns f1 = %.4f"
          % (my, float(x[y >= my - 1e-12].max())))
