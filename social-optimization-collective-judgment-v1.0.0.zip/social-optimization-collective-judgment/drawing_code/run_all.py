#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""run_all.py -- rebuild every data workbook, then regenerate every figure.

    python run_all.py

Rebuilds ../simulation_data/*.xlsx and case_manifest.json, then writes
../figures_out/*.png (+ .pdf) and ../svg/*.svg.
"""
import glob
import os
import runpy

HERE = os.path.dirname(os.path.abspath(__file__))
SIM = os.path.normpath(os.path.join(HERE, "..", "simulation_data"))

print("== building data workbooks ==")
runpy.run_path(os.path.join(SIM, "build_workbooks.py"), run_name="__main__")
runpy.run_path(os.path.join(SIM, "gen_case_manifest.py"), run_name="__main__")

print("\n== rendering figures ==")
for f in sorted(glob.glob(os.path.join(HERE, "fig*.py"))):
    print("--", os.path.basename(f))
    runpy.run_path(f, run_name="__main__")

print("\nDone. See ../figures_out/")
