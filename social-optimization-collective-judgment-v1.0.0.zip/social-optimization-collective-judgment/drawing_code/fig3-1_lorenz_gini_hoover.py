#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Figure 3.1 (fig:lorenz): the Gini area and Hoover index on an illustrative
Lorenz curve. Data source: ../data/fig3-1_lorenz_gini_hoover.xlsx"""
import numpy as np
from _common import load, config, save, PALETTE, plt

s = load("fig3-1_lorenz_gini_hoover.xlsx")
c = config(s)
n = int(c.get("lorenz_exponent", 2))
hx = float(c.get("hoover_x", 0.5))

x = np.linspace(0, 1, 200)
equality = x
lorenz = x ** n

fig, ax = plt.subplots(figsize=(5.2, 5.2))
ax.plot(x, equality, color=PALETTE["slate"], lw=1.8, label="line of equality")
ax.plot(x, lorenz, color=PALETTE["ink"], lw=2.4, ls="--", label="Lorenz curve")
ax.fill_between(x, lorenz, equality, color=PALETTE["gray_l"], alpha=0.60, lw=0)

# Hoover index = maximum vertical gap (drawn at hx), the one accented element
ax.annotate("", xy=(hx, hx), xytext=(hx, hx ** n),
            arrowprops=dict(arrowstyle="<->", color=PALETTE["red"], lw=1.8))

for _, a in s["annotations"].iterrows():
    is_hoover = str(a["text"]).startswith("Hoover")
    # nudge the Hoover label clear of its double-headed arrow (style only;
    # the workbook stores the anchor, the offset separates text from arrowheads)
    dx = 0.035 if is_hoover else 0.0
    ax.text(float(a["x"]) + dx, a["y"], str(a["text"]), fontsize=9,
            color=PALETTE["text"] if is_hoover else PALETTE["slate"],
            ha="left" if is_hoover else "center",
            va="center")

ax.set_xlim(0, 1); ax.set_ylim(0, 1)
ax.set_xticks([0, 0.5, 1]); ax.set_yticks([0, 0.5, 1])
ax.set_xlabel(c["x_label"]); ax.set_ylabel(c["y_label"])
ax.legend(loc="upper left", fontsize=9)
ax.set_aspect("equal")
fig.tight_layout()
save(fig, "fig3-1_lorenz_gini_hoover")
