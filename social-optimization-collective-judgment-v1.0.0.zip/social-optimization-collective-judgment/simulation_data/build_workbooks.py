#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
build_workbooks.py
==================
Creates every Excel data file in this folder (simulation_data/) that backs the
reproducible figures and the synthetic-data tables of the monograph
"The Social Optimization of Collective Judgment" (Chen & Wang).

Each workbook is the *authoritative data source* for one figure or one table.
The matching plotting script in drawing_code/ (same base name) reads only the
Excel file -- never hard-coded numbers -- so the figures are guaranteed to be
generated from the tabulated data.

Run once:  python build_workbooks.py
Output:    ./*.xlsx (this folder; the drawing scripts read ../simulation_data/)
"""
import os
import math
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = HERE   # the workbooks are written beside this generator, in simulation_data/
os.makedirs(DATA, exist_ok=True)


def cfg(d):
    return pd.DataFrame(list(d.items()), columns=["key", "value"])


# every workbook must carry a config/provenance sheet naming its generator,
# its seed (or the explicit statement that no draws are involved), and the
# synthetic flag; write() injects the missing keys so no workbook can ship
# without them (traceability rule 12).
_PROV_DEFAULTS = {
    "generator": "build_workbooks.py (the block that writes this workbook)",
    "seed": "none -- fixed illustrative parameters, no random draws",
    "synthetic": 1,
}


def write(name, sheets):
    """sheets: dict of sheet_name -> DataFrame (or list-of-dicts)."""
    sheets = dict(sheets)
    if "config" in sheets:
        c = sheets["config"]
        have = set(c["key"].astype(str))
        missing = {k: v for k, v in _PROV_DEFAULTS.items() if k not in have}
        if missing:
            sheets["config"] = pd.concat([c, cfg(missing)], ignore_index=True)
    elif "provenance" in sheets:
        # table-only workbooks that state their own provenance: inject only
        # the missing mandatory keys
        c = sheets["provenance"]
        have = set(c["key"].astype(str))
        missing = {k: v for k, v in dict(_PROV_DEFAULTS, workbook=name).items() if k not in have}
        if missing:
            sheets["provenance"] = pd.concat([c, cfg(missing)], ignore_index=True)
    else:
        # table-only workbooks: add a dedicated provenance sheet
        sheets["provenance"] = cfg(dict(_PROV_DEFAULTS, workbook=name))
    path = os.path.join(DATA, name)
    with pd.ExcelWriter(path, engine="openpyxl") as xl:
        for sheet, obj in sheets.items():
            df = obj if isinstance(obj, pd.DataFrame) else pd.DataFrame(obj)
            df.to_excel(xl, sheet_name=sheet, index=False)
        xl.book.properties.created = _FIXED_STAMP
    _fix_zip_stamps(path)
    print("wrote", os.path.relpath(path, HERE))


# openpyxl stamps the wall clock into docProps/core.xml (dcterms:modified is
# overwritten at save time) and into every zip entry header, so two builds of
# identical cell content are not byte-identical.  The post-pass below rewrites
# the archive with one fixed entry time and sets 'modified' equal to the fixed
# 'created' stamp, so that a rebuild from the same seed reproduces every
# workbook byte for byte (traceability rule 12; content is unchanged).
import datetime as _wb_datetime
import re as _wb_re
import zipfile as _wb_zipfile

_FIXED_STAMP = _wb_datetime.datetime(2026, 1, 1, 0, 0, 0)


def _fix_zip_stamps(path):
    with _wb_zipfile.ZipFile(path) as zin:
        entries = [(info, zin.read(info.filename)) for info in zin.infolist()]
    tmp = path + ".tmp"
    with _wb_zipfile.ZipFile(tmp, "w", compression=_wb_zipfile.ZIP_DEFLATED) as zout:
        for info, data in entries:
            if info.filename == "docProps/core.xml":
                data = _wb_re.sub(rb"(<dcterms:modified[^>]*>)[^<]*",
                               lambda m: m.group(1) + _FIXED_STAMP.strftime("%Y-%m-%dT%H:%M:%SZ").encode(),
                               data)
            new = _wb_zipfile.ZipInfo(info.filename, date_time=_FIXED_STAMP.timetuple()[:6])
            new.compress_type = _wb_zipfile.ZIP_DEFLATED
            new.external_attr = info.external_attr
            zout.writestr(new, data)
    os.replace(tmp, path)


# =====================================================================
# FIGURE 3.1  Lorenz curve with Gini area and Hoover index (illustrative)
# =====================================================================
write("fig3-1_lorenz_gini_hoover.xlsx", {
    "config": cfg({
        "figure": "3.1", "label": "fig:lorenz",
        "x_label": "cumulative share of experts",
        "y_label": "cumulative share of fairness utility",
        "lorenz_exponent": 2,   # illustrative Lorenz curve y = x^2
        "hoover_x": 0.5,        # max vertical gap location
        "title": "Gini coefficient and Hoover index on the Lorenz curve",
    }),
    "annotations": [
        {"text": "Hoover", "x": 0.52, "y": 0.375},
        # must sit INSIDE the tint, which at x=0.74 spans y in [0.74^2, 0.74]
        # = [0.5476, 0.7400]; 0.644 is that band's midpoint.
        {"text": "Gini area", "x": 0.74, "y": 0.644},
    ],
})

# =====================================================================
# FIGURE 4.2  Pareto front with a concave indentation (illustrative)
#   Stored as the three piecewise pieces + the weighted-sum chord + point.
# =====================================================================
write("fig4-4_pareto_front.xlsx", {
    "config": cfg({
        "figure": "4.4", "label": "fig:pareto",
        "x_label": "objective f1 (e.g. consensus)",
        "y_label": "objective f2 (e.g. fairness)",
        "title": "Weighted-sum scalarization and a non-convex Pareto front",
        "grid_points": 2001,
        "marked_label": "unsupported: no weighting reaches it",
        "front_legend": "Pareto front",
        "arc_legend": "unsupported arc",
        "hull_legend": "convex-hull boundary",
    }),
    # A concave, strictly decreasing base with a smooth dip cut out of its
    # middle. Strict decrease makes every point of the curve efficient (nothing
    # on it dominates anything else); the dip makes the middle stretch fall
    # below the least concave majorant, so those efficient points are
    # UNSUPPORTED -- reachable by the epsilon-constraint and weighted Tchebycheff
    # methods but by no weighted sum. The dip amplitude 0.10 over a width of
    # 0.40 keeps |dip'| < |base'| everywhere, which is what preserves strict
    # monotonicity; a deeper or narrower dip would make the curve turn upward
    # and stop being a front at all.
    "front_pieces": [
        {"piece": 1, "x_min": 0.00, "x_max": 1.00,
         "form": "1.0 - 0.9*x - 0.1*x**2 - 0.10*sin(pi*clip((x-0.35)/0.40, 0.0, 1.0))**2"},
    ],
    # The hull chord (its two tangency points), the unsupported arc, and the
    # marked point are all DERIVED by the plotting script from this curve, so
    # they cannot contradict it. See fig4-4_pareto_front.py.
})

# =====================================================================
# FIGURE 5.2  Calibration-sharpness profile of a mixed panel (fig:calsharp)
#   The workbook is written FURTHER DOWN, right after the fig5-3_loo
#   study: since 2026-08-28 its per-expert REL_i / RES_i values are
#   DERIVED from the same generated ex:hmpanel panel (the 'individual'
#   Hersbach split), so Figures 5.2 and 5.3 are two views of one
#   dataset and cannot drift apart.
# =====================================================================

# =====================================================================
# FIGURES 6.3 and 6.4 and TABLE 6.9 (Case I fairness panel) are SOLVED,
# not typed: see the block "CASE STUDY I, FAIRNESS PANEL" further down,
# after the shared numerical helpers, which writes fig6-3_bim_densities.xlsx,
# fig6-4_bim_tradeoff.xlsx, and tab6-9_bim_results.xlsx from the solve of
# eq:bim-triobjective.
# =====================================================================

# =====================================================================
# CASE STUDY I, FULL ASSESSMENT (Section 6.2, BIM maturity)
#   -> Figure fig6-1_bim_groupagg  (fig:bim-groupagg)
#   -> Figure fig6-2_bim_dimensions (fig:bim-dimensions)
#   -> Table  tab:bim-elicit (the elicited q_4 profile and its Gaussian fit)
#   -> Table  tab:bim-dimensions (the three dimensions and the global row)
# One workbook backs the whole case, because the two figures and the tables
# are views of a single synthetic dataset and must never drift apart.
#
# WHAT IS STATED AND WHAT IS COMPUTED (audit R19, BIM-05/06).  The full
# assessment is worked at the group and dimension level.  Its stated design
# inputs, fixed illustrative constants that no code derives, are
#   * the three group opinions on q4 (normal) and the credibility weights
#     Omega (the k-means clustering, the TOPSIS closeness and the twenty
#     experts' indicator profiles behind them are not part of the pack),
#   * the three dimension distributions and the best-worst dimension
#     weights (the indicator layer and the BWM comparison vectors behind
#     them are not part of the pack),
#   * one expert's elicited probability profile over the ten levels.
# From these the block COMPUTES (sheet 'derived')
#   * the q4 collective, the quantile average of the three group opinions
#     under Omega, N(Omega.mu, (Omega.sigma)^2) by Prop. qa-properties(iii),
#   * the global maturity, the quantile average of the three dimensions
#     under the dimension weights,
#   * the tab:bim-elicit fit, a normal matched to the first two moments of
#     the profile at the band midpoints (level_mid).
# No random draws are involved anywhere in the full assessment; the seed
# is recorded because the pack-wide seed 202603 fixes the starting points
# of the fairness-panel solve (fig6-4 block), not because anything here
# is drawn.
# =====================================================================
_c1_groups = [
    {"group": "G1 (junior)",     "legend": "G1 (junior)",     "mu": 4.3, "sigma": 1.3, "Omega": 0.24},
    {"group": "G2 (mid-career)", "legend": "G2 (mid-career)", "mu": 4.7, "sigma": 1.1, "Omega": 0.35},
    {"group": "G3 (senior)",     "legend": "G3 (senior)",     "mu": 5.4, "sigma": 1.0, "Omega": 0.41},
]
_c1_dims = [
    {"dimension": "Technology",   "mu": 4.80, "sigma": 1.20, "weight": 0.42, "color": "blue"},
    {"dimension": "Organization", "mu": 5.70, "sigma": 1.00, "weight": 0.33, "color": "green"},
    {"dimension": "Policy",       "mu": 5.45, "sigma": 1.10, "weight": 0.25, "color": "amber"},
]
_c1_elicit = [
    {"level": 1,  "level_mid": 0.5, "probability": 0.005},
    {"level": 2,  "level_mid": 1.5, "probability": 0.03},
    {"level": 3,  "level_mid": 2.5, "probability": 0.08},
    {"level": 4,  "level_mid": 3.5, "probability": 0.18},
    {"level": 5,  "level_mid": 4.5, "probability": 0.27},
    {"level": 6,  "level_mid": 5.5, "probability": 0.22},
    {"level": 7,  "level_mid": 6.5, "probability": 0.12},
    {"level": 8,  "level_mid": 7.5, "probability": 0.06},
    {"level": 9,  "level_mid": 8.5, "probability": 0.03},
    {"level": 10, "level_mid": 9.5, "probability": 0.005},
]


def _qa_normal(rows, wkey):
    """Quantile average of normal rows under the weights in rows[wkey]:
    mean = sum w mu, sd = sum w sigma (Prop. qa-properties(iii))."""
    wsum = sum(r[wkey] for r in rows)
    mu = sum(r[wkey] * r["mu"] for r in rows) / wsum
    sd = sum(r[wkey] * r["sigma"] for r in rows) / wsum
    return mu, sd


_c1_q4_mu, _c1_q4_sd = _qa_normal(_c1_groups, "Omega")
_c1_glob_mu, _c1_glob_sd = _qa_normal(_c1_dims, "weight")
_c1_psum = sum(r["probability"] for r in _c1_elicit)
_c1_fit_mu = sum(r["probability"] * r["level_mid"] for r in _c1_elicit) / _c1_psum
_c1_fit_sd = math.sqrt(sum(r["probability"] * (r["level_mid"] - _c1_fit_mu) ** 2
                           for r in _c1_elicit) / _c1_psum)


def _c1_printed(mu, sd):
    """N(mu, sd^2) rounded half-up to two decimals, as the book prints."""
    from decimal import Decimal, ROUND_HALF_UP
    r = lambda v: Decimal(repr(round(v, 9))).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return "N(%s, %s^2)" % (r(mu), r(sd))


print("\n-- Case I full assessment (stated inputs -> computed quantile averages)")
print("   q4 collective   N(%.4f, %.4f^2)   = QA of the three group opinions under Omega" % (_c1_q4_mu, _c1_q4_sd))
print("   global maturity N(%.4f, %.4f^2)   = QA of the three dimensions under the BWM weights" % (_c1_glob_mu, _c1_glob_sd))
print("   tab:bim-elicit  N(%.4f, %.4f^2)   = moment match of the q4 profile at band midpoints" % (_c1_fit_mu, _c1_fit_sd))

write("fig6-1_bim_case.xlsx", {
    "config": cfg({
        "case": "I -- BIM maturity assessment (Section 6.2)",
        "figures": "fig6-1_bim_groupagg, fig6-2_bim_dimensions",
        "labels": "fig:bim-groupagg, fig:bim-dimensions",
        "tables": "tab:bim-elicit (elicitation_q4 + derived), tab:bim-dimensions (dimensions + derived)",
        "source_paper": "chen2023bimdc",
        "synthetic": 1,
        "seed": 202603,
        "draws": "none -- the full assessment involves no random draws; every row of groups, dimensions and elicitation_q4 is a stated design input, and the seed is the pack-wide seed that fixes only the multi-start of the fairness-panel solve (fig6-4_bim_tradeoff.xlsx)",
        "stated_inputs": "group opinions on q4 and Omega (groups sheet), dimension distributions and BWM dimension weights (dimensions sheet), one elicited profile (elicitation_q4 sheet)",
        "computed_here": "derived sheet: q4 collective = QA of the group opinions under Omega, global maturity = QA of the dimensions under the BWM weights (Prop. qa-properties(iii)), tab:bim-elicit fit = moment matching at band midpoints",
        "not_in_pack": "the twenty experts' indicator distributions, the k-means clustering, the TOPSIS closeness behind Omega, the indicator layer behind the dimension distributions, and the BWM comparison vectors behind the weights (described in the text, not generated)",
        "n_experts": 20,
        "n_experts_note": "a label of the case description (three groups of 6/7/7); the panel is worked at the group and dimension level and no individual expert is generated",
        "scale_min": 0.0, "scale_max": 10.0, "n_levels": 10,
        "indicator": "q4 -- Real-time Data (a technology indicator)",
        "x_label_groupagg": "maturity level, Real-time Data indicator ($q_4$)",
        "x_label_dimensions": "BIM maturity level",
        "y_label": "probability density",
        # the two level borders drawn on the dimension figure
        "band_lo": 5.0, "band_hi": 6.0, "band_name": "Defined",
        "grid_points": 700,
        "fit_rule": "moment matching at band midpoints: mu = sum p_l m_l, sigma^2 = sum p_l (m_l - mu)^2 with m_l = l - 0.5",
    }),
    # STATED INPUT: three expert groups (the k-means partition is described,
    # not run) with their group opinions on q4 and the credibility weights.
    "groups": _c1_groups,
    # STATED INPUT: dimension-level distributions standing for the BWM-weighted
    # QA of each dimension's indicators, and the BWM dimension weights.
    "dimensions": _c1_dims,
    # STATED INPUT: one expert's elicited probability profile over the ten
    # maturity levels for q4 (tab:bim-elicit).
    "elicitation_q4": _c1_elicit,
    # COMPUTED: the two quantile averages and the elicitation fit.  The
    # 'printed' column rounds half-up to the two decimals the book prints
    # (the fit mean is exactly 967/200 = 4.835, printed 4.84).
    "derived": [
        {"quantity": "q4 collective (inter-group QA under Omega)", "mu": _c1_q4_mu, "sigma": _c1_q4_sd,
         "printed": _c1_printed(_c1_q4_mu, _c1_q4_sd),
         "rule": "mu = sum Omega_k mu_k, sigma = sum Omega_k sigma_k", "shown_in": "Figure 6.1, text sec:bim-elicit"},
        {"quantity": "global maturity (QA of dimensions under BWM weights)", "mu": _c1_glob_mu, "sigma": _c1_glob_sd,
         "printed": _c1_printed(_c1_glob_mu, _c1_glob_sd),
         "rule": "mu = sum w_d mu_d, sigma = sum w_d sigma_d", "shown_in": "Figure 6.2, Table 6.8 global row"},
        {"quantity": "tab:bim-elicit normal fit of the q4 profile", "mu": _c1_fit_mu, "sigma": _c1_fit_sd,
         "printed": _c1_printed(_c1_fit_mu, _c1_fit_sd),
         "rule": "moment matching at band midpoints", "shown_in": "Table 6.6 caption, text sec:bim-elicit"},
    ],
})

# =====================================================================
# CASE STUDY II (Section 6.3, digital-transformation barriers in SMCEs)
#   -> Figure fig6-5_dt_ranking14 (fig:dt-ranking14)
#   -> Figure fig6-6_dt_crossswf  (fig:dt-crossswf)
#   -> Figure fig6-7_dt_triad     (fig:dt-triad)
#   -> Table  tab:dt-swf-results, tab:dt-elicit
# GENERATED AND SOLVED HERE (since 2026-09-14).  A 30 x 14 panel of
# truncated-Weibull experts is generated under seed 202603 by the design
# chapter6.tex states (target importances calibrated to stated design
# means, leniency, background bias, noise, five-level profile, grouped-MLE
# Weibull fit), and the welfare-confidence program eq:dt-welfare-conf is
# solved 70 times (14 barriers x 5 equity indices) by multi-start SLSQP:
#     max_w  W~_s(w) - V~(w)   on the simplex,
#     W_s(w) = Ubar(w) (1 - I_s(U(w)))   (Sen's abbreviated welfare form on
#     the exp-normalized Fehr-Schmidt utilities of the overlaps, eq:exp-norm),
#     V(w) = variance of the quantile-averaged aggregate,
#     ~ = min-max normalization over the simplex (bounds solved).
# Every printed number of the case (tab:dt-swf-results, the ranking, the
# triad, the spreads, tab:dt-elicit's fit) is read from this workbook.
# =====================================================================
import math
import time
import numpy as np
from scipy.optimize import minimize as _sp_minimize

print("\n-- generating and solving Case II (fig6-5_dt_case.xlsx) ...")
_dt_t0 = time.time()

DT_SEED = 202603
DT_N, DT_M = 30, 14
DT_HI = 5.0                     # importance domain [0, 5], five unit bands
DT_RHO, DT_THETA = 0.4, 0.2     # Fehr-Schmidt jealousy / sympathy (Case I values)
DT_LENIENCY_SD = 0.15           # a_i ~ N(0, 0.15^2)
DT_NOISE_SD = 0.25              # eps_ik ~ N(0, 0.25^2)
DT_BIAS = 0.30                  # background bias on the expert's own TOE domain
DT_PROFILE_SD = 0.9             # Gaussian kernel sd of the five-level profile
DT_CALIB_TOL = 2e-4             # |equal-weight QA mean - design mean| target
DT_CALIB_MAXIT = 10
DT_PGRID = 2000                 # midpoint probability grid for quantile averaging
DT_XBINS = 600                  # x bins on [0, 5] for the overlaps
DT_STARTS_BOUNDS = 6            # Dirichlet(1) starts (plus barycentre) for W_min, W_max
DT_STARTS_PROGRAM = 12          # Dirichlet(1) starts (plus barycentre) for the program
DT_FTOL, DT_MAXITER, DT_FDH = 1e-10, 400, 1e-7
DT_ACTIVE_TOL = 1e-4            # w_i > tol counts as an active expert
DT_BOUND_REFINE_MAX = 4         # max refinements of a welfare bound from the program solution
DT_BOUND_TOL = 1e-9             # tolerance for W(w*) within [W_min, W_max]
DT_TRIAD_EQ = "EQ4"             # objective whose collective densities Figure 6.7 shows
_dt_pg = (np.arange(DT_PGRID) + 0.5) / DT_PGRID
_dt_xg = np.linspace(0.0, DT_HI, DT_XBINS + 1)

# the 14 barriers (tab:dt-barriers) and the design mean of each: the value
# the equal-weight quantile-averaged mean of the generated panel is
# calibrated to, chosen so that B14, B6, B1 lead and B9, B13, B11 trail
_DT_BARRIERS = [
    ("B1",  "Inadequate infrastructure",        "T", 3.86),
    ("B2",  "Poor system integration",          "T", 3.02),
    ("B3",  "Low level of digital technology",  "T", 3.13),
    ("B4",  "Data security risks",              "T", 3.56),
    ("B5",  "Insufficient funding",             "O", 3.67),
    ("B6",  "Lack of strategic planning",       "O", 4.00),
    ("B7",  "Lack of leadership support",       "O", 3.73),
    ("B8",  "Lack of skilled employees",        "O", 3.43),
    ("B9",  "Difficulty in technical training", "O", 2.29),
    ("B10", "Employee resistance",              "O", 3.79),
    ("B11", "Industry resistance",              "E", 2.83),
    ("B12", "Customer diversity",               "E", 3.29),
    ("B13", "Limited financial support",        "E", 2.56),
    ("B14", "Lack of standards & regulations",  "E", 4.10),
]
_DT_IDS = [b[0] for b in _DT_BARRIERS]
_DT_DIM = [b[2] for b in _DT_BARRIERS]
_DT_DESIGN = np.array([b[3] for b in _DT_BARRIERS])
_DT_EQ = ["EQ1", "EQ2", "EQ3", "EQ4", "EQ5"]
# experts 1-15 technologists (bias on the technological barriers B1-B4),
# 16-30 managers (bias on the organizational barriers B5-B10)
_DT_BACKGROUND = ["technologist"] * 15 + ["manager"] * 15
_DT_BG_DOMAIN = {"technologist": "T", "manager": "O"}
# the illustrative elicited profile of tab:dt-elicit (an input the book states)
_DT_B1_PROFILE = [0.01, 0.04, 0.13, 0.40, 0.42]


# ------------------------------------------------ truncated Weibull (eq:dt-weibull-trunc)
def _dt_wb_H(x, k, lam):
    return 1.0 - np.exp(-(np.clip(np.asarray(x, float), 0.0, None) / lam) ** k)


def _dt_trunc_quantile(p, k, lam):
    """Inverse of H(x)/H(5) on (0,1): x = lam (-ln(1 - p H(5)))^(1/k)."""
    return lam * (-np.log(1.0 - p * _dt_wb_H(DT_HI, k, lam))) ** (1.0 / k)


def _dt_trunc_cdf(x, k, lam):
    return np.clip(_dt_wb_H(x, k, lam) / _dt_wb_H(DT_HI, k, lam), 0.0, 1.0)


def _dt_fit_trunc_weibull(prob):
    """Grouped maximum likelihood of the truncated Weibull on the five unit
    bands l_t = [t-1, t):  max_{k,lam} sum_t p_t log([H(t)-H(t-1)] / H(5)).
    Nine starts, L-BFGS-B in log-parameters, best kept.
    Returns (kappa, lambda, mean of the fitted truncated Weibull, H(5))."""
    prob = np.asarray(prob, float)
    edges = np.arange(0.0, DT_HI + 1.0)

    def nll(th):
        k, lam = np.exp(th)
        H = _dt_wb_H(edges, k, lam)
        with np.errstate(divide="ignore", invalid="ignore"):
            q = np.clip(np.diff(H) / H[-1], 1e-300, None)
        return -float(np.dot(prob, np.nan_to_num(np.log(q), nan=-700.0)))

    best = None
    for k0 in (1.5, 3.0, 6.0):
        for l0 in (2.0, 3.5, 4.5):
            r = _sp_minimize(nll, np.log([k0, l0]), method="L-BFGS-B",
                             bounds=[(np.log(0.3), np.log(60.0)), (np.log(0.2), np.log(40.0))])
            if best is None or r.fun < best.fun:
                best = r
    k, lam = np.exp(best.x)
    mean = float(np.mean(_dt_trunc_quantile(_dt_pg, k, lam)))
    return float(k), float(lam), mean, float(_dt_wb_H(DT_HI, k, lam))


def _dt_profile(rating):
    """Five-level probability vector concentrated around the rating:
    p_t proportional to exp(-(m_t - r)^2 / (2 sd^2)), m_t = t - 1/2."""
    mids = np.arange(5) + 0.5
    p = np.exp(-(mids[None, :] - np.asarray(rating, float)[:, None]) ** 2 / (2.0 * DT_PROFILE_SD ** 2))
    return p / p.sum(axis=1, keepdims=True)


# ------------------------------------------------------------ the panel of one barrier
class _DtPanel:
    """N truncated-Weibull experts; quantile averaging on the p grid
    (def:qa), overlaps as shared bin mass on the x grid (def:consensus),
    aggregate variance as a quadratic form (def:confidence)."""

    def __init__(self, ks, lams):
        self.k = np.asarray(ks, float)
        self.lam = np.asarray(lams, float)
        self.N = self.k.size
        self.Qi = np.vstack([_dt_trunc_quantile(_dt_pg, k, l) for k, l in zip(self.k, self.lam)])
        self.mu_i = self.Qi.mean(axis=1)
        Fi = np.vstack([_dt_trunc_cdf(_dt_xg, k, l) for k, l in zip(self.k, self.lam)])
        self.dFi = np.diff(Fi, axis=1)                       # N x X bin masses
        Qc = self.Qi - self.mu_i[:, None]
        self.Sig = Qc @ Qc.T / DT_PGRID                      # V(w) = w' Sig w
        self.Vi = np.diag(self.Sig).copy()

    def quantile(self, w):
        return np.asarray(w, float) @ self.Qi

    def overlaps(self, W):
        """Batched overlaps A (B x N): F_QA is the inverse of the aggregate
        quantile table; A_i = sum over bins of min{dF_QA, dF_i}."""
        W = np.atleast_2d(W)
        Q = W @ self.Qi
        F = np.empty((W.shape[0], _dt_xg.size))
        for b in range(W.shape[0]):
            F[b] = np.interp(_dt_xg, Q[b], _dt_pg, left=0.0, right=1.0)
        F[:, 0] = 0.0
        F[:, -1] = 1.0
        dF = np.diff(F, axis=1)
        return np.minimum(dF[:, None, :], self.dFi[None, :, :]).sum(axis=2)

    def var(self, W):
        W = np.atleast_2d(W)
        return np.einsum("bi,ij,bj->b", W, self.Sig, W)

    def mean(self, w):
        return float(np.asarray(w, float) @ self.mu_i)

    def density(self, w, x):
        """f_QA on the points x by the inverse-function rule: along the
        aggregate quantile function, f_QA(Q(p)) = 1 / Q'(p), with Q' the
        central difference on the p grid; zero below Q(p_1), and the value at
        Q(p_P) carried to the domain boundary 5 (the truncated density is
        positive there)."""
        Q = self.quantile(w)
        f_on_Q = 1.0 / np.gradient(Q, _dt_pg)
        return np.where((x >= Q[0]) & (x <= DT_HI), np.interp(x, Q, f_on_Q, right=f_on_Q[-1]), 0.0)


# ------------------------------------------------ behavioral layer and welfare
def _dt_fs_expnorm(A, rho, theta):
    """Batched Fehr-Schmidt utilities of the overlaps (def:ifcu) mapped to
    [0,1] by the exponential normalization eq:exp-norm.  A is B x N."""
    A = np.atleast_2d(A)
    n = A.shape[1]
    M = A[:, None, :] - A[:, :, None]                        # M[b,i,j] = A_j - A_i
    D = np.clip(M, 0.0, None).sum(axis=2) / (n - 1)
    S = np.clip(-M, 0.0, None).sum(axis=2) / (n - 1)
    Ufs = A - rho * D - theta * S
    pos = A > 0
    with np.errstate(divide="ignore", invalid="ignore"):
        r = np.where(pos, Ufs / np.where(pos, A, 1.0), 0.0)
    U = np.where(pos & (Ufs >= 0) & (Ufs <= A),
                 (np.exp(np.clip(r, 0.0, 1.0)) - 1.0) / (math.e - 1.0), 0.0)
    return np.where(pos & (Ufs > A), 1.0, U)


def _dt_ineq(U, s):
    """Batched inequality index I_s of tab:swf on the rows of U (relative
    range, relative mean deviation, coefficient of variation, Gini, Hoover);
    zero on an all-zero row by the book's convention."""
    U = np.atleast_2d(U)
    n = U.shape[1]
    m = U.mean(axis=1)
    safe = np.where(m > 0, m, 1.0)
    if s == 1:
        val = (U.max(axis=1) - U.min(axis=1)) / safe
    elif s == 2:
        val = np.abs(U - m[:, None]).sum(axis=1) / (n * safe)
    elif s == 3:
        val = np.sqrt(((U - m[:, None]) ** 2).mean(axis=1)) / safe
    elif s == 4:
        val = np.abs(U[:, :, None] - U[:, None, :]).sum(axis=(1, 2)) / (2.0 * n * n * safe)
    elif s == 5:
        val = np.abs(U - m[:, None]).sum(axis=1) / (2.0 * n * safe)
    else:
        raise ValueError(s)
    return np.where(m > 0, val, 0.0)


def _dt_welfare(panel, W, s):
    """Complete welfare in Sen's abbreviated form, W_s(w) = Ubar(w) (1 - I_s(U(w)))."""
    U = _dt_fs_expnorm(panel.overlaps(W), DT_RHO, DT_THETA)
    return U.mean(axis=1) * (1.0 - _dt_ineq(U, s))


def _dt_slsqp(fun, n, starts, maximize=True):
    """Multi-start SLSQP on the simplex (sum w = 1, 0 <= w_i <= 1) with a
    batched forward-difference gradient (step DT_FDH); the best local
    optimum over the starts is retained.  fun maps a (B x n) batch to (B,)."""
    sign = -1.0 if maximize else 1.0
    eye = np.eye(n)

    def f(w):
        return sign * float(fun(w[None, :])[0])

    def jac(w):
        v = fun(np.vstack([w[None, :], w[None, :] + DT_FDH * eye]))
        return sign * (v[1:] - v[0]) / DT_FDH

    cons = ({"type": "eq", "fun": lambda w: np.sum(w) - 1.0, "jac": lambda w: np.ones_like(w)},)
    bnds = [(0.0, 1.0)] * n
    best_w, best_v = None, np.inf
    for w0 in starts:
        r = _sp_minimize(f, w0, jac=jac, method="SLSQP", bounds=bnds, constraints=cons,
                         options={"ftol": DT_FTOL, "maxiter": DT_MAXITER})
        w = np.clip(r.x, 0.0, None)
        w = w / w.sum()
        v = f(w)
        if v < best_v:
            best_v, best_w = v, w
    return best_w, sign * best_v


# ------------------------------------------------------------ generate the panel
# Draw order under default_rng(DT_SEED): (1) the 30 leniencies a_i, (2) the
# 30 x 14 noise matrix eps_ik (expert-major).  Nothing else is drawn for the
# panel; the target importances tau_k are then calibrated deterministically.
_dt_rng = np.random.default_rng(DT_SEED)
_dt_len = _dt_rng.normal(0.0, DT_LENIENCY_SD, DT_N)
_dt_eps = _dt_rng.normal(0.0, DT_NOISE_SD, (DT_N, DT_M))
_dt_bias = np.array([[DT_BIAS if _DT_BG_DOMAIN[_DT_BACKGROUND[i]] == _DT_DIM[k] else 0.0
                      for k in range(DT_M)] for i in range(DT_N)])


def _dt_fit_column(tau_k, k):
    r = np.clip(tau_k + _dt_len + _dt_bias[:, k] + _dt_eps[:, k], 0.0, DT_HI)
    prof = _dt_profile(r)
    fits = np.array([_dt_fit_trunc_weibull(p) for p in prof])
    return r, prof, fits[:, 0], fits[:, 1], fits[:, 2], fits[:, 3]


_dt_tau = np.empty(DT_M)
_dt_calib_it = np.zeros(DT_M, int)
_dt_rating = np.empty((DT_N, DT_M))
_dt_prof = np.empty((DT_N, DT_M, 5))
_dt_kap = np.empty((DT_N, DT_M))
_dt_lam = np.empty((DT_N, DT_M))
_dt_wmean = np.empty((DT_N, DT_M))
_dt_H5 = np.empty((DT_N, DT_M))
for _k in range(DT_M):
    # secant iteration on tau_k: the equal-weight quantile-averaged mean of
    # the fitted panel (the average of the fitted expert means, QA means
    # being linear) is driven to the design mean
    t_prev, m_prev = None, None
    t_cur = _DT_DESIGN[_k]
    for _it in range(DT_CALIB_MAXIT):
        r, prof, kk, ll, wm, h5 = _dt_fit_column(t_cur, _k)
        m_cur = float(wm.mean())
        _dt_calib_it[_k] = _it + 1
        if abs(m_cur - _DT_DESIGN[_k]) < DT_CALIB_TOL:
            break
        if t_prev is None or abs(m_cur - m_prev) < 1e-9:
            t_new = t_cur + (_DT_DESIGN[_k] - m_cur)
        else:
            slope = (m_cur - m_prev) / (t_cur - t_prev)
            t_new = t_cur + (_DT_DESIGN[_k] - m_cur) / max(slope, 0.3)
        t_prev, m_prev, t_cur = t_cur, m_cur, t_new
    assert abs(m_cur - _DT_DESIGN[_k]) < 5 * DT_CALIB_TOL, \
        "Case II calibration of %s did not converge (%.5f vs %.2f)" % (_DT_IDS[_k], m_cur, _DT_DESIGN[_k])
    _dt_tau[_k] = t_cur
    _dt_rating[:, _k], _dt_prof[:, _k], _dt_kap[:, _k], _dt_lam[:, _k], _dt_wmean[:, _k], _dt_H5[:, _k] = \
        r, prof, kk, ll, wm, h5
print("   panel generated and fitted: shapes %.2f..%.2f, scales %.2f..%.2f, %.0f s"
      % (_dt_kap.min(), _dt_kap.max(), _dt_lam.min(), _dt_lam.max(), time.time() - _dt_t0))

# the illustrative profile of tab:dt-elicit, fitted by the same estimator
_dt_b1_fit = _dt_fit_trunc_weibull(_DT_B1_PROFILE)

# ------------------------------------------------------------------ solve
# Start order under a fresh default_rng(DT_SEED): for each barrier in order
# B1..B14, DT_STARTS_PROGRAM Dirichlet(1) draws; the bound programs use the
# barycentre plus the first DT_STARTS_BOUNDS of them, the scalarized program
# the barycentre plus all of them.
_dt_rng_starts = np.random.default_rng(DT_SEED)
_dt_solves = []
_dt_W = {}
_dt_A = {}
_dt_U = {}
_dt_panels = {}
_dt_bary = np.full(DT_N, 1.0 / DT_N)
for _k in range(DT_M):
    _bid = _DT_IDS[_k]
    panel = _DtPanel(_dt_kap[:, _k], _dt_lam[:, _k])
    _dt_panels[_bid] = panel
    _rs = [_dt_rng_starts.dirichlet(np.ones(DT_N)) for _ in range(DT_STARTS_PROGRAM)]
    _starts_b = [_dt_bary] + _rs[:DT_STARTS_BOUNDS]
    _starts_p = [_dt_bary] + _rs
    # confidence bounds: V is a convex quadratic on the simplex, so its
    # minimum is found from the barycentre and its maximum sits at a vertex
    _wVmin, Vmin = _dt_slsqp(panel.var, DT_N, [_dt_bary], maximize=False)
    Vmax = float(panel.Vi.max())
    for _s in range(1, 6):
        _eq = "EQ%d" % _s

        def Wfun(Wb, s=_s):
            return _dt_welfare(panel, Wb, s)

        _, Wmin = _dt_slsqp(Wfun, DT_N, _starts_b, maximize=False)
        _, Wmax = _dt_slsqp(Wfun, DT_N, _starts_b, maximize=True)
        # The program is solved from more starts than the bounds, so its
        # solution can reach a welfare outside [Wmin, Wmax].  Whenever it does,
        # the violated bound is refined by a further bound solve started from
        # that solution and the program is re-solved, until the solution lies
        # within the bounds (so that W~ in [0, 1] holds by construction).
        _n_refine = 0
        for _ref in range(DT_BOUND_REFINE_MAX + 1):
            dW, dV = Wmax - Wmin, Vmax - Vmin
            assert dW > 1e-9 and dV > 1e-9, "degenerate min-max range for %s %s" % (_bid, _eq)

            def scal(Wb, Wmin=Wmin, dW=dW, Vmin=Vmin, dV=dV):
                return (Wfun(Wb) - Wmin) / dW - (panel.var(Wb) - Vmin) / dV

            w, val = _dt_slsqp(scal, DT_N, _starts_p, maximize=True)
            _Ww = float(Wfun(w[None, :])[0])
            if _Ww <= Wmax + DT_BOUND_TOL and _Ww >= Wmin - DT_BOUND_TOL:
                break
            if _ref == DT_BOUND_REFINE_MAX:
                raise AssertionError("Case II %s %s: welfare bound not settled after %d refinements"
                                     % (_bid, _eq, DT_BOUND_REFINE_MAX))
            _n_refine += 1
            if _Ww > Wmax + DT_BOUND_TOL:
                _, _Wr = _dt_slsqp(Wfun, DT_N, [w], maximize=True)
                Wmax = max(Wmax, _Wr, _Ww)
            if _Ww < Wmin - DT_BOUND_TOL:
                _, _Wr = _dt_slsqp(Wfun, DT_N, [w], maximize=False)
                Wmin = min(Wmin, _Wr, _Ww)
        A = panel.overlaps(w[None, :])[0]
        U = _dt_fs_expnorm(A[None, :], DT_RHO, DT_THETA)[0]
        I = float(_dt_ineq(U[None, :], _s)[0])
        Ws = float(U.mean() * (1.0 - I))
        V = float(panel.var(w[None, :])[0])
        _dt_W[(_bid, _eq)] = w
        _dt_A[(_bid, _eq)] = A
        _dt_U[(_bid, _eq)] = U
        _dt_solves.append({
            "barrier": _bid, "eq": _eq, "mu": panel.mean(w), "V": V,
            "Ubar": float(U.mean()), "Umin": float(U.min()), "I": I, "W": Ws,
            "W_min": Wmin, "W_max": Wmax, "V_min": Vmin, "V_max": Vmax,
            "W_tilde": (Ws - Wmin) / dW, "V_tilde": (V - Vmin) / dV, "objective": val,
            "objective_barycentre": float(scal(_dt_bary[None, :])[0]),
            "Abar": float(A.mean()), "Amin": float(A.min()),
            "Abar_equal_weights": float(panel.overlaps(_dt_bary[None, :])[0].mean()),
            "n_active": int((w > DT_ACTIVE_TOL).sum()), "w_max": float(w.max()),
            "bound_refinements": _n_refine,
            "weight_gini": float(np.abs(w[:, None] - w[None, :]).sum() / (2.0 * DT_N * DT_N * w.mean())),
        })
    print("   %-4s mu by EQ1..EQ5: %s  active %s  (%.0f s)" % (
        _bid, " ".join("%.3f" % d["mu"] for d in _dt_solves[-5:]),
        [d["n_active"] for d in _dt_solves[-5:]], time.time() - _dt_t0))

# the 14 x 5 matrix (eq:dt-expectation), the average (eq:dt-average), the rank
_dt_Mx = np.array([[next(d["mu"] for d in _dt_solves if d["barrier"] == b and d["eq"] == e)
                    for e in _DT_EQ] for b in _DT_IDS])
_dt_avg = _dt_Mx.mean(axis=1)
_dt_order = sorted(range(DT_M), key=lambda r: -_dt_avg[r])
_dt_rank = np.empty(DT_M, int)
for _p, _r in enumerate(_dt_order, 1):
    _dt_rank[_r] = _p
_dt_triad = [_DT_IDS[r] for r in _dt_order[:3]]
_dt_ew_mean = np.array([_dt_panels[b].mean(_dt_bary) for b in _DT_IDS])
_dt_eq_orders = {e: ">".join(_DT_IDS[r] for r in np.argsort(-_dt_Mx[:, j])) for j, e in enumerate(_DT_EQ)}
print("   ranking: " + ">".join(_DT_IDS[r] for r in _dt_order))
print("   triad %s; bottom three %s; active experts %d..%d; EQ2-EQ5 max |diff| %.2e"
      % (_dt_triad, [_DT_IDS[r] for r in _dt_order[-3:]],
         min(d["n_active"] for d in _dt_solves), max(d["n_active"] for d in _dt_solves),
         float(np.abs(_dt_Mx[:, 1] - _dt_Mx[:, 4]).max())))

# collective densities of the leading triad under DT_TRIAD_EQ (Figure 6.7)
_dt_dens = {"x": _dt_xg}
for _b in _dt_triad:
    _dt_dens["f_" + _b] = _dt_panels[_b].density(_dt_W[(_b, DT_TRIAD_EQ)], _dt_xg)

_dt_cols = ["%s_%s" % (b, e) for b in _DT_IDS for e in _DT_EQ]
_dt_elapsed = time.time() - _dt_t0
write("fig6-5_dt_case.xlsx", {
    "config": cfg({
        "case": "II -- barriers to digital transformation in SMCEs (Section 6.3)",
        "figures": "fig6-5_dt_ranking14, fig6-6_dt_crossswf, fig6-7_dt_triad",
        "labels": "fig:dt-ranking14, fig:dt-crossswf, fig:dt-triad",
        "source_paper": "chen2024socialwelfare",
        "synthetic": 1,
        "generator": "build_workbooks.py Case II block (generated and solved; nothing typed)",
        "seed": DT_SEED,
        "seed_use": ("default_rng(seed): (1) 30 leniencies a_i, (2) 30x14 noise eps_ik; "
                     "a fresh default_rng(seed) then draws the SLSQP starts, %d Dirichlet(1) "
                     "vectors per barrier in order B1..B14" % DT_STARTS_PROGRAM),
        "N_experts": DT_N, "M_barriers": DT_M,
        "scale_min": 0.0, "scale_max": DT_HI, "n_levels": 5,
        "backgrounds": "experts 1-15 technologists (bias on B1-B4), 16-30 managers (bias on B5-B10)",
        "design_means": ", ".join("%s %.2f" % (b, d) for b, d in zip(_DT_IDS, _DT_DESIGN)),
        "target_calibration": ("tau_k found by secant iteration so that the equal-weight quantile-"
                               "averaged mean of the fitted panel equals the design mean within %g "
                               "(at most %d refits)" % (DT_CALIB_TOL, DT_CALIB_MAXIT)),
        "rating_rule": "r_ik = clip(tau_k + a_i + b_ik + eps_ik, 0, 5)",
        "leniency_sd": DT_LENIENCY_SD, "noise_sd": DT_NOISE_SD, "background_bias": DT_BIAS,
        "profile_rule": ("p_t proportional to exp(-(m_t - r_ik)^2 / (2 sd^2)), m_t = t - 1/2, "
                         "sd = %.1f" % DT_PROFILE_SD),
        "profile_kernel_sd": DT_PROFILE_SD,
        "weibull_estimator": ("grouped maximum likelihood of the truncated Weibull on the five "
                              "bands, nine L-BFGS-B starts in log-parameters"),
        "b1_profile": ", ".join("%.2f" % p for p in _DT_B1_PROFILE),
        "b1_fit_kappa": _dt_b1_fit[0], "b1_fit_lambda": _dt_b1_fit[1],
        "b1_fit_mean": _dt_b1_fit[2], "b1_fit_H5": _dt_b1_fit[3],
        "rho": DT_RHO, "theta": DT_THETA,
        "utility_normalization": "exponential unit-interval normalization eq:exp-norm",
        "welfare_form": "W_s(w) = Ubar(w) (1 - I_s(U(w))), Sen's abbreviated form (eq:complete-welfare, multiplicative)",
        "program": "max_w  W~_s(w) - V~(w) on the simplex, equal weights, both terms min-max normalized",
        "minmax_W": ("W_min, W_max over the simplex by multi-start SLSQP (barycentre + %d Dirichlet(1) "
                     "starts); a bound exceeded by the program's solution is refined by a bound solve "
                     "started from that solution and the program re-solved (at most %d times), so that "
                     "W~ lies in [0, 1] at every recorded solution" % (DT_STARTS_BOUNDS, DT_BOUND_REFINE_MAX)),
        "bound_refine_max": DT_BOUND_REFINE_MAX, "bound_tol": DT_BOUND_TOL,
        "minmax_V": "V_min by SLSQP from the barycentre (V convex); V_max = max_i V_i (vertex of the simplex)",
        "solver": ("scipy SLSQP, equality sum w = 1, bounds [0,1], batched forward-difference gradient "
                   "(step %g), ftol %g, maxiter %d" % (DT_FDH, DT_FTOL, DT_MAXITER)),
        "starts_program": "barycentre + %d Dirichlet(1)" % DT_STARTS_PROGRAM,
        "starts_bounds": "barycentre + %d Dirichlet(1)" % DT_STARTS_BOUNDS,
        "start_law": "Dirichlet(1,...,1), uniform on the simplex",
        "p_grid": DT_PGRID, "p_rule": "midpoint rule, p_j = (j - 1/2)/P",
        "x_bins": DT_XBINS, "overlap_rule": "sum over bins of min{dF_QA, dF_i} on [0,5]",
        "variance_rule": "V(w) = w' Sigma w, Sigma the covariance of the expert quantile functions on the p grid",
        "active_threshold": DT_ACTIVE_TOL,
        "triad": ",".join(_dt_triad), "triad_objective": DT_TRIAD_EQ,
        "band_lo": 3.0, "band_hi": 4.0,
        "x_label_ranking": "mean importance of the collective distribution, averaged over the five equity indices",
        "x_label_triad": "importance level",
        "y_label_triad": "collective probability density",
    }),
    "barriers": pd.DataFrame([{
        "id": b[0], "label": b[1], "dimension": b[2], "design_mean": b[3],
        "tau_calibrated": _dt_tau[k], "calibration_refits": int(_dt_calib_it[k]),
        "equal_weight_mean": _dt_ew_mean[k],
        "expert_mean_min": _dt_wmean[:, k].min(), "expert_mean_max": _dt_wmean[:, k].max(),
        "expert_mean_sd": _dt_wmean[:, k].std(),
    } for k, b in enumerate(_DT_BARRIERS)]),
    "dimensions": [
        {"code": "T", "name": "Technology",   "color": "blue"},
        {"code": "O", "name": "Organization", "color": "green"},
        {"code": "E", "name": "Environment",  "color": "amber"},
    ],
    "equity_objectives": [
        {"eq": "EQ1", "name": "EQ1 (rel. range)",     "index": "I1 relative range",          "color": "red"},
        {"eq": "EQ2", "name": "EQ2 (rel. mean dev.)", "index": "I2 relative mean deviation", "color": "blue"},
        {"eq": "EQ3", "name": "EQ3 (coef. var.)",     "index": "I3 coefficient of variation","color": "teal"},
        {"eq": "EQ4", "name": "EQ4 (Gini)",           "index": "I4 Gini",                    "color": "green"},
        {"eq": "EQ5", "name": "EQ5 (Hoover)",         "index": "I5 Hoover",                  "color": "purple"},
    ],
    "panel_experts": pd.DataFrame({"expert": np.arange(1, DT_N + 1), "background": _DT_BACKGROUND,
                                   "leniency": _dt_len}),
    "panel": pd.DataFrame([{
        "expert": i + 1, "background": _DT_BACKGROUND[i], "barrier": _DT_IDS[k],
        "tau": _dt_tau[k], "leniency": _dt_len[i], "bias": _dt_bias[i, k], "noise": _dt_eps[i, k],
        "rating": _dt_rating[i, k],
        **{"p%d" % (t + 1): _dt_prof[i, k, t] for t in range(5)},
        "kappa": _dt_kap[i, k], "lambda": _dt_lam[i, k], "H5": _dt_H5[i, k],
        "fitted_mean": _dt_wmean[i, k],
    } for i in range(DT_N) for k in range(DT_M)]),
    "elicitation_b1": pd.DataFrame([{"level": t + 1, "level_mid": t + 0.5, "probability": p}
                                    for t, p in enumerate(_DT_B1_PROFILE)]),
    "solves": pd.DataFrame(_dt_solves),
    "weights": pd.DataFrame({c: _dt_W[(c.split("_")[0], c.split("_")[1])] for c in _dt_cols},
                            index=pd.Index(np.arange(1, DT_N + 1), name="expert")).reset_index(),
    "overlaps": pd.DataFrame({c: _dt_A[(c.split("_")[0], c.split("_")[1])] for c in _dt_cols},
                             index=pd.Index(np.arange(1, DT_N + 1), name="expert")).reset_index(),
    "utilities": pd.DataFrame({c: _dt_U[(c.split("_")[0], c.split("_")[1])] for c in _dt_cols},
                              index=pd.Index(np.arange(1, DT_N + 1), name="expert")).reset_index(),
    "matrix": pd.DataFrame([{
        "id": _DT_IDS[k], "dimension": _DT_DIM[k],
        **{e: _dt_Mx[k, j] for j, e in enumerate(_DT_EQ)},
        "avg": _dt_avg[k], "rank": int(_dt_rank[k]),
        "spread": float(_dt_Mx[k].max() - _dt_Mx[k].min()),
        "design_mean": _DT_DESIGN[k], "equal_weight_mean": _dt_ew_mean[k],
        "n_active_min": min(d["n_active"] for d in _dt_solves if d["barrier"] == _DT_IDS[k]),
        "n_active_max": max(d["n_active"] for d in _dt_solves if d["barrier"] == _DT_IDS[k]),
    } for k in range(DT_M)]),
    "ranking": pd.DataFrame([{"rank": p, "id": _DT_IDS[r], "avg": _dt_avg[r]}
                             for p, r in enumerate(_dt_order, 1)]),
    "per_objective_order": pd.DataFrame([{"eq": e, "order": o} for e, o in _dt_eq_orders.items()]),
    "triad_density": pd.DataFrame(_dt_dens),
})
print("   Case II solved in %.0f s" % _dt_elapsed)

# =====================================================================
# SYNTHETIC-DATA TABLES  (data only -- no plotting script)
# =====================================================================
# The four table-only workbooks are written from solved values by their own
# blocks below: tab2-1 and tab2-5 by the Chapter 2 block, tab6-9 by the Case I
# fairness-panel block, tab5-3 by the ex:hmpanel block.  Nothing is typed here.


# =====================================================================
# =====================================================================
#  ADDITIONS 2026-08-28 -- the six figures promised in the proposal
#  review response, plus the workbook of the new Chapter 6 case study
#  (Case IV, rail-transit station accessibility with stakeholder
#  equity).  All heavy computation lives HERE so that every number a
#  figure plots or the text prints is carried by a workbook; the figure
#  scripts read and plot only.  Everything below is deterministic: the
#  generator seed is 202603 and no other entropy source is used.
# =====================================================================
# =====================================================================
import math
import numpy as np

NEW_SEED = 202603
_trapz = getattr(np, "trapezoid", np.trapz)


# =====================================================================
# CHAPTER 2 RUNNING EXAMPLE
#   Table 2.1 (tab:elicitation), Figure 2.1 (fig:lp-vs-qa),
#   Figure 2.2 (fig:lp-lop-qa), Table 2.5 (tab:biobj-example)
# ---------------------------------------------------------------------
# Stated inputs (the only typed numbers of this block):
#   * the five elicited percentiles of each expert in Table 2.1 (synthetic),
#   * the two-expert panel of Figure 2.1 (means -2.2 and 2.2, sd 0.75, equal
#     weights),
#   * the equal weights of Figure 2.2 and the trade-off alpha = 0.75,
#   * the seed 202603 and the numerical settings recorded in the config sheets.
# Everything else is computed here from the definitions of chapter2.tex:
#   Table 2.1     least squares of the elicited x_hat_p on Phi^{-1}(p), the
#                 quantile-matching fit of Section 2.2.2, rounded to one
#                 decimal before use (as the book prints them)
#   Fig 2.1/2.2   quantile average by prop:qa-properties(iii), mu = w.mu and
#                 sigma = w.sigma, cross-checked against alg:qa on a p-grid;
#                 logarithmic pool by def:log-pool, the normalized product,
#                 whose closed form for normal experts is the precision
#                 average, cross-checked against the numerical normalization
#   Table 2.5     Algorithm 2.2 (alg:biobjective): A(w) by def:consensus,
#                 V(w) by def:confidence, the four bounds and the scalarized
#                 program solved by multi-start SLSQP under seed 202603
# =====================================================================
from scipy.stats import norm as _norm
from scipy.optimize import minimize as _minimize
from scipy.interpolate import PchipInterpolator as _Pchip
from scipy.special import ndtr as _ndtr

CH2_SEED = NEW_SEED
CH2_P5 = np.array([0.05, 0.25, 0.50, 0.75, 0.95])
CH2_Z5 = _norm.ppf(CH2_P5)
# numerical settings (recorded in every config sheet of the block)
CH2_X_GRID = np.linspace(-2.0, 12.0, 7001)          # trapezoid cross-check of the overlap, dx = 0.002, tails > 5 sd; the log-pool normalization
CH2_P_GRID = np.linspace(1e-6, 1 - 1e-6, 20001)     # alg:qa / eq:confidence-quantile cross-checks
CH2_N_STARTS = 64                                   # Dirichlet(1,...,1) starts, plus vertices and centroid
CH2_FTOL = 1e-10
CH2_MAXITER = 500
CH2_ALPHA_STAR = 0.75
CH2_ALPHA_GRID = np.unique(np.round(np.concatenate([np.arange(0.0, 1.0001, 0.05),
                                                     np.arange(0.70, 0.9001, 0.01)]), 2))   # 37 distinct levels
CH2_N_PROBES = 2000                                 # Dirichlet(1,...,1) probe points of the rule-12 optimality check

# ---- Table 2.1: the elicited percentiles (stated inputs) and their LS fits
CH2_ELICITED = [
    ("Expert 1", [2.4, 3.3, 4.0, 4.7, 5.6]),
    ("Expert 2", [3.0, 4.2, 5.0, 5.8, 7.0]),
    ("Expert 3", [4.9, 5.8, 6.5, 7.2, 8.1]),
    ("Expert 4", [4.2, 5.0, 5.5, 6.0, 6.8]),
]


def _ch2_ls_fit(xhat):
    """Least squares of x_hat_p = mu + sigma * Phi^{-1}(p) over the five levels."""
    X = np.column_stack([np.ones(5), CH2_Z5])
    coef, res, _, _ = np.linalg.lstsq(X, np.asarray(xhat, float), rcond=None)
    rss = float(np.sum((X @ coef - xhat) ** 2))
    return float(coef[0]), float(coef[1]), rss


_t21 = []
for _name, _xh in CH2_ELICITED:
    _mu_ls, _sd_ls, _rss = _ch2_ls_fit(_xh)
    _t21.append({"expert": _name, "p05": _xh[0], "p25": _xh[1], "p50": _xh[2], "p75": _xh[3], "p95": _xh[4],
                 "fitted_mu": round(_mu_ls, 1), "fitted_sigma": round(_sd_ls, 1),
                 "ls_mu_exact": _mu_ls, "ls_sigma_exact": _sd_ls, "ls_rss": _rss})
CH2_MU = np.array([r["fitted_mu"] for r in _t21])       # the rounded fits are the panel of ex:running
CH2_SD = np.array([r["fitted_sigma"] for r in _t21])
assert np.all(CH2_SD > 0)
write("tab2-1_running_example_percentiles.xlsx", {
    "config": cfg({
        "table": "2.1", "label": "tab:elicitation",
        "inputs": "elicited percentiles p in {0.05,0.25,0.50,0.75,0.95} of four synthetic experts (typed, stated in the book)",
        "fit": "least squares of x_hat_p on Phi^{-1}(p): x_hat_p = mu + sigma * Phi^{-1}(p), numpy.linalg.lstsq",
        "rounding": "fitted mu and sigma rounded to one decimal before use; the rounded values are the panel of ex:running",
        "seed": "none -- deterministic least squares, no random draws",
    }),
    "table_2_1": _t21,
})


# ---- helpers shared by Figures 2.1/2.2 and Table 2.5 ------------------
def _ch2_qa_closed(w, mu, sd):
    """prop:qa-properties(iii): the quantile average of normal experts is N(w.mu, (w.sigma)^2)."""
    w = np.asarray(w, float)
    return float(w @ mu), float(w @ sd)


def _ch2_qa_density_numeric(w, mu, sd, x):
    """alg:qa on CH2_P_GRID: aggregate quantiles, monotone (PCHIP) interpolation,
    inversion, density by the inverse-function rule (cross-check only)."""
    q = sum(wi * (m + s * _norm.ppf(CH2_P_GRID)) for wi, m, s in zip(w, mu, sd))
    Fx = _Pchip(q, CH2_P_GRID, extrapolate=False)(x)
    dQ = _Pchip(CH2_P_GRID, q, extrapolate=False).derivative()
    with np.errstate(divide="ignore", invalid="ignore"):
        f = 1.0 / dQ(Fx)
    return np.where(np.isfinite(f), f, 0.0)


def _ch2_logpool_closed(w, mu, sd):
    """def:log-pool for normal experts: precision = sum w_i/sd_i^2,
    mean = sum(w_i mu_i/sd_i^2)/precision."""
    w = np.asarray(w, float)
    prec = float(np.sum(w / sd ** 2))
    return float(np.sum(w * mu / sd ** 2) / prec), prec ** -0.5


def _ch2_logpool_numeric(w, mu, sd, x):
    """def:log-pool literally: the weighted geometric mean normalized by its integral on CH2_X_GRID."""
    lg = sum(wi * _norm.logpdf(CH2_X_GRID, m, s) for wi, m, s in zip(w, mu, sd))
    g = np.exp(lg)
    Z = _trapz(g, CH2_X_GRID)
    lgx = sum(wi * _norm.logpdf(x, m, s) for wi, m, s in zip(w, mu, sd))
    return np.exp(lgx) / Z, float(_trapz(CH2_X_GRID * g, CH2_X_GRID) / Z)


def _ch2_overlap_normal(m1, s1, m2, s2):
    """int min{N(m1,s1^2), N(m2,s2^2)} dx exactly.  The two densities cross where
    log f_1 = log f_2, a quadratic in x (one root when s1 = s2), and on each interval
    between consecutive roots the smaller density is a fixed one of the two, so the
    integral is a sum of normal probabilities (scipy.special.ndtr).  Grid-free, so the
    optimizer of Algorithm 2.2 does not inherit a discretization error."""
    if abs(s1 - s2) < 1e-14:
        if abs(m1 - m2) < 1e-14:
            return 1.0
        roots = [0.5 * (m1 + m2)]
    else:
        a = 0.5 / s2 ** 2 - 0.5 / s1 ** 2
        b = m1 / s1 ** 2 - m2 / s2 ** 2
        c = 0.5 * m2 ** 2 / s2 ** 2 - 0.5 * m1 ** 2 / s1 ** 2 + math.log(s2 / s1)
        disc = b * b - 4.0 * a * c
        assert disc > 0, "two normal densities with different scales always cross twice"
        r1, r2 = (-b - math.sqrt(disc)) / (2.0 * a), (-b + math.sqrt(disc)) / (2.0 * a)
        roots = sorted([r1, r2])
    edges = [-math.inf] + roots + [math.inf]
    total = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        xm = 0.5 * (lo + hi) if math.isfinite(lo) and math.isfinite(hi) else (hi - 1.0 if math.isfinite(hi) else lo + 1.0)
        # the smaller density on this interval (log densities compared at its midpoint)
        if -0.5 * ((xm - m1) / s1) ** 2 - math.log(s1) <= -0.5 * ((xm - m2) / s2) ** 2 - math.log(s2):
            m, s = m1, s1
        else:
            m, s = m2, s2
        total += _ndtr((hi - m) / s) - _ndtr((lo - m) / s)
    return total


def _ch2_A_ms(m, s):
    """def:consensus in the aggregate coordinates: sum_i int min{f_i, N(m, s^2)} dx, exact."""
    return float(sum(_ch2_overlap_normal(mi, si, m, s) for mi, si in zip(CH2_MU, CH2_SD)))


def _ch2_A(w, mu, sd):
    """def:consensus: A(w) = sum_i int min{f_i, f_QA(.; w)} dx with f_QA the closed-form
    normal aggregate of prop:qa-properties(iii); each overlap evaluated exactly."""
    m, s = _ch2_qa_closed(w, mu, sd)
    return float(sum(_ch2_overlap_normal(mi, si, m, s) for mi, si in zip(mu, sd)))


def _ch2_A_grid(w, mu, sd):
    """def:consensus by the trapezoid rule on CH2_X_GRID with the closed-form aggregate
    (cross-check only; its O(h^2) error at the density crossings is about 1e-7)."""
    m, s = _ch2_qa_closed(w, mu, sd)
    fqa = _norm.pdf(CH2_X_GRID, m, s)
    return float(sum(_trapz(np.minimum(fqa, fi), CH2_X_GRID) for fi in _CH2_FI))


def _ch2_A_numeric(w, mu, sd):
    """def:consensus with f_QA from alg:qa numerically (cross-check only)."""
    fqa = _ch2_qa_density_numeric(w, mu, sd, CH2_X_GRID)
    return float(sum(_trapz(np.minimum(fqa, fi), CH2_X_GRID) for fi in _CH2_FI))


def _ch2_V(w, mu, sd):
    """def:confidence: V(w) = (w.sigma)^2, the equality case of thm:qa-moments
    for the location-scale panel (prop:qa-properties(iii))."""
    return float(np.asarray(w, float) @ sd) ** 2


def _ch2_V_numeric(w, mu, sd):
    """eq:confidence-quantile on CH2_P_GRID by the trapezoid rule (cross-check only)."""
    q = sum(wi * (m + s * _norm.ppf(CH2_P_GRID)) for wi, m, s in zip(w, mu, sd))
    mq = _trapz(q, CH2_P_GRID)
    return float(_trapz((q - mq) ** 2, CH2_P_GRID))


def _ch2_fibre(m, s, mu, sd):
    """The set of simplex weight vectors with (w.mu, w.sigma) = (m, s): the fibre of
    the affine map w -> (w.mu, w.sigma), a segment (or a point) of the simplex.
    Returns its endpoints (each has at least one zero coordinate)."""
    Aeq = np.vstack([np.ones(len(mu)), mu, sd])
    beq = np.array([1.0, m, s])
    ends = []
    for j in range(len(mu)):
        idx = [i for i in range(len(mu)) if i != j]
        try:
            w3 = np.linalg.solve(Aeq[:, idx], beq)
        except np.linalg.LinAlgError:
            continue
        if np.all(w3 >= -1e-9):
            w = np.zeros(len(mu)); w[idx] = np.clip(w3, 0, None); w /= w.sum()
            if not any(np.allclose(w, e, atol=1e-7) for e in ends):
                ends.append(w)
    assert 1 <= len(ends) <= 2, "fibre of (%.4f, %.4f) has %d endpoints" % (m, s, len(ends))
    return ends


def _ch2_tiebreak(w, mu, sd):
    """Selection rule for a non-unique optimizer: the midpoint of the optimal segment
    (the fibre of the best point's (w.mu, w.sigma)); a unique optimizer is returned as is."""
    m, s = _ch2_qa_closed(w, mu, sd)
    ends = _ch2_fibre(m, s, mu, sd)
    mid = np.mean(ends, axis=0)
    return mid, ends


# ---- Figure 2.1: two experts, QA row computed ---------------------------
_f21_mu, _f21_sd, _f21_w = np.array([-2.2, 2.2]), np.array([0.75, 0.75]), np.array([0.5, 0.5])
_f21_qa_mu, _f21_qa_sd = _ch2_qa_closed(_f21_w, _f21_mu, _f21_sd)
_f21_x = np.linspace(-5.5, 5.5, 600)                  # the plotting grid of density_figure()
_f21_qa_dev = float(np.max(np.abs(_ch2_qa_density_numeric(_f21_w, _f21_mu, _f21_sd, _f21_x)
                                  - _norm.pdf(_f21_x, _f21_qa_mu, _f21_qa_sd))))
assert _f21_qa_dev < 1e-3, "Figure 2.1: alg:qa disagrees with the closed form (%.2e)" % _f21_qa_dev
write("fig2-1_linear_pool_vs_qa.xlsx", {
    "config": cfg({
        "figure": "2.1", "label": "fig:lp-vs-qa",
        "x_label": "x", "y_label": "density",
        "domain_min": -5.5, "domain_max": 5.5, "ymax": 0.6,
        "draw_linear_pool": 1, "title": "Linear pool versus quantile averaging",
        "inputs": "two normal experts, means -2.2 and 2.2, sd 0.75, equal weights (typed, stated in the caption)",
        "linear_pool": "computed by the plotting script from the expert rows (def:linear-pool, weight-normalized mixture)",
        "quantile_average": "computed here by prop:qa-properties(iii): mu = w.mu, sigma = w.sigma",
        "qa_cross_check": "alg:qa on %d probability levels in [1e-6, 1-1e-6], PCHIP interpolation, inverse-function rule" % len(CH2_P_GRID),
        "qa_max_abs_density_deviation_on_plot_grid": _f21_qa_dev,
        "seed": "none -- closed forms, no random draws",
    }),
    "gaussians": [
        {"legend": "individual experts", "mu": _f21_mu[0], "sigma": _f21_sd[0], "weight": _f21_w[0], "role": "expert", "linestyle": "dotted"},
        {"legend": "_nolegend_",         "mu": _f21_mu[1], "sigma": _f21_sd[1], "weight": _f21_w[1], "role": "expert", "linestyle": "dotted"},
        {"legend": "quantile average",   "mu": _f21_qa_mu, "sigma": _f21_qa_sd, "weight": 1.0, "role": "aggregate", "linestyle": "dashed"},
    ],
})

# ---- Figure 2.2: the running panel under equal weights ------------------
_CH2_FI = [_norm.pdf(CH2_X_GRID, m, s) for m, s in zip(CH2_MU, CH2_SD)]   # expert densities on the overlap grid
_f22_w = np.full(4, 0.25)
_f22_x = np.linspace(1.0, 10.0, 600)                   # the plotting grid of density_figure()
_f22_qa_mu, _f22_qa_sd = _ch2_qa_closed(_f22_w, CH2_MU, CH2_SD)
_f22_qa_dev = float(np.max(np.abs(_ch2_qa_density_numeric(_f22_w, CH2_MU, CH2_SD, _f22_x)
                                  - _norm.pdf(_f22_x, _f22_qa_mu, _f22_qa_sd))))
_f22_lo_mu, _f22_lo_sd = _ch2_logpool_closed(_f22_w, CH2_MU, CH2_SD)
_f22_lo_num, _f22_lo_num_mu = _ch2_logpool_numeric(_f22_w, CH2_MU, CH2_SD, _f22_x)
_f22_lo_dev = float(np.max(np.abs(_f22_lo_num - _norm.pdf(_f22_x, _f22_lo_mu, _f22_lo_sd))))
assert _f22_qa_dev < 1e-3, "Figure 2.2: alg:qa disagrees with the closed form (%.2e)" % _f22_qa_dev
assert _f22_lo_dev < 1e-3 and abs(_f22_lo_num_mu - _f22_lo_mu) < 1e-3, \
    "Figure 2.2: normalized product disagrees with the precision-average closed form"
_f22_lp_sd = float(np.sqrt(np.sum(_f22_w * CH2_SD ** 2) + np.sum(_f22_w * (CH2_MU - _f22_w @ CH2_MU) ** 2)))
write("fig2-2_three_pooling_operators.xlsx", {
    "config": cfg({
        "figure": "2.2", "label": "fig:lp-lop-qa",
        "x_label": "x", "y_label": "density",
        "domain_min": 1, "domain_max": 10, "ymax": 0.55,
        "draw_linear_pool": 1, "title": "Linear, logarithmic, and quantile pools",
        "inputs": "the four rounded normal fits of Table 2.1 (tab2-1 workbook) under equal weights 0.25",
        "linear_pool": "computed by the plotting script from the expert rows (def:linear-pool); mixture sd recorded below",
        "linear_pool_sd": _f22_lp_sd,
        "quantile_average": "computed here by prop:qa-properties(iii): mu = w.mu, sigma = w.sigma",
        "qa_cross_check": "alg:qa on %d probability levels, PCHIP interpolation, inverse-function rule" % len(CH2_P_GRID),
        "qa_max_abs_density_deviation_on_plot_grid": _f22_qa_dev,
        "logarithmic_pool": "computed here by def:log-pool; for normal experts the normalized product is normal with precision sum w_i/sigma_i^2 and mean sum(w_i mu_i/sigma_i^2)/precision",
        "logpool_cross_check": "normalized product integrated by the trapezoid rule on x in [-2, 12], step 0.002",
        "logpool_max_abs_density_deviation_on_plot_grid": _f22_lo_dev,
        "seed": "none -- closed forms, no random draws",
    }),
    "gaussians": [
        {"legend": "experts",          "mu": CH2_MU[0], "sigma": CH2_SD[0], "weight": _f22_w[0], "role": "expert", "linestyle": "dotted"},
        {"legend": "_nolegend_",       "mu": CH2_MU[1], "sigma": CH2_SD[1], "weight": _f22_w[1], "role": "expert", "linestyle": "dotted"},
        {"legend": "_nolegend_",       "mu": CH2_MU[2], "sigma": CH2_SD[2], "weight": _f22_w[2], "role": "expert", "linestyle": "dotted"},
        {"legend": "_nolegend_",       "mu": CH2_MU[3], "sigma": CH2_SD[3], "weight": _f22_w[3], "role": "expert", "linestyle": "dotted"},
        {"legend": "quantile average", "mu": _f22_qa_mu, "sigma": _f22_qa_sd, "weight": 1.0, "role": "aggregate", "linestyle": "dashed"},
        {"legend": "logarithmic pool", "mu": _f22_lo_mu, "sigma": _f22_lo_sd, "weight": 1.0, "role": "aggregate", "linestyle": "dashdot"},
    ],
})

# ---- Table 2.5: Algorithm 2.2 on the running panel ----------------------
_ch2_rng = np.random.default_rng(CH2_SEED)
# draw order: (1) the CH2_N_STARTS Dirichlet(1,1,1,1) starts, (2) CH2_N_PROBES Dirichlet(1,1,1,1)
# probe points used only by the rule-12 optimality check at the end of the file
CH2_STARTS = np.vstack([_ch2_rng.dirichlet(np.ones(4), size=CH2_N_STARTS), np.eye(4), np.full((1, 4), 0.25)])
CH2_PROBES = _ch2_rng.dirichlet(np.ones(4), size=CH2_N_PROBES)
_ch2_cons = [{"type": "eq", "fun": lambda w: np.sum(w) - 1.0}]
_ch2_bnds = [(0.0, 1.0)] * 4


def _ch2_multistart(fun):
    """Minimize fun over the simplex by SLSQP from every start in CH2_STARTS;
    returns (best value, best w, number of starts within 1e-6 of the best, number of starts used)."""
    sols = []
    for w0 in CH2_STARTS:
        r = _minimize(fun, w0, method="SLSQP", bounds=_ch2_bnds, constraints=_ch2_cons,
                      options={"ftol": CH2_FTOL, "maxiter": CH2_MAXITER})
        w = np.clip(r.x, 0.0, 1.0); w = w / w.sum()
        sols.append((float(fun(w)), w))
    fs = np.array([s[0] for s in sols])
    k = int(np.argmin(fs))
    return sols[k][0], sols[k][1], int(np.sum(fs - fs[k] < 1e-6)), len(sols)


_A = lambda w: _ch2_A(w, CH2_MU, CH2_SD)
_V = lambda w: _ch2_V(w, CH2_MU, CH2_SD)
_Amin, _wAmin, _nAmin, _nS = _ch2_multistart(_A)
_negAmax, _wAmax, _nAmax, _ = _ch2_multistart(lambda w: -_A(w)); _Amax = -_negAmax
_Vmin, _wVmin, _nVmin, _ = _ch2_multistart(_V)
_negVmax, _wVmax, _nVmax, _ = _ch2_multistart(lambda w: -_V(w)); _Vmax = -_negVmax
assert _Amax > _Amin and _Vmax > _Vmin


def _ch2_objective(w, alpha):
    """alg:biobjective: alpha * A~(w) - (1 - alpha) * V~(w) with min-max normalized objectives."""
    At = (_A(w) - _Amin) / (_Amax - _Amin)
    Vt = (_V(w) - _Vmin) / (_Vmax - _Vmin)
    return alpha * At - (1.0 - alpha) * Vt


def _ch2_objective_ms(ms, alpha):
    """The same scalarized objective written in the aggregate coordinates (m, s) = (w.mu, w.sigma),
    through which alone both objectives depend on w on this panel."""
    m, s = float(ms[0]), float(ms[1])
    if s <= 0:
        return -np.inf
    A = _ch2_A_ms(m, s)
    return alpha * (A - _Amin) / (_Amax - _Amin) - (1.0 - alpha) * (s ** 2 - _Vmin) / (_Vmax - _Vmin)


CH2_POLISH_XATOL, CH2_POLISH_FATOL = 1e-9, 1e-14


def _ch2_solve_alpha(alpha):
    """One grid point of alg:biobjective: multi-start SLSQP over the simplex, then, for an
    interior optimizer, a Nelder-Mead polish of (m*, s*) in the aggregate plane (exact for
    this panel, since the objective depends on w only through that pair), then the fibre
    of (m*, s*) and its midpoint as the reported weight vector."""
    negf, wb, nagree, _ = _ch2_multistart(lambda w: -_ch2_objective(w, alpha))
    m0, s0 = _ch2_qa_closed(wb, CH2_MU, CH2_SD)
    if np.max(wb) < 0.999:
        r = _minimize(lambda ms: -_ch2_objective_ms(ms, alpha), np.array([m0, s0]), method="Nelder-Mead",
                      options={"xatol": CH2_POLISH_XATOL, "fatol": CH2_POLISH_FATOL, "maxiter": 4000})
        m1, s1 = float(r.x[0]), float(r.x[1])
        assert -r.fun >= -negf - 1e-9, "polish worsened the objective at alpha=%.2f" % alpha
        assert abs(m1 - m0) < 5e-3 and abs(s1 - s0) < 5e-3, "polish moved (m, s) by more than 5e-3 at alpha=%.2f" % alpha
        ends = _ch2_fibre(m1, s1, CH2_MU, CH2_SD)
        f = -r.fun
    else:
        ends = _ch2_fibre(m0, s0, CH2_MU, CH2_SD)
        f = -negf
    wmid = np.mean(ends, axis=0)
    return wb, wmid, ends, f, nagree


_sweep = []
_sweep_sol = {}
for _al in CH2_ALPHA_GRID:
    _wb, _wmid, _ends, _f, _nagree = _ch2_solve_alpha(float(_al))
    _m, _s = _ch2_qa_closed(_wmid, CH2_MU, CH2_SD)
    _sweep_sol[float(_al)] = (_wb, _wmid, _ends, _f, _nagree)
    _sweep.append({"alpha": float(_al), "w1": _wmid[0], "w2": _wmid[1], "w3": _wmid[2], "w4": _wmid[3],
                   "A": _A(_wmid), "V": _V(_wmid), "fQA_mu": _m, "fQA_sigma": _s,
                   "objective": _f, "interior": int(np.max(_wmid) < 0.999),
                   "segment_length": float(np.linalg.norm(_ends[-1] - _ends[0])),
                   "starts_within_1e-6_of_best": _nagree, "starts_total": _nS})
_wb75, _w75, _ends75, _f75, _n75 = _sweep_sol[CH2_ALPHA_STAR]
_m75, _s75 = _ch2_qa_closed(_w75, CH2_MU, CH2_SD)
_alphas_interior = [r["alpha"] for r in _sweep if r["interior"] == 1]
assert _alphas_interior, "no interior compromise found on the alpha grid"

_ch2_rows = [
    ("equal weights",                    np.full(4, 0.25)),
    ("maximum consensus",                _wAmax),
    ("minimum variance",                 _wVmin),
    ("balance, alpha=%.2f" % CH2_ALPHA_STAR, _w75),
]
_t25 = []
_t25_checks = []
for _emph, _w in _ch2_rows:
    _m, _s = _ch2_qa_closed(_w, CH2_MU, CH2_SD)
    _t25.append({"weight_vector": "(%s)" % ",".join("%.3f" % v for v in _w), "emphasis": _emph,
                 "A": _A(_w), "V": _V(_w), "fQA_mu": _m, "fQA_sigma": _s,
                 "w1": _w[0], "w2": _w[1], "w3": _w[2], "w4": _w[3],
                 "A_tilde": (_A(_w) - _Amin) / (_Amax - _Amin), "V_tilde": (_V(_w) - _Vmin) / (_Vmax - _Vmin),
                 "objective_alpha_star": _ch2_objective(_w, CH2_ALPHA_STAR)})
    _t25_checks.append({"emphasis": _emph, "A_exact": _A(_w),
                        "A_trapezoid_grid": _ch2_A_grid(_w, CH2_MU, CH2_SD),
                        "A_alg_qa_numeric": _ch2_A_numeric(_w, CH2_MU, CH2_SD),
                        "V_closed_form": _V(_w), "V_eq_confidence_quantile_numeric": _ch2_V_numeric(_w, CH2_MU, CH2_SD)})
for _c in _t25_checks:
    assert abs(_c["A_exact"] - _c["A_trapezoid_grid"]) < 1e-6, _c
    assert abs(_c["A_exact"] - _c["A_alg_qa_numeric"]) < 2e-3, _c
    assert abs(_c["V_closed_form"] - _c["V_eq_confidence_quantile_numeric"]) < 2e-3, _c

write("tab2-5_biobjective_example.xlsx", {
    "config": cfg({
        "table": "2.5", "label": "tab:biobj-example",
        "panel": "the four rounded normal fits of Table 2.1 (tab2-1 workbook): mu = %s, sigma = %s" % (
            CH2_MU.tolist(), CH2_SD.tolist()),
        "aggregate": "quantile average, closed form N(w.mu, (w.sigma)^2) by prop:qa-properties(iii)",
        "consensus_A": "def:consensus, A(w) = sum_i int min{f_i, f_QA} dx, each overlap of two normal densities evaluated exactly as the normal probability mass on the intervals cut by their crossing points (roots of log f_i = log f_QA), scipy.special.ndtr",
        "consensus_A_cross_check": "trapezoid rule on x in [-2, 12] with %d points (step %.3f), sheet cross_checks; its error at the density crossings is about 1e-7, enough to move the flat alpha* optimizer in its third decimal, which is why the exact form is the primary rule" % (
            len(CH2_X_GRID), CH2_X_GRID[1] - CH2_X_GRID[0]),
        "confidence_V": "def:confidence, V(w) = (w.sigma)^2 (equality case of thm:qa-moments on the location-scale panel)",
        "cross_checks": "A with f_QA from alg:qa on %d probability levels and V by eq:confidence-quantile on the same levels, sheet cross_checks" % len(CH2_P_GRID),
        "solver": "scipy.optimize.minimize, method SLSQP, bounds [0,1], equality sum w = 1, finite-difference gradients",
        "starts": "%d Dirichlet(1,1,1,1) starts from numpy.random.default_rng(%d) (first draw of the block) plus the 4 vertices and the centroid, %d starts per solve, sheet starts" % (
            CH2_N_STARTS, CH2_SEED, _nS),
        "ftol": "%.0e" % CH2_FTOL, "maxiter": CH2_MAXITER,
        "normalization": "min-max, bounds solved over the simplex by the same multi-start (sheet bounds)",
        "A_min": _Amin, "A_max": _Amax, "V_min": _Vmin, "V_max": _Vmax,
        "alpha_grid": "0.00 to 1.00 step 0.05 and 0.70 to 0.90 step 0.01, %d distinct levels (sheet alpha_sweep)" % len(CH2_ALPHA_GRID),
        "probes": "%d Dirichlet(1,1,1,1) points from the same generator (second draw of the block), used by the rule-12 optimality check of the alpha* row, not stored" % CH2_N_PROBES,
        "alpha_star": CH2_ALPHA_STAR,
        "polish": "for an interior optimizer the pair (m*, s*) = (w.mu, w.sigma) of the best SLSQP point is polished by Nelder-Mead in the aggregate plane, xatol %.0e, fatol %.0e (exact for this panel: the objective depends on w only through that pair)" % (
            CH2_POLISH_XATOL, CH2_POLISH_FATOL),
        "tie_break": "the optimizer is a segment of the simplex (the fibre of (m*, s*) under w -> (w.mu, w.sigma)); the reported vector is the midpoint of that segment, sheet level_set_alpha_star",
        "alpha_star_slsqp_point": "(%s)" % ",".join("%.6f" % v for v in _wb75),
        "alpha_star_objective": _f75,
        "alpha_star_starts_within_1e-6_of_best": _n75,
        "interior_alpha_window_on_grid": "[%.2f, %.2f]" % (min(_alphas_interior), max(_alphas_interior)),
        "seed": CH2_SEED,
        "synthetic": 1,
    }),
    "table_2_5": _t25,
    "bounds": [
        {"bound": "A_min", "value": _Amin, "w1": _wAmin[0], "w2": _wAmin[1], "w3": _wAmin[2], "w4": _wAmin[3], "starts_within_1e-6_of_best": _nAmin, "starts_total": _nS},
        {"bound": "A_max", "value": _Amax, "w1": _wAmax[0], "w2": _wAmax[1], "w3": _wAmax[2], "w4": _wAmax[3], "starts_within_1e-6_of_best": _nAmax, "starts_total": _nS},
        {"bound": "V_min", "value": _Vmin, "w1": _wVmin[0], "w2": _wVmin[1], "w3": _wVmin[2], "w4": _wVmin[3], "starts_within_1e-6_of_best": _nVmin, "starts_total": _nS},
        {"bound": "V_max", "value": _Vmax, "w1": _wVmax[0], "w2": _wVmax[1], "w3": _wVmax[2], "w4": _wVmax[3], "starts_within_1e-6_of_best": _nVmax, "starts_total": _nS},
    ],
    "alpha_sweep": _sweep,
    "level_set_alpha_star": [
        {"point": "endpoint 1", "w1": _ends75[0][0], "w2": _ends75[0][1], "w3": _ends75[0][2], "w4": _ends75[0][3], "objective": _ch2_objective(_ends75[0], CH2_ALPHA_STAR)},
        {"point": "endpoint 2", "w1": _ends75[-1][0], "w2": _ends75[-1][1], "w3": _ends75[-1][2], "w4": _ends75[-1][3], "objective": _ch2_objective(_ends75[-1], CH2_ALPHA_STAR)},
        {"point": "midpoint (reported)", "w1": _w75[0], "w2": _w75[1], "w3": _w75[2], "w4": _w75[3], "objective": _ch2_objective(_w75, CH2_ALPHA_STAR)},
        {"point": "SLSQP best", "w1": _wb75[0], "w2": _wb75[1], "w3": _wb75[2], "w4": _wb75[3], "objective": _f75},
    ],
    "cross_checks": _t25_checks,
    "starts": [{"start": k, "w1": s[0], "w2": s[1], "w3": s[2], "w4": s[3],
                "law": ("Dirichlet(1,1,1,1)" if k < CH2_N_STARTS else ("vertex" if k < CH2_N_STARTS + 4 else "centroid"))}
               for k, s in enumerate(CH2_STARTS)],
})
print("   Table 2.5 solved: A in [%.4f, %.4f], V in [%.4f, %.4f]; alpha=%.2f -> w = (%s), A %.4f, V %.4f, N(%.3f, %.3f^2), objective %.5f (%d/%d starts agree); interior for alpha in [%.2f, %.2f]" % (
    _Amin, _Amax, _Vmin, _Vmax, CH2_ALPHA_STAR, ", ".join("%.3f" % v for v in _w75), _A(_w75), _V(_w75), _m75, _s75, _f75, _n75, _nS,
    min(_alphas_interior), max(_alphas_interior)))



# ------------------------------------------------------------------ numerics --
def _erf(x):
    """Abramowitz-Stegun 7.1.26 (vectorized, |err| < 1.5e-7). Deterministic."""
    x = np.asarray(x, float)
    s = np.sign(x)
    a = np.abs(x)
    t = 1.0 / (1.0 + 0.3275911 * a)
    y = 1.0 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t
                - 0.284496736) * t + 0.254829592) * t * np.exp(-a * a)
    return s * y


def _npdf(x):
    return np.exp(-0.5 * np.asarray(x, float) ** 2) / math.sqrt(2.0 * math.pi)


def _ncdf(x):
    """Kept for reference; the ex:hmpanel block uses the exact scipy cdf."""
    return 0.5 * (1.0 + _erf(np.asarray(x, float) / math.sqrt(2.0)))


def _norm_ppf(p):
    """Acklam's rational approximation to the standard normal quantile."""
    p = np.asarray(p, float)
    a = [-3.969683028665376e+01, 2.209460984245205e+02, -2.759285104469687e+02,
         1.383577518672690e+02, -3.066479806614716e+01, 2.506628277459239e+00]
    b = [-5.447609879822406e+01, 1.615858368580409e+02, -1.556989798598866e+02,
         6.680131188771972e+01, -1.328068155288572e+01]
    c = [-7.784894002430293e-03, -3.223964580411365e-01, -2.400758277161838e+00,
         -2.549732539343734e+00, 4.374664141464968e+00, 2.938163982698783e+00]
    d = [7.784695709041462e-03, 3.224671290700398e-01, 2.445134137142996e+00,
         3.754408661907416e+00]
    plow, phigh = 0.02425, 1 - 0.02425
    q = np.empty_like(p)
    lo, hi = p < plow, p > phigh
    mid = ~(lo | hi)
    if lo.any():
        u = np.sqrt(-2.0 * np.log(p[lo]))
        q[lo] = (((((c[0] * u + c[1]) * u + c[2]) * u + c[3]) * u + c[4]) * u + c[5]) / \
                ((((d[0] * u + d[1]) * u + d[2]) * u + d[3]) * u + 1.0)
    if hi.any():
        u = np.sqrt(-2.0 * np.log(1.0 - p[hi]))
        q[hi] = -(((((c[0] * u + c[1]) * u + c[2]) * u + c[3]) * u + c[4]) * u + c[5]) / \
                 ((((d[0] * u + d[1]) * u + d[2]) * u + d[3]) * u + 1.0)
    if mid.any():
        u = p[mid] - 0.5
        r = u * u
        q[mid] = (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5]) * u / \
                 (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1.0)
    return q


def _project_simplex(W):
    """Row-wise Euclidean projection onto the probability simplex."""
    W = np.atleast_2d(np.asarray(W, float))
    n = W.shape[1]
    U = np.sort(W, axis=1)[:, ::-1]
    css = np.cumsum(U, axis=1) - 1.0
    idx = np.arange(1, n + 1)
    rho = (U - css / idx > 0).sum(axis=1)
    theta = css[np.arange(W.shape[0]), rho - 1] / rho
    return np.maximum(W - theta[:, None], 0.0)


def _ascend(obj, starts, iters=220, step0=0.35):
    """Deterministic projected-gradient ascent (batched forward differences)."""
    best_w, best_v = None, -np.inf
    for w0 in starts:
        w = np.asarray(w0, float).copy()
        n = w.size
        eye = np.eye(n)
        for r in range(iters):
            h = 1e-6
            W = np.vstack([w[None, :], w[None, :] + h * eye])
            V = obj(W)
            g = (V[1:] - V[0]) / h
            eta = step0 / (1.0 + r / 40.0)
            w = _project_simplex(w + eta * g)[0]
        v = float(obj(w[None, :])[0])
        if v > best_v:
            best_v, best_w = v, w
    return best_w, best_v


def _gini_vec(u):
    """Gini coefficient of a nonnegative vector (0 for an even profile)."""
    u = np.asarray(u, float)
    n = u.size
    m = u.mean()
    if m <= 0:
        return 0.0
    return float(np.abs(u[:, None] - u[None, :]).sum() / (2.0 * n * n * m))


def _fs_phi(A, rho, theta):
    """Batched Fehr-Schmidt utilities -> parabolic normalization -> Bonferroni
    Phi_{1,1}; A is (B x n) overlaps.  Returns (Phi (B,), Util (B x n))."""
    A = np.atleast_2d(A)
    n = A.shape[1]
    M = A[:, None, :] - A[:, :, None]          # M[b,i,j] = A_j - A_i
    D = np.clip(M, 0.0, None).sum(axis=2) / (n - 1)
    S = np.clip(-M, 0.0, None).sum(axis=2) / (n - 1)
    U = A - rho * D - theta * S
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = np.where(A > 0, U / np.where(A > 0, A, 1.0), 0.0)
    Ut = np.clip(ratio, 0.0, 1.0) ** 2
    S1 = Ut.sum(axis=1)
    S2 = (Ut ** 2).sum(axis=1)
    Phi = np.sqrt(np.clip((S1 ** 2 - S2) / (n * (n - 1)), 0.0, None))
    return Phi, Ut


# =====================================================================
# CASE STUDY I, FAIRNESS PANEL (Section 6.2) -- SOLVED HERE, NOT TYPED
#   -> Figure 6.3  fig6-3_bim_densities.xlsx  (fig:bim-densities)
#   -> Figure 6.4  fig6-4_bim_tradeoff.xlsx   (fig:bim-tradeoff)
#   -> Table  6.9  tab6-9_bim_results.xlsx    (tab:bim)
# The seven-expert tri-objective program eq:bim-triobjective is solved
# from the stated inputs (eq:bim-panel-mu, eq:bim-panel-sigma, rho, theta)
# with the book's conventions:
#   * F_QA(.;w) = N(w.mu, (w.sigma)^2)                   Prop. qa-properties(iii)
#   * A_i(w) = int_R min{f_i, f_QA} dx, whole real line   def:consensus
#     (closed form through the two crossing points of the densities)
#   * Abar = (1/N) sum_i A_i,  V = (w.sigma)^2            def:confidence
#   * U_i^FS on the overlap profile, rho = 0.4, vartheta = 0.2,
#     divisor N-1                                        def:ifcu
#   * power normalization, kappa = 2                     eq:parabola-norm
#   * Bonferroni mean of order (1,1)                     def:collective-fairness
#   * min-max normalization with the bounds of each objective SOLVED over
#     the simplex by the same multi-start procedure      Algorithm 2.2
#   * max alpha*At - beta*Vt + delta*Pt, alpha = 2(1-delta)/3,
#     beta = (1-delta)/3, delta on the grid {0, 0.1, ..., 0.6}
#   * multi-start SQP = scipy SLSQP from 200 starting points drawn
#     uniformly on the simplex (Dirichlet(1,...,1)) by ONE generator
#     numpy.random.default_rng(202603), consumed in the documented order
#     (bounds first, then the sweep); the first start attaining the
#     highest objective is retained.
# Everything the book prints for the fairness panel (weights, aggregates,
# overlaps, fairness, the sweep) is read back from the workbooks written
# by this block, and the rule-12 pass at the end checks the solved outputs
# against optimality and closed-form invariants.
# =====================================================================
from scipy.optimize import minimize as _sp_minimize
from scipy.special import ndtr as _ndtr
import scipy as _scipy

_BIM_MU = np.array([7.1, 7.6, 6.8, 7.3, 4.7, 6.6, 7.0])   # eq:bim-panel-mu
_BIM_SD = np.array([1.2, 1.3, 1.1, 1.2, 1.3, 1.1, 1.2])   # eq:bim-panel-sigma
_BIM_N = len(_BIM_MU)
_BIM_RHO, _BIM_THETA, _BIM_KAPPA = 0.4, 0.2, 2          # ch6 sec:bim-data, eq:parabola-norm
_BIM_DELTAS = [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6]        # the sweep grid
_BIM_N_STARTS = 200
_BIM_FTOL = 1e-12
_BIM_MAXITER = 1000
_BIM_TIE_TOL = 1e-6      # starts whose objective lies within this of the best are counted as ties
_BIM_DISSENTER = 4       # expert 5 (0-based index)


def _bim_overlap(m1, s1, m2, s2):
    """A = int_R min{N(m1,s1^2), N(m2,s2^2)} dx in closed form.
    Equal spreads: 2*Phi(-|m1-m2|/(2 s)).  Otherwise the two densities cross
    at the roots of a quadratic; the narrower density is the larger one
    between the roots, so the minimum is the wider one there and the
    narrower one outside."""
    if abs(s1 - s2) < 1e-12:
        return float(2.0 * _ndtr(-abs(m1 - m2) / (2.0 * s1)))
    if s1 > s2:                      # make (m1, s1) the narrower density
        m1, s1, m2, s2 = m2, s2, m1, s1
    a = 1.0 / s1 ** 2 - 1.0 / s2 ** 2
    b = -2.0 * (m1 / s1 ** 2 - m2 / s2 ** 2)
    c = m1 ** 2 / s1 ** 2 - m2 ** 2 / s2 ** 2 - 2.0 * math.log(s2 / s1)
    disc = max(b * b - 4.0 * a * c, 0.0)
    r1 = (-b - math.sqrt(disc)) / (2.0 * a)
    r2 = (-b + math.sqrt(disc)) / (2.0 * a)
    x1, x2 = min(r1, r2), max(r1, r2)
    F1 = lambda x: _ndtr((x - m1) / s1)
    F2 = lambda x: _ndtr((x - m2) / s2)
    return float((F2(x2) - F2(x1)) + F1(x1) + (1.0 - F1(x2)))


def _bim_overlap_trapz(m1, s1, m2, s2, n=200001):
    """The same overlap by the trapezoid rule on a wide grid (check only)."""
    lo = min(m1 - 8 * s1, m2 - 8 * s2)
    hi = max(m1 + 8 * s1, m2 + 8 * s2)
    x = np.linspace(lo, hi, n)
    f1 = np.exp(-0.5 * ((x - m1) / s1) ** 2) / (s1 * math.sqrt(2 * math.pi))
    f2 = np.exp(-0.5 * ((x - m2) / s2) ** 2) / (s2 * math.sqrt(2 * math.pi))
    return float(_trapz(np.minimum(f1, f2), x))


def _bim_aggregate(w):
    return float(w @ _BIM_MU), float(w @ _BIM_SD)


def _bim_overlaps(w):
    m, s = _bim_aggregate(w)
    return np.array([_bim_overlap(_BIM_MU[i], _BIM_SD[i], m, s) for i in range(_BIM_N)])


def _bim_Abar(w):
    return float(_bim_overlaps(w).mean())


def _bim_V(w):
    return float(w @ _BIM_SD) ** 2


def _bim_Phi(w, return_util=False):
    A = _bim_overlaps(w)
    Phi, Ut = _fs_phi(A[None, :], _BIM_RHO, _BIM_THETA)   # kappa = 2 inside _fs_phi
    return (float(Phi[0]), Ut[0]) if return_util else float(Phi[0])


_BIM_CONS = ({"type": "eq", "fun": lambda w: float(w.sum() - 1.0)},)
_BIM_BNDS = [(0.0, 1.0)] * _BIM_N


def _bim_multistart(fun, rng, sense="max"):
    """Multi-start SLSQP over the simplex.  Draws _BIM_N_STARTS starting
    points from rng (Dirichlet(1,...,1)); returns (w_best, value, n_ties,
    n_converged).  The first start attaining the best value is kept."""
    sign = -1.0 if sense == "max" else 1.0
    starts = rng.dirichlet(np.ones(_BIM_N), size=_BIM_N_STARTS)
    best_w, best_v, vals = None, np.inf, []
    for w0 in starts:
        r = _sp_minimize(lambda w: sign * fun(w), w0, method="SLSQP",
                         bounds=_BIM_BNDS, constraints=_BIM_CONS,
                         options={"ftol": _BIM_FTOL, "maxiter": _BIM_MAXITER})
        w = np.clip(r.x, 0.0, 1.0)
        w = w / w.sum()
        v = sign * fun(w)
        vals.append(v)
        if v < best_v:
            best_v, best_w = v, w
    vals = np.asarray(vals)
    n_ties = int(np.sum(np.abs(vals - best_v) < _BIM_TIE_TOL))
    return best_w, sign * best_v, n_ties


print("\n-- Case I fairness panel: solving eq:bim-triobjective (seed %d, %d SLSQP starts per program) ..."
      % (NEW_SEED, _BIM_N_STARTS))
_bim_rng = np.random.default_rng(NEW_SEED)
_bim_draw_order = []

# ----- Algorithm 2.2: min and max of each objective over the simplex ----------
_bim_bounds = {}
for _name, _fun in (("Abar", _bim_Abar), ("V", _bim_V), ("Phi", _bim_Phi)):
    _wmin, _vmin, _tmin = _bim_multistart(_fun, _bim_rng, sense="min")
    _bim_draw_order.append("%s min" % _name)
    _wmax, _vmax, _tmax = _bim_multistart(_fun, _bim_rng, sense="max")
    _bim_draw_order.append("%s max" % _name)
    _bim_bounds[_name] = dict(min=_vmin, max=_vmax, argmin=_wmin, argmax=_wmax,
                              ties_min=_tmin, ties_max=_tmax)
    print("   %-4s in [%.6f, %.6f]" % (_name, _vmin, _vmax))
_bim_Amin, _bim_Amax = _bim_bounds["Abar"]["min"], _bim_bounds["Abar"]["max"]
_bim_Vmin, _bim_Vmax = _bim_bounds["V"]["min"], _bim_bounds["V"]["max"]
_bim_Pmin, _bim_Pmax = _bim_bounds["Phi"]["min"], _bim_bounds["Phi"]["max"]


def _bim_scalarized(w, delta):
    alpha, beta = 2.0 * (1.0 - delta) / 3.0, (1.0 - delta) / 3.0
    At = (_bim_Abar(w) - _bim_Amin) / (_bim_Amax - _bim_Amin)
    Vt = (_bim_V(w) - _bim_Vmin) / (_bim_Vmax - _bim_Vmin)
    Pt = (_bim_Phi(w) - _bim_Pmin) / (_bim_Pmax - _bim_Pmin)
    return alpha * At - beta * Vt + delta * Pt


# ----- the delta sweep ---------------------------------------------------------
_bim_rows, _bim_wrows, _bim_arows, _bim_sol = [], [], [], {}
for _d in _BIM_DELTAS:
    _w, _val, _ties = _bim_multistart(lambda w, d=_d: _bim_scalarized(w, d), _bim_rng, sense="max")
    _bim_draw_order.append("sweep delta=%.1f" % _d)
    _A = _bim_overlaps(_w)
    _P, _Ut = _bim_Phi(_w, return_util=True)
    _m, _s = _bim_aggregate(_w)
    _bim_sol[_d] = dict(w=_w, Abar=float(_A.mean()), Phi=_P, minA=float(_A.min()),
                        mu=_m, sd=_s, obj=_val, ties=_ties)
    _bim_rows.append({
        "delta": _d, "alpha": 2.0 * (1.0 - _d) / 3.0, "beta": (1.0 - _d) / 3.0,
        "consensus_Abar": float(_A.mean()), "fairness_Phibar": _P,
        "minimum_overlap": float(_A.min()),
        "argmin_overlap_expert": int(np.argmin(_A)) + 1,
        "objective": _val, "starts_at_best": _ties, "n_starts": _BIM_N_STARTS,
        "agg_mu": _m, "agg_sd": _s, "weight_on_dissenter": float(_w[_BIM_DISSENTER]),
    })
    _bim_wrows.append(dict({"delta": _d}, **{"w%d" % (i + 1): float(_w[i]) for i in range(_BIM_N)}))
    _bim_arows.append(dict({"delta": _d},
                           **{"A%d" % (i + 1): float(_A[i]) for i in range(_BIM_N)},
                           **{"Unorm%d" % (i + 1): float(_Ut[i]) for i in range(_BIM_N)}))
    print("   delta=%.1f  obj=%.6f  (%d/%d starts at best)  w=%s  agg=N(%.3f,%.3f^2)  Abar=%.4f Phi=%.4f minA=%.4f"
          % (_d, _val, _ties, _BIM_N_STARTS, np.round(_w, 4), _m, _s, _A.mean(), _P, _A.min()))

# closed-form overlap against the trapezoid rule at the sweep solutions
_bim_overlap_err = 0.0
for _d in _BIM_DELTAS:
    _m, _s = _bim_sol[_d]["mu"], _bim_sol[_d]["sd"]
    for _i in range(_BIM_N):
        _bim_overlap_err = max(_bim_overlap_err,
                               abs(_bim_overlap(_BIM_MU[_i], _BIM_SD[_i], _m, _s)
                                   - _bim_overlap_trapz(_BIM_MU[_i], _BIM_SD[_i], _m, _s)))
print("   closed-form overlap vs trapezoid at the sweep solutions: max |diff| = %.2e" % _bim_overlap_err)

_bim_solver_cfg = {
    "seed": NEW_SEED,
    "rng": "numpy.random.default_rng(202603), one generator for the whole block",
    "draw_order": " -> ".join(_bim_draw_order) + " (%d Dirichlet(1,...,1) starts each)" % _BIM_N_STARTS,
    "solver": "scipy.optimize.minimize(method='SLSQP') with bounds [0,1]^7 and the equality sum(w)=1",
    "scipy_version": _scipy.__version__, "numpy_version": np.__version__,
    "n_starts": _BIM_N_STARTS,
    "start_law": "uniform on the simplex, Dirichlet(1,...,1)",
    "ftol": _BIM_FTOL, "maxiter": _BIM_MAXITER,
    "tie_rule": "the first start attaining the highest objective is retained; starts_at_best counts starts within %g of it" % _BIM_TIE_TOL,
    "post_processing": "clip to [0,1] and renormalize to sum 1, then re-evaluate",
    "overlap_rule": "A_i = int_R min{f_i, f_QA} dx over the whole real line, closed form via the crossing points (def:consensus); checked against the trapezoid rule on [min mu-8sd, max mu+8sd] with 200001 points",
    "overlap_check_max_abs_diff": _bim_overlap_err,
    "consensus": "Abar = mean_i A_i", "confidence": "V = (w.sigma)^2 (def:confidence, Prop. qa-properties(iii))",
    "fairness": "Fehr-Schmidt on the overlap profile, divisor N-1 (def:ifcu), power normalization (eq:parabola-norm), Bonferroni (1,1) (def:collective-fairness)",
    "rho": _BIM_RHO, "vartheta": _BIM_THETA, "kappa": _BIM_KAPPA,
    "scalarization": "alpha*At - beta*Vt + delta*Pt, alpha = 2(1-delta)/3, beta = (1-delta)/3, min-max normalized objectives",
    "delta_grid": ", ".join("%.1f" % d for d in _BIM_DELTAS),
    "bounds_method": "min and max of each objective solved over the simplex by the same multi-start SLSQP (Algorithm 2.2)",
    "Abar_min": _bim_Amin, "Abar_max": _bim_Amax,
    "V_min": _bim_Vmin, "V_max": _bim_Vmax,
    "Phi_min": _bim_Pmin, "Phi_max": _bim_Pmax,
    "panel_mu": ", ".join("%.1f" % v for v in _BIM_MU),
    "panel_sigma": ", ".join("%.1f" % v for v in _BIM_SD),
    "synthetic": 1,
}
_bim_bounds_sheet = [
    {"objective": k, "min": v["min"], "max": v["max"],
     "argmin_w": ", ".join("%.4f" % x for x in v["argmin"]),
     "argmax_w": ", ".join("%.4f" % x for x in v["argmax"]),
     "starts_at_min": v["ties_min"], "starts_at_max": v["ties_max"]}
    for k, v in _bim_bounds.items()
]

# ---- Figure 6.4: the sweep ---------------------------------------------------
write("fig6-4_bim_tradeoff.xlsx", {
    "config": cfg(dict({
        "figure": "6.4", "label": "fig:bim-tradeoff",
        "x_label": "fairness weight delta", "y_label": "objective value",
        "ymin": 0.3, "ymax": 1.0, "title": "BIM fairness-consensus trade-off",
        "generator": "build_workbooks.py, Case I fairness-panel block (solved)",
    }, **_bim_solver_cfg)),
    "series": pd.DataFrame(_bim_rows),
    "weights": pd.DataFrame(_bim_wrows),
    "overlaps": pd.DataFrame(_bim_arows),
    "bounds": pd.DataFrame(_bim_bounds_sheet),
})

# ---- Figure 6.3: the seven experts and the two solved aggregates -------------
_bim_expert_rows = []
for _i in range(_BIM_N):
    _bim_expert_rows.append({
        "legend": "dissenter (expert 5)" if _i == _BIM_DISSENTER else "_nolegend_",
        "mu": float(_BIM_MU[_i]), "sigma": float(_BIM_SD[_i]), "weight": 1,
        "role": "expert_highlight" if _i == _BIM_DISSENTER else "expert",
        "linestyle": "solid"})
_bim_agg_rows = [
    {"legend": "aggregate, delta=0", "mu": _bim_sol[0.0]["mu"], "sigma": _bim_sol[0.0]["sd"],
     "weight": 1, "role": "aggregate", "linestyle": "solid"},
    {"legend": "aggregate, delta=0.5", "mu": _bim_sol[0.5]["mu"], "sigma": _bim_sol[0.5]["sd"],
     "weight": 1, "role": "aggregate", "linestyle": "dashed"},
]
write("fig6-3_bim_densities.xlsx", {
    "config": cfg({
        "figure": "6.3", "label": "fig:bim-densities",
        "x_label": "maturity score", "y_label": "density",
        "domain_min": 0, "domain_max": 10, "ymax": 0.42,
        "draw_linear_pool": 0, "title": "BIM maturity: experts and aggregates",
        "generator": "build_workbooks.py, Case I fairness-panel block (solved)",
        "seed": NEW_SEED,
        "experts": "stated inputs eq:bim-panel-mu / eq:bim-panel-sigma (no random draws)",
        "aggregates": "N(w.mu, (w.sigma)^2) at the solved w(delta=0) and w(delta=0.5) of fig6-4_bim_tradeoff.xlsx",
        "solver_settings": "see the config sheet of fig6-4_bim_tradeoff.xlsx (same block, same seed)",
        "synthetic": 1,
    }),
    "gaussians": _bim_expert_rows + _bim_agg_rows,
    "aggregates": [
        dict({"delta": d, "mu": _bim_sol[d]["mu"], "sigma": _bim_sol[d]["sd"]},
             **{"w%d" % (i + 1): float(_bim_sol[d]["w"][i]) for i in range(_BIM_N)})
        for d in (0.0, 0.5)],
    "annotations": [{"text": "dissenter", "x": 4.7, "y": 0.31, "ha": "center"}],
})

# ---- Table 6.9: the two solutions compared -------------------------------------
_bim_tab_rows, _bim_tab_printed = [], []
for _q, _key, _nd in (("aggregate distribution", None, 2),
                      ("weight on dissenter (exp 5)", "wdis", 3),
                      ("minimum overlap", "minA", 3),
                      ("mean overlap (consensus)", "Abar", 3),
                      ("collective fairness", "Phi", 3)):
    _vals, _prt = {}, {}
    for _col, _d in (("consensus_confidence_d0", 0.0), ("fairness_weighted_d0.5", 0.5)):
        _S = _bim_sol[_d]
        if _key is None:
            _vals[_col] = "N(%.6f, %.6f^2)" % (_S["mu"], _S["sd"])
            _prt[_col] = "N(%.2f, %.2f^2)" % (round(_S["mu"], 2), round(_S["sd"], 2))
        else:
            _v = float(_S["w"][_BIM_DISSENTER]) if _key == "wdis" else float(_S[_key])
            _vals[_col] = _v
            _prt[_col] = round(_v, _nd)
    _bim_tab_rows.append(dict({"quantity": _q}, **_vals))
    _bim_tab_printed.append(dict({"quantity": _q}, **_prt))
write("tab6-9_bim_results.xlsx", {
    "config": cfg(dict({
        "table": "6.9", "label": "tab:bim",
        "generator": "build_workbooks.py, Case I fairness-panel block (solved)",
        "source": "the delta = 0 and delta = 0.5 rows of the solved sweep in fig6-4_bim_tradeoff.xlsx",
        "rounding": "table_6_9 carries full precision; table_6_9_printed rounds as the book prints (aggregate to 2 decimals, the rest to 3)",
    }, **_bim_solver_cfg)),
    "table_6_9": _bim_tab_rows,
    "table_6_9_printed": _bim_tab_printed,
})


# =====================================================================
# FIGURE 4.5  Scalability of the hierarchical paradigm (fig4-3_scalability)
#   Pairwise-interaction counts from the stated formulas -- no timings.
#   Flat program: N(N-1) ordered pairs.  Two-stage program with balanced
#   subgroups at K* = round((N^2/2)^(1/3)) ~ N^(2/3):
#   sum_k n_k(n_k-1) intra-group pairs + K(K-1) inter-group pairs.
# =====================================================================
def _hier_count(N):
    K = int(round((N * N / 2.0) ** (1.0 / 3.0)))
    K = max(1, min(K, N))
    base, rem = divmod(N, K)
    sizes = [base + 1] * rem + [base] * (K - rem)
    return K, sum(n * (n - 1) for n in sizes) + K * (K - 1)


_Ns = np.unique(np.round(np.logspace(math.log10(10), math.log10(10000), 28)).astype(int))
_scal_rows = []
for _N in _Ns:
    _K, _hc = _hier_count(int(_N))
    _scal_rows.append({"N": int(_N), "flat_pairwise": int(_N) * (int(_N) - 1),
                       "K_star": _K, "hier_pairwise": _hc})
write("fig4-3_scalability.xlsx", {
    "config": cfg({
        "figure": "4.3", "label": "fig:scalability",
        "seed": NEW_SEED, "synthetic": 1,
        "x_label": "panel size $N$",
        "y_label": "pairwise interaction count",
        "flat_legend": "flat single-stage program, $\\Theta(N^2)$",
        "hier_legend": "hierarchical two-stage program, $K^{*}\\propto N^{2/3}$, $\\Theta(N^{4/3})$",
        "note": ("interaction counts computed from the stated formulas -- "
                 "flat N(N-1) ordered pairs vs sum_k n_k(n_k-1) + K(K-1) "
                 "with balanced subgroups at K* = round((N^2/2)^(1/3)); "
                 "normalized cost units (counts, not timings)"),
    }),
    "series": pd.DataFrame(_scal_rows),
})


# =====================================================================
# FIGURE 5.3  Leave-one-out contributions of the synthetic human-machine
#             panel of Example ex:hmpanel  (fig5-3_loo)
#             FIGURE 5.2 and TABLE 5.3 are derived from the same block.
#
# The panel of tab:hmpanel is GENERATED and SOLVED here, from the stated
# inputs (seed 202603, the outcome model and its constants below, the
# penalties lambda_G and lambda_C) by the formulas the book states:
#   * objective  eq:convex-reformulation, mean CRPS + lambda_G G + lambda_C C,
#     with G the Gini coefficient of the weight vector and C the
#     representativeness penalty (squared quantile deviation from the
#     equal-weight aggregate, continuous limit, see _hm_program);
#   * solver     Algorithm 4.2 (alg:subgradient) exactly as printed --
#     equal-weight start, analytic subgradient with the sign(0) = 0 tie
#     rule for the Gini kinks, diminishing steps eta_r = eta0/(1 + r/tau),
#     best iterate returned, stop when |w(r) - w(r-1)|_inf < tol and
#     r >= r_min; every solve is then VERIFIED against a multistart SLSQP
#     solve of the same objective (scipy) and the build aborts if the two
#     disagree (_HM_VERIFY tolerances);
#   * leave-one-out re-solves (def:loo) with the same solver and settings;
#   * the calibration/resolution split (prop:loo-decomposition) by the
#     Hersbach (2000) decomposition on the L = 19 quantile representation
#     of every aggregate, held identical across the full and the
#     leave-one-out aggregates (_hersbach_X, convention documented there).
# No printed number is typed anywhere in this block: Table 5.3 is written
# from the rounded solved values, and the rule-12 self-checks at the end
# of this file test the written workbooks against invariants (weights on
# the simplex, objective recomputed from the stored data, optimality
# certificate, exact channel identity), never against typed constants.
#
# Outcome model:  y_t = h_t + sum_i u_{i,t} + m_t + sum_k v_{k,t} + g_t + eps_t
# where h is seen by the five humans (each with its own unique signal
# u_i), m by all machines (each calibrated machine with its own unique
# signal v_k), and g only by the two overconfident machines M4/M5, whose
# reported predictive scale is shrunk far below their honest one.  Every
# forecast is Gaussian, so the quantile-averaged aggregate is Gaussian
# with mean sum(w mu) and sd sum(w sigma), and its CRPS has the exact
# closed form of _crps_gauss (no grid, no truncation).
# =====================================================================
from scipy.special import ndtr as _ndtr          # exact standard normal cdf
from scipy.optimize import minimize as _sp_minimize


def _crps_gauss(mu, sig, y):
    """Exact CRPS of N(mu, sig^2) against y (closed form, exact normal cdf)."""
    z = (y - mu) / sig
    return sig * (z * (2.0 * _ndtr(z) - 1.0) + 2.0 * _npdf(z) - 1.0 / math.sqrt(math.pi))


def _hersbach_X(X, y):
    """Hersbach (2000) decomposition of a forecast sequence represented by
    its T x L matrix X of sorted quantiles at the levels k/(L+1), k = 1..L.
    CONVENTION (Hersbach's original ensemble treatment, recorded in the
    workbook config and stated in the book): the L quantiles are read as
    an L-member ensemble; interior bin i (between members i and i+1) has
    nominal level i/L; the two outer regions, below member 1 and above
    member L, are scored as outlier bins at nominal levels 0 and 1.  The
    same routine is applied to every sequence (full aggregate,
    leave-one-out aggregates, individual experts, climatology), which is
    the identical-convention requirement of prop:loo-decomposition.
    Returns (crps_h, REL, POT) with crps_h = REL + POT exactly."""
    X = np.asarray(X, float)
    T, L = X.shape
    rel = 0.0
    pot = 0.0
    for i in range(1, L):
        x1, x2 = X[:, i - 1], X[:, i]
        alpha = np.where(y > x2, x2 - x1, np.where(y > x1, y - x1, 0.0))
        beta = np.where(y < x1, x2 - x1, np.where(y < x2, x2 - y, 0.0))
        ab, bb = alpha.mean(), beta.mean()
        g = ab + bb
        p = i / float(L)
        if g > 0:
            o = bb / g
            rel += g * (o - p) ** 2
            pot += g * o * (1.0 - o)
    below = y < X[:, 0]
    O0 = below.mean()
    if O0 > 0:
        g0 = np.where(below, X[:, 0] - y, 0.0).mean() / O0
        rel += g0 * O0 ** 2
        pot += g0 * O0 * (1.0 - O0)
    above = y > X[:, -1]
    OL = above.mean()
    if OL > 0:
        gL = np.where(above, y - X[:, -1], 0.0).mean() / OL
        rel += gL * OL ** 2
        pot += gL * OL * (1.0 - OL)
    return rel + pot, rel, pot


def _hersbach(mu, sig, y, zlev):
    """_hersbach_X for a Gaussian sequence N(mu_t, sig_t^2) read through its
    L quantiles mu_t + sig_t z_k, z_k the standard normal quantiles of the
    levels k/(L+1)."""
    X = mu[:, None] + sig[:, None] * zlev[None, :]
    return _hersbach_X(X, y)


# generator constants (stated inputs; the seed drives all draws).  The
# outcome decomposes into a human-shared signal h, one unique signal u_i
# per human, a machine-shared signal m, one unique signal v_k per
# calibrated machine, a signal g seen only by the two overconfident
# machines, and an irreducible eps.  _HM_SCALE multiplies every scale
# below; since the CRPS is 1-homogeneous it sets the level of every score
# and was chosen so that the human-only aggregate's mean CRPS prints as
# 0.45 (the relative gain and the weight shares do not depend on it).
_HM_SCALE = 0.5567
_HM_SIG = {"h": 1.00, "u": 0.30, "m": 0.85, "v": 0.35, "g": 0.65,
           "eps": 0.60, "tau_H": 0.30, "tau_M": 0.22}
_HM_MULT = np.array([1.00, 1.03, 0.98, 1.05, 1.01, 0.99, 1.03, 1.00, 0.36, 0.32])
_HM_T = 250
# Algorithm 4.2 settings (recorded in the workbook config)
_HM_ALG = {"eta0": 0.5, "tau": 100.0, "tol": 1e-6, "r_min": 1000, "r_max": 200000}
# SLSQP verification of every Algorithm 4.2 solve: equal-weight start plus
# n_random Dirichlet(1) starts drawn from default_rng(seed); the build
# aborts if the best SLSQP value beats the returned iterate by more than
# obj_gap or the two weight vectors differ by more than w_gap (inf norm)
_HM_VERIFY = {"n_random": 30, "seed": NEW_SEED, "ftol": 1e-14, "maxiter": 2000,
              "obj_gap": 1e-8, "w_gap": 1e-3}


def _hm_generate():
    """Draw order under default_rng(202603): h (T), u (T x 5), m (T),
    v (T x 3), g (T), eps (T), then the forecast noises tau_H (T) for
    H1..H5, tau_M (T) for M1..M3, tau_M (T) for M4, M5, in that order."""
    rng = np.random.default_rng(NEW_SEED)
    T = _HM_T
    c = _HM_SCALE
    s = {k: v * c for k, v in _HM_SIG.items()}
    h = rng.normal(0.0, s["h"], T)
    u = rng.normal(0.0, s["u"], (T, 5))
    m = rng.normal(0.0, s["m"], T)
    v = rng.normal(0.0, s["v"], (T, 3))
    g = rng.normal(0.0, s["g"], T)
    eps = rng.normal(0.0, s["eps"], T)
    y = h + u.sum(axis=1) + m + v.sum(axis=1) + g + eps
    ids = ["H1", "H2", "H3", "H4", "H5", "M1", "M2", "M3", "M4", "M5"]
    groups = ["human"] * 5 + ["machine calibrated"] * 3 + ["machine overconfident"] * 2
    vary = (s["h"] ** 2 + 5 * s["u"] ** 2 + s["m"] ** 2 + 3 * s["v"] ** 2
            + s["g"] ** 2 + s["eps"] ** 2)
    # honest predictive scales for each information set
    sd_H = math.sqrt(vary - s["h"] ** 2 - s["u"] ** 2 + s["tau_H"] ** 2)
    sd_M = math.sqrt(vary - s["m"] ** 2 - s["v"] ** 2 + s["tau_M"] ** 2)
    sd_O = math.sqrt(vary - s["m"] ** 2 - s["g"] ** 2 + s["tau_M"] ** 2)
    mult = _HM_MULT
    MU = np.empty((T, 10))
    SD = np.empty(10)
    for i in range(5):
        MU[:, i] = h + u[:, i] + rng.normal(0.0, s["tau_H"], T)
        SD[i] = mult[i] * sd_H
    for i in range(5, 8):
        MU[:, i] = m + v[:, i - 5] + rng.normal(0.0, s["tau_M"], T)
        SD[i] = mult[i] * sd_M
    for i in range(8, 10):
        MU[:, i] = m + g + rng.normal(0.0, s["tau_M"], T)
        SD[i] = mult[i] * sd_O
    params = {"T": T, "scale": c,
              "outcome_model": "y_t = h_t + sum_i u_it + m_t + sum_k v_kt + g_t + eps_t",
              "sig_h": s["h"], "sig_u": s["u"],
              "sig_m": s["m"], "sig_v": s["v"], "sig_g": s["g"],
              "sig_eps": s["eps"], "tau_H": s["tau_H"], "tau_M": s["tau_M"],
              "sd_honest_human": sd_H, "sd_honest_machine": sd_M,
              "sd_honest_overconf": sd_O,
              "sd_multipliers": ",".join("%.2f" % v for v in mult),
              "forecast_family": "Gaussian N(mu_it, sd_i^2), sd_i = multiplier_i x honest sd",
              "draw_order": ("default_rng(202603): h, u, m, v, g, eps, "
                             "then noise tau_H for H1..H5, tau_M for M1..M3, tau_M for M4..M5")}
    return y, MU, SD, ids, groups, mult, params


def _hm_program(y, MU, SD, idx, lam_G, lam_C):
    """The convex program eq:convex-reformulation restricted to the experts
    in idx, as three closures: terms(w) -> (objective, mean CRPS, G, C),
    obj(w), and subgrad(w) (analytic, sign(0) = 0 at Gini ties).
      mean CRPS : exact Gaussian closed form of the QA aggregate
                  N(sum w mu, (sum w sd)^2), averaged over t
      G         : Gini of w, (1/(2 n^2 wbar)) sum_ij |w_i - w_j|, wbar = 1/n
      C         : (1/T) sum_t E_p [q_t,p(w) - q_t,p(w0)]^2 with w0 = 1/n
                  the equal-weight vector; for Gaussians q_t,p = mu_t + sd z_p,
                  so C = mean_t (dmu_t)^2 + dsd^2 E z^2 with E z^2 = 1 in
                  the continuous (untruncated) limit used here
    Subgradient: d CRPS_t/d mu_a = 1 - 2 Phi(z_t), d CRPS_t/d sd_a =
    2 phi(z_t) - 1/sqrt(pi), z_t = (y_t - mu_a)/sd_a, chained through
    mu_a = mu w, sd_a = sd . w; d G/d w_i = (1/(n^2 wbar)) sum_j sign(w_i - w_j);
    d C/d w_i = 2 mean_t dmu_t mu_it + 2 dsd sd_i."""
    mu = MU[:, idx]
    sd = SD[idx]
    n = len(idx)
    T = len(y)
    w0 = np.full(n, 1.0 / n)
    mu0, sd0 = mu @ w0, float(sd @ w0)
    sqrt_pi = math.sqrt(math.pi)

    def terms(w):
        Ma = mu @ w
        Sa = float(sd @ w)
        crps = float(_crps_gauss(Ma, Sa, y).mean())
        gini = _gini_vec(w)
        Cw = float(((Ma - mu0) ** 2).mean() + (Sa - sd0) ** 2)
        return crps + lam_G * gini + lam_C * Cw, crps, gini, Cw

    def obj(w):
        return terms(w)[0]

    def subgrad(w):
        Ma = mu @ w
        Sa = float(sd @ w)
        z = (y - Ma) / Sa
        d_mu = 1.0 - 2.0 * _ndtr(z)
        d_sd = 2.0 * _npdf(z) - 1.0 / sqrt_pi
        g_fid = (d_mu @ mu) / T + d_sd.mean() * sd
        sgn = np.sign(w[:, None] - w[None, :])          # sign(0) = 0: the tie rule
        g_G = sgn.sum(axis=1) / (n * n * (1.0 / n))
        g_C = 2.0 * ((Ma - mu0) @ mu) / T + 2.0 * (Sa - sd0) * sd
        return g_fid + lam_G * g_G + lam_C * g_C

    return {"terms": terms, "obj": obj, "subgrad": subgrad, "n": n}


def _hm_alg42(prog, eta0, tau, tol, r_min, r_max):
    """Algorithm 4.2 (alg:subgradient) as printed: projected subgradient
    descent from the equal-weight vector with eta_r = eta0/(1 + r/tau),
    incumbent-best bookkeeping, stop when |w(r) - w(r-1)|_inf < tol and
    r >= r_min.  r_max is a safety cap only; hitting it aborts the build."""
    n = prog["n"]
    w = np.full(n, 1.0 / n)
    L_min, w_best = prog["obj"](w), w.copy()
    r = 0
    while True:
        g = prog["subgrad"](w)
        eta = eta0 / (1.0 + r / tau)
        w_new = _project_simplex(w - eta * g)[0]
        L_new = prog["obj"](w_new)
        if L_new < L_min:
            L_min, w_best = L_new, w_new.copy()
        dw = float(np.abs(w_new - w).max())
        w = w_new
        r += 1
        if dw < tol and r >= r_min:
            break
        if r >= r_max:
            raise RuntimeError("Algorithm 4.2 hit the iteration cap %d (last dw %.2e)"
                               % (r_max, dw))
    return w_best, L_min, r, dw


def _hm_slsqp(prog, n_random, seed, ftol, maxiter):
    """Multistart SLSQP on the same objective (verification only)."""
    n = prog["n"]
    rng = np.random.default_rng(seed)
    starts = [np.full(n, 1.0 / n)] + [rng.dirichlet(np.ones(n)) for _ in range(n_random)]
    best = None
    for s in starts:
        res = _sp_minimize(prog["obj"], s, method="SLSQP", bounds=[(0.0, 1.0)] * n,
                           constraints=[{"type": "eq", "fun": lambda w: w.sum() - 1.0}],
                           options={"ftol": ftol, "maxiter": maxiter})
        if best is None or res.fun < best.fun:
            best = res
    w = np.clip(best.x, 0.0, None)
    return w / w.sum(), float(best.fun)


_hm_solver_log = []


def _hm_solve(y, MU, SD, idx, lam_G, lam_C, tag):
    """Minimize mean CRPS + lam_G G(w) + lam_C C(w) over the simplex of the
    experts in idx by Algorithm 4.2, verify against multistart SLSQP, log
    both, and return (w, mean CRPS, aggregate mu_t, aggregate sd)."""
    prog = _hm_program(y, MU, SD, idx, lam_G, lam_C)
    w, L_alg, r, dw = _hm_alg42(prog, _HM_ALG["eta0"], _HM_ALG["tau"], _HM_ALG["tol"],
                                _HM_ALG["r_min"], _HM_ALG["r_max"])
    w_chk, L_chk = _hm_slsqp(prog, _HM_VERIFY["n_random"], _HM_VERIFY["seed"],
                             _HM_VERIFY["ftol"], _HM_VERIFY["maxiter"])
    gap = L_alg - L_chk
    w_gap = float(np.abs(w - w_chk).max())
    assert gap <= _HM_VERIFY["obj_gap"], \
        "%s: Algorithm 4.2 value %.10f exceeds the SLSQP value %.10f by %.2e" % (tag, L_alg, L_chk, gap)
    assert w_gap <= _HM_VERIFY["w_gap"], \
        "%s: Algorithm 4.2 weights differ from SLSQP by %.2e (inf norm)" % (tag, w_gap)
    L_w, crps, gini, Cw = prog["terms"](w)
    _hm_solver_log.append({
        "solve": tag, "n_experts": len(idx), "experts": ",".join(str(i) for i in idx),
        "alg42_iterations": r, "alg42_last_dw_inf": dw,
        "objective_alg42": L_alg, "objective_slsqp": L_chk, "objective_gap": gap,
        "weights_inf_gap_vs_slsqp": w_gap,
        "mean_crps": crps, "gini_G": gini, "representativeness_C": Cw,
        "weights": ",".join("%.8f" % v for v in w)})
    mu_a, sd_a = MU[:, idx] @ w, float(SD[idx] @ w)
    return w, crps, mu_a, sd_a


print("\n-- generating and solving the ex:hmpanel study "
      "(fig5-3_loo.xlsx, fig5-2_calibration_sharpness.xlsx, tab5-3_hm_panel.xlsx) ...")
_y, _MU, _SD, _ids, _hm_groups, _mult, _hm_params = _hm_generate()
_LAM_G, _LAM_C = 0.010 * _HM_SCALE, 0.080 / _HM_SCALE
_all = list(range(10))
_hum = list(range(5))
_w_full, _crps_full, _mua_full, _sda_full = _hm_solve(_y, _MU, _SD, _all, _LAM_G, _LAM_C, "full panel")
_w_hum, _crps_hum, _mua_hum, _sda_hum = _hm_solve(_y, _MU, _SD, _hum, _LAM_G, _LAM_C, "human-only")
_WH = float(_w_full[:5].sum())
_WM = float(_w_full[5:].sum())
_gain_pct = 100.0 * (_crps_full / _crps_hum - 1.0)

# decomposition grid: L = 19 levels k/20, the same for every sequence
_L_LEV = 19
_hm_plev = np.arange(1, _L_LEV + 1) / (_L_LEV + 1.0)
_zlev = _norm_ppf(_hm_plev)
_ch_full, _rel_full, _pot_full = _hersbach(_mua_full, np.full(len(_y), _sda_full), _y, _zlev)
_ch_hum, _rel_hum, _pot_hum = _hersbach(_mua_hum, np.full(len(_y), _sda_hum), _y, _zlev)
# uncertainty on the SAME grid and convention: the sample climatology
# represented by the empirical outcome quantiles at the 19 levels (numpy
# linear interpolation), scored by the same routine; UNC is its potential
# CRPS, so the climatology has resolution exactly zero
_X_clim = np.tile(np.quantile(_y, _hm_plev), (len(_y), 1))
_ch_clim, _rel_clim, _pot_clim = _hersbach_X(_X_clim, _y)
_UNC_grid = float(_pot_clim)
_U_cont = float(0.5 * np.abs(_y[:, None] - _y[None, :]).mean())   # continuous reference only

# leave-one-out re-solves (def:loo, re-optimized construction), split by
# prop:loo-decomposition on the L = 19 grid; the binning-sensitivity grid
# of rem:binning-sensitivity re-evaluates the SAME solved aggregates at
# other L (the solve does not depend on L)
_L_SENS = [9, 19, 39, 99]
_zsens = {L: _norm_ppf(np.arange(1, L + 1) / (L + 1.0)) for L in _L_SENS}
_full_sens = {L: _hersbach(_mua_full, np.full(len(_y), _sda_full), _y, _zsens[L]) for L in _L_SENS}
_loo_rows = []
_sens_rows = []
for _i in range(10):
    _sub = [j for j in _all if j != _i]
    _w_i, _crps_i, _mua_i, _sda_i = _hm_solve(_y, _MU, _SD, _sub, _LAM_G, _LAM_C, "leave-out " + _ids[_i])
    _ch_i, _rel_i, _pot_i = _hersbach(_mua_i, np.full(len(_y), _sda_i), _y, _zlev)
    _d_cal = _rel_i - _rel_full                 # eq:loo-split-cal
    _d_res = _pot_i - _pot_full                 # eq:loo-split-res (UNC cancels)
    _loo_rows.append({
        "id": _ids[_i], "group": _hm_groups[_i],
        "weight_full": float(_w_full[_i]),
        "delta_cal": float(_d_cal), "delta_res": float(_d_res),
        "delta_total": float(_ch_i - _ch_full),       # step-score total = cal + res exactly
        "delta_cont_defloo": float(_crps_i - _crps_full),   # def:loo continuous mean-CRPS difference
        "crps_loo_hersbach": float(_ch_i),
        "crps_loo_continuous": float(_crps_i),
    })
    for _L in _L_SENS:
        _cL, _rL, _pL = _hersbach(_mua_i, np.full(len(_y), _sda_i), _y, _zsens[_L])
        _cF, _rF, _pF = _full_sens[_L]
        _sens_rows.append({"id": _ids[_i], "L": _L,
                           "delta_cal": float(_rL - _rF), "delta_res": float(_pL - _pF),
                           "delta_total": float(_cL - _cF)})

# per-expert individual reliability / potential CRPS (Figure 5.2 reads these)
_ind_rows = []
for _i in range(10):
    _c_i, _r_i, _p_i = _hersbach(_MU[:, _i], np.full(len(_y), _SD[_i]), _y, _zlev)
    _ind_rows.append({"id": _ids[_i], "group": _hm_groups[_i],
                      "REL_i": float(_r_i), "POT_i": float(_p_i),
                      "RES_i": float(_UNC_grid - _p_i),
                      "crps_i_hersbach": float(_c_i),
                      "crps_i_continuous": float(_crps_gauss(_MU[:, _i], _SD[_i], _y).mean()),
                      "reported_sd": float(_SD[_i]),
                      "scale_multiplier": float(_mult[_i])})

# sign stability across the binning grid (rem:binning-sensitivity)
_sens_df = pd.DataFrame(_sens_rows)


def _sign_stable(col):
    out = {}
    for _id in _ids:
        v = _sens_df.loc[_sens_df["id"] == _id, col].to_numpy(float)
        out[_id] = bool(len(set(np.sign(v))) == 1)
    return out


_stab_tot = _sign_stable("delta_total")
_stab_cal = _sign_stable("delta_cal")
_stab_res = _sign_stable("delta_res")
_unstable_total = [k for k in _ids if not _stab_tot[k]]


def _sv(eid, L, col):
    m = (_sens_df["id"] == eid) & (_sens_df["L"] == L)
    return float(_sens_df.loc[m, col].iloc[0])


# which L keep "H3-H5 chiefly resolution" (res > cal), "M1-M3 chiefly
# calibration" (cal > res), and "M4, M5 in the (-, +) cell"
_L_h3h5_res = [L for L in _L_SENS if all(
    _sv(k, L, "delta_res") > _sv(k, L, "delta_cal") for k in ("H3", "H4", "H5"))]
_L_m1m3_cal = [L for L in _L_SENS if all(
    _sv(k, L, "delta_cal") > _sv(k, L, "delta_res") for k in ("M1", "M2", "M3"))]
_L_m4m5_cell = [L for L in _L_SENS if all(
    _sv(k, L, "delta_cal") < 0 and _sv(k, L, "delta_res") > 0 for k in ("M4", "M5"))]

print("   hm panel: human-only %.6f  collaborative %.6f  gain %.2f%%  W_H %.4f  W_M %.4f"
      % (_crps_hum, _crps_full, _gain_pct, _WH, _WM))
for _r in _loo_rows:
    print("   loo %-3s cal %+.6f res %+.6f tot %+.6f defloo %+.6f  w %.4f"
          % (_r["id"], _r["delta_cal"], _r["delta_res"], _r["delta_total"],
             _r["delta_cont_defloo"], _r["weight_full"]))
print("   sign-unstable totals across L=%s: %s" % (_L_SENS, _unstable_total))
print("   UNC on grid %.6f (climatology REL %.2e), continuous U %.6f" % (_UNC_grid, _rel_clim, _U_cont))

# the design invariant of the example (what Figure 5.3 is built to show):
# the two overconfident machines sit in the (-, +) cell of tab:loo-decomposition
for _r in _loo_rows[8:]:
    assert _r["delta_cal"] < 0 and _r["delta_res"] > 0, \
        "overconfident machine %s left the (-,+) cell: %r" % (_r["id"], _r)

write("fig5-3_loo.xlsx", {
    "config": cfg({
        "figure": "5.3", "label": "fig:loo-chart",
        "example": "ex:hmpanel (Section 5.5)",
        "synthetic": 1, "seed": NEW_SEED,
        "T": _hm_params["T"], "n_human": 5, "n_machine": 5,
        "lambda_G": _LAM_G, "lambda_C": _LAM_C,
        "lambda_G_rule": "0.010 x scale", "lambda_C_rule": "0.080 / scale",
        "objective": ("eq:convex-reformulation: mean exact Gaussian CRPS of the QA aggregate "
                      "+ lambda_G Gini(w) + lambda_C C(w); C in the continuous limit (E z^2 = 1), "
                      "no grid and no truncation enter the objective"),
        "solver": "Algorithm 4.2 (alg:subgradient), projected subgradient descent",
        "solver_start": "equal weights 1/N (one start; the program is convex)",
        "solver_step_schedule": "eta_r = %.3g / (1 + r / %.3g)" % (_HM_ALG["eta0"], _HM_ALG["tau"]),
        "solver_subgradient": ("analytic (closed-form CRPS, Gini, C derivatives); "
                               "tie rule sign(0) = 0 at Gini kinks"),
        "solver_returned_iterate": "best iterate visited (incumbent), as printed",
        "solver_tolerance": _HM_ALG["tol"],
        "solver_r_min": _HM_ALG["r_min"],
        "solver_r_max_cap": _HM_ALG["r_max"],
        "solver_projection": "Euclidean projection onto the simplex (sort-based)",
        "normal_cdf": "scipy.special.ndtr (exact)",
        "verification": ("every solve re-run by SLSQP (scipy) from the equal-weight start plus %d "
                         "Dirichlet(1) starts under default_rng(%d), ftol %.0e; build aborts if the "
                         "Algorithm 4.2 value exceeds the SLSQP value by more than %.0e or the weights "
                         "differ by more than %.0e (inf norm); see sheet solver_log"
                         % (_HM_VERIFY["n_random"], _HM_VERIFY["seed"], _HM_VERIFY["ftol"],
                            _HM_VERIFY["obj_gap"], _HM_VERIFY["w_gap"])),
        "loo_construction": "re-optimized (def:loo): the program is re-solved on each reduced panel with the same solver and settings",
        "human_only_row": "the same program solved on the human subpanel alone (Gini and C on the reduced panel)",
        "hersbach_levels_L": _L_LEV,
        "hersbach_levels": "k/(L+1), k = 1..L, standard normal quantiles of the Gaussian aggregate",
        "hersbach_convention": ("Hersbach (2000) L-member ensemble: interior bin i at nominal level i/L; "
                                "the two outer regions scored as outlier bins at nominal levels 0 and 1; "
                                "identical routine for every sequence"),
        "uncertainty_UNC_grid": _UNC_grid,
        "uncertainty_note": ("potential CRPS of the sample climatology represented by the empirical "
                             "outcome quantiles at the same L levels (numpy linear interpolation), "
                             "same routine and convention; climatology REL %.3e, total %.6f; "
                             "continuous 0.5 E|y - y'| = %.6f for reference" % (_rel_clim, _ch_clim, _U_cont)),
        "binning_sensitivity_L": ",".join(str(L) for L in _L_SENS),
        "total_sign_unstable_across_L": ",".join(_unstable_total) if _unstable_total else "none",
        "L_with_H3H5_chiefly_resolution": ",".join(str(L) for L in _L_h3h5_res),
        "L_with_M1M3_chiefly_calibration": ",".join(str(L) for L in _L_m1m3_cal),
        "L_with_M4M5_in_minus_plus_cell": ",".join(str(L) for L in _L_m4m5_cell),
        "x_label": "leave-one-out contribution $\\Delta_i$ to the mean CRPS",
        "cal_legend": "calibration channel $\\Delta_i^{\\mathrm{cal}}$",
        "res_legend": "resolution channel $\\Delta_i^{\\mathrm{res}}$",
        "tot_legend": "total $\\Delta_i$ (step score)",
        "note": ("panel generated and convex program solved here by Algorithm 4.2; "
                 "decomposition = Hersbach on the L-quantile representation, identical "
                 "convention for full and leave-one-out aggregates; the plotted total is "
                 "the step-function score difference, which equals Delta_cal + Delta_res "
                 "exactly; the def:loo continuous difference is the column delta_cont_defloo"),
    }),
    "generator_params": cfg({k: v for k, v in _hm_params.items()}),
    "experts": pd.DataFrame({
        "id": _ids, "group": _hm_groups,
        "signal": (["h+u_i"] * 5 + ["m+v_k"] * 3 + ["m+g"] * 2),
        "scale_multiplier": _mult,
        "reported_sd": _SD,
    }),
    "outcomes": pd.DataFrame({"t": np.arange(1, len(_y) + 1), "y": _y}),
    "forecast_mu": pd.DataFrame(_MU, columns=_ids),
    "loo": pd.DataFrame(_loo_rows),
    "individual": pd.DataFrame(_ind_rows),
    "binning_sensitivity": _sens_df,
    "solver_log": pd.DataFrame(_hm_solver_log),
    "results": pd.DataFrame([
        {"quantity": "human-only mean CRPS", "value": _crps_hum,
         "printed": round(_crps_hum, 2)},
        {"quantity": "collaborative mean CRPS", "value": _crps_full,
         "printed": round(_crps_full, 2)},
        {"quantity": "human weight share W_H", "value": _WH, "printed": round(_WH, 2)},
        {"quantity": "machine weight share W_M", "value": _WM, "printed": round(_WM, 2)},
        {"quantity": "CRPS gain (collab vs human-only, pct)",
         "value": _gain_pct, "printed": round(_gain_pct)},
        {"quantity": "full-panel Hersbach REL", "value": _rel_full, "printed": round(_rel_full, 3)},
        {"quantity": "full-panel Hersbach POT", "value": _pot_full, "printed": round(_pot_full, 3)},
        {"quantity": "full-panel Hersbach CRPS", "value": _ch_full, "printed": round(_ch_full, 3)},
        {"quantity": "human-only Hersbach CRPS", "value": _ch_hum, "printed": round(_ch_hum, 3)},
        {"quantity": "uncertainty UNC on grid", "value": _UNC_grid, "printed": round(_UNC_grid, 3)},
        {"quantity": "full-panel objective", "value": _hm_solver_log[0]["objective_alg42"],
         "printed": round(_hm_solver_log[0]["objective_alg42"], 4)},
        {"quantity": "human-only objective", "value": _hm_solver_log[1]["objective_alg42"],
         "printed": round(_hm_solver_log[1]["objective_alg42"], 4)},
    ]),
    "weights": pd.DataFrame({"id": _ids, "weight_full_panel": _w_full,
                             "weight_human_only": list(_w_hum) + [0.0] * 5}),
})

# ---- TABLE 5.3 (tab:hmpanel): the rounded outputs of the solve above -------
write("tab5-3_hm_panel.xlsx", {
    "table_5_3": [
        {"row": "Human-only aggregate", "optimized_weight_share": None,
         "mean_CRPS": round(_crps_hum, 2)},
        {"row": "Collaborative aggregate", "optimized_weight_share": None,
         "mean_CRPS": round(_crps_full, 2)},
        {"row": "  human subpanel (5 experts)", "optimized_weight_share": round(_WH, 2),
         "mean_CRPS": None},
        {"row": "  machine subpanel (5 experts)", "optimized_weight_share": round(_WM, 2),
         "mean_CRPS": None},
    ],
    "provenance": cfg({
        "generator": "build_workbooks.py (ex:hmpanel block; values are round(x, 2) of fig5-3_loo.xlsx sheet results)",
        "seed": NEW_SEED,
        "synthetic": 1,
        "note": ("rounded outputs of the seeded ex:hmpanel solve, asserted in build_workbooks.py "
                 "(rule-12 self-check: this table must equal the rounded results sheet of fig5-3_loo.xlsx)"),
        "gain_pct_printed": round(_gain_pct),
    }),
})

# =====================================================================
# FIGURE 5.2  Calibration-sharpness profile of the mixed panel
#             (fig:calsharp, Example ex:hmpanel)
#
# DERIVED from the same generated panel as fig5-3_loo.xlsx above, not
# hand-set: each expert's reliability error REL_i and potential CRPS
# POT_i are the per-expert Hersbach values of the 'individual' sheet,
# and the resolution follows Hersbach's own definition
#     RES_i = UNC - POT_i,
# where UNC is the uncertainty term formed on the SAME L = 19 grid and
# convention as REL_i and POT_i (the potential CRPS of the sample
# climatology represented by its empirical quantiles at the 19 levels),
# as prop:loo-decomposition requires.  Figures 5.2 and 5.3 are therefore
# two views of ONE dataset.  The workbook remains the figure's own data
# source (one workbook per figure), and this block records the
# cross-reference.
# NOTE the honest consequence: the two overconfident machines, which
# alone see the extra signal g, have the HIGHEST individual resolution
# in the panel as well as by far the worst reliability error; they
# stand apart at the top of the plot.
# =====================================================================
_GRP51 = {"human": "human experts",
          "machine calibrated": "calibrated models",
          "machine overconfident": "overconfident models"}
_pts51 = [{"id": r["id"], "group": _GRP51[r["group"]],
           "RES": r["RES_i"], "REL": r["REL_i"]}
          for r in _ind_rows]
_res51 = [p["RES"] for p in _pts51]
_rel51 = [p["REL"] for p in _pts51]
_xspan51 = max(_res51) - min(_res51)
_x0_51 = round(min(_res51) - 0.10 * _xspan51, 3)
_x1_51 = round(max(_res51) + 0.10 * _xspan51, 3)
_y1_51 = round(1.42 * max(_rel51), 3)      # headroom keeps the legend clear
_rel_over51 = [p["REL"] for p in _pts51 if p["group"] == "overconfident models"]
assert min(_rel_over51) > 3.0 * max(
    p["REL"] for p in _pts51 if p["group"] != "overconfident models"), \
    "the overconfident machines no longer stand apart in REL_i"
write("fig5-2_calibration_sharpness.xlsx", {
    "config": cfg({
        "figure": "5.2", "label": "fig:calsharp",
        "example": "ex:hmpanel (Section 5.5)",
        "synthetic": 1, "seed": NEW_SEED,
        "derived_from": ("fig5-3_loo.xlsx sheet 'individual' -- same generated "
                         "panel and Hersbach split; RES_i = UNC_grid - POT_i"),
        "uncertainty_UNC_grid": _UNC_grid,
        "uncertainty_note": ("potential CRPS of the sample climatology on the same L = 19 grid "
                             "and Hersbach convention as REL_i and POT_i (see fig5-3_loo.xlsx config); "
                             "continuous 0.5 E|y - y'| = %.6f for reference" % _U_cont),
        "hersbach_levels_L": _L_LEV,
        "hersbach_convention": ("Hersbach (2000) L-member ensemble: interior bin i at nominal level i/L; "
                                "outer regions scored at nominal levels 0 and 1"),
        # mathtext, so the subscripts typeset as they do in the caption and prose
        "x_label": "resolution (informativeness) $\\mathrm{RES}_i$",
        "y_label": "reliability error $\\mathrm{REL}_i$ (lower is better)",
        # a small negative floor keeps the low-REL cluster off the axis line
        "xmin": _x0_51, "xmax": _x1_51,
        "ymin": round(-0.04 * _y1_51, 3), "ymax": _y1_51,
        "title": "Calibration profile of a synthetic human-machine panel",
    }),
    "points": pd.DataFrame(_pts51),
    "annotations": [
        {"text": "poorly\ncalibrated",
         "x": round(_x0_51 + 0.03 * (_x1_51 - _x0_51), 4),
         "y": round(sum(_rel_over51) / len(_rel_over51), 4), "ha": "left"},
        {"text": "calibrated\nand informative",
         "x": round(_x1_51 - 0.03 * (_x1_51 - _x0_51), 4),
         "y": round(0.11 * _y1_51, 4), "ha": "right"},
    ],
})


# =====================================================================
# VIGNETTE V (Section 6.6, human-machine forecast aggregation)
#   -> Figure fig6-12_hm_calsharp (fig:hm-calsharp), Table tab:hm-vignette,
#      and every number the vignette prose reports.
#
# Since 2026-09-14 the vignette is GENERATED and SOLVED here (it used to
# carry eight typed points).  Under seed 202603:
#   * target: a stationary AR(1) over T = 24 quarters,
#         y_1 ~ N(c, s^2/(1-phi^2)),  y_t = c + phi (y_{t-1} - c) + s e_t,
#     c = 2.0, phi = 0.6, s = 1.2 (a quarterly growth-rate series in percent);
#   * panel: N_H = 4 human forecasters, N_M = 4 machine experts (two
#     calibrated, two overconfident).  Forecaster i issues N(mu_it, spread_i^2)
#     with mu_it = y_t + bias_i + tau_i * xi_it, xi_it iid N(0,1).  Humans and
#     calibrated machines report the spread commensurate with their error,
#     spread_i = sqrt(bias_i^2 + tau_i^2); the overconfident machines report
#     a spread far below it.  The eight (bias, tau, spread) triples are the
#     constants _VG_BIAS / _VG_TAU / _VG_SPREAD_OVER below and are written to
#     the 'forecasters' sheet;
#   * draw order: (1) T standard normals for the AR(1) innovations (the first
#     scaled to the stationary law), (2) a T x 8 matrix of forecast noise,
#     quarter-major / forecaster-minor.  Nothing else is drawn from this rng;
#   * pool: quantile averaging (eq:hm-qa); for normals the aggregate is
#     N(w.mu_t, (w.spread)^2), and the CRPS is the closed form of def:crps
#     (_crps_gauss, evaluated exactly, no quadrature);
#   * program: eq:hm-crps, mean CRPS + lambda_G Gini(w) + eps/2 |w|^2 over the
#     simplex, lambda_G = 0.02, eps_ridge = 1e-3, solved by Algorithm 4.2
#     (projected subgradient descent from the equal-weight vector, analytic
#     subgradient, diminishing steps eta_r = eta0/(1 + r/r0), the tie rule
#     sign(0) = 0 for the Gini term, best iterate returned, stop when the
#     sup-norm change of the iterate is below 1e-6 after at least r_min
#     iterations, with an iteration guard).  Every solve is CERTIFIED against
#     scipy SLSQP from the equal-weight vector plus K = 20 Dirichlet(1) starts
#     (a fresh default_rng(202603) per solve draws the starts); the objective
#     gap and the weight difference are written to the 'solves' sheet;
#   * comparators: the same program on the humans alone, the equal-weight
#     pool, and the eight leave-one-out re-solves;
#   * diagnostics: the fraction of outcomes below each forecaster's median,
#     and the Hersbach reliability / potential split on the L = 19
#     ensemble-quantile representation of each forecast sequence (outer bins
#     scored), the convention of the ex:hmpanel block above; the resolution
#     is RES_i = UNC - POT_i with UNC = 0.5 mean|y - y'| the sample
#     climatological CRPS of the T outcomes.
# All settings are written to the workbook's config sheet.
# =====================================================================
from scipy.optimize import minimize as _sp_minimize

_VG_T = 24
_VG_AR = {"c": 2.0, "phi": 0.6, "sigma": 1.2}
_VG_IDS = ["H1", "H2", "H3", "H4", "M1", "M2", "M3", "M4"]
_VG_GROUPS = (["human forecasters"] * 4 + ["calibrated machines"] * 2
              + ["overconfident machines"] * 2)
_VG_COLOR = ["blue"] * 4 + ["teal"] * 2 + ["red"] * 2
_VG_MARKER = ["o"] * 4 + ["s"] * 2 + ["^"] * 2
_VG_BIAS = np.array([0.20, -0.15, 0.25, -0.10, 0.05, -0.05, 0.50, 0.65])
_VG_TAU = np.array([0.60, 0.65, 0.55, 0.70, 0.50, 0.45, 0.30, 0.25])
_VG_SPREAD_OVER = np.array([0.15, 0.12])           # reported by M3, M4
_VG_SPREAD = np.concatenate([np.sqrt(_VG_BIAS[:6] ** 2 + _VG_TAU[:6] ** 2),
                             _VG_SPREAD_OVER])
_VG_LAM_G, _VG_EPS = 0.02, 1e-3
_VG_SOLVER = {"eta0": 0.5, "r0": 50.0, "tol": 1e-6, "r_min": 500, "r_max": 500000}
_VG_CERT = {"K": 20, "ftol": 1e-14, "maxiter": 2000}
_VG_CERT_GAP = 1e-7      # every solve must agree with its SLSQP certificate to this bound (the book prints it)
_VG_L = 19
_SQRT_PI_INV = 1.0 / math.sqrt(math.pi)


def _vg_generate():
    rng = np.random.default_rng(NEW_SEED)
    c, phi, s = _VG_AR["c"], _VG_AR["phi"], _VG_AR["sigma"]
    e = rng.normal(0.0, 1.0, _VG_T)                        # draw (1)
    y = np.empty(_VG_T)
    y[0] = c + s / math.sqrt(1.0 - phi ** 2) * e[0]
    for t in range(1, _VG_T):
        y[t] = c + phi * (y[t - 1] - c) + s * e[t]
    xi = rng.normal(0.0, 1.0, (_VG_T, len(_VG_IDS)))       # draw (2)
    MU = y[:, None] + _VG_BIAS[None, :] + _VG_TAU[None, :] * xi
    return y, MU, _VG_SPREAD.copy()


def _vg_val_grad(w, mu, sd, y, lam_G, eps):
    """Objective of eq:hm-crps and one of its subgradients (tie rule
    sign(0) = 0 in the Gini term), sharing z, Phi(z), phi(z)."""
    m = mu @ w
    s = float(sd @ w)
    z = (y - m) / s
    Phi = _ncdf(z)
    phi = _npdf(z)
    crps = float((s * (z * (2.0 * Phi - 1.0) + 2.0 * phi - _SQRT_PI_INV)).mean())
    n = w.size
    D = w[:, None] - w[None, :]
    mbar = w.mean()
    G = float(np.abs(D).sum() / (2.0 * n * n * mbar))      # == _gini_vec(w)
    v = crps + lam_G * G + 0.5 * eps * float(w @ w)
    g = ((1.0 - 2.0 * Phi)[:, None] * mu).mean(axis=0) + (2.0 * phi - _SQRT_PI_INV).mean() * sd
    g = g + lam_G * (np.sign(D).sum(axis=1) / (n * n * mbar) - G / (n * mbar)) + eps * w
    return v, g


def _vg_objective(w, mu, sd, y, lam_G, eps):
    w = np.asarray(w, float)
    return float(_crps_gauss(mu @ w, float(sd @ w), y).mean()
                 + lam_G * _gini_vec(w) + 0.5 * eps * float(w @ w))


def _vg_psd(mu, sd, y, lam_G, eps, eta0, r0, tol, r_min, r_max):
    """Algorithm 4.2: projected subgradient descent, best iterate returned."""
    n = mu.shape[1]
    w = np.full(n, 1.0 / n)
    best_v, g = _vg_val_grad(w, mu, sd, y, lam_G, eps)
    best_w = w.copy()
    r = 0
    while True:
        eta = eta0 / (1.0 + r / r0)
        w_new = _project_simplex(w - eta * g)[0]
        v, g = _vg_val_grad(w_new, mu, sd, y, lam_G, eps)
        if v < best_v:
            best_v, best_w = v, w_new.copy()
        r += 1
        step = float(np.abs(w_new - w).max())
        w = w_new
        if (step < tol and r >= r_min) or r >= r_max:
            break
    return best_w, best_v, r, step, bool(step < tol)


def _vg_certify(mu, sd, y, lam_G, eps, K, ftol, maxiter):
    """SLSQP over the simplex from the equal-weight vector and K Dirichlet(1)
    starts drawn from a fresh default_rng(NEW_SEED); best value over starts."""
    n = mu.shape[1]
    rng = np.random.default_rng(NEW_SEED)
    starts = [np.full(n, 1.0 / n)] + [rng.dirichlet(np.ones(n)) for _ in range(K)]
    f = lambda v: _vg_objective(v, mu, sd, y, lam_G, eps)
    best = None
    for w0 in starts:
        res = _sp_minimize(f, w0, method="SLSQP", bounds=[(0.0, 1.0)] * n,
                           constraints=({"type": "eq", "fun": lambda v: v.sum() - 1.0},),
                           options={"ftol": ftol, "maxiter": maxiter})
        w = np.clip(res.x, 0.0, None)
        w = w / w.sum()
        v = f(w)
        if best is None or v < best[1]:
            best = (w, v)
    return best


def _vg_solve(y, MU, SD, idx, label):
    mu, sd = MU[:, idx], SD[idx]
    w, v, iters, step, met = _vg_psd(mu, sd, y, _VG_LAM_G, _VG_EPS, **_VG_SOLVER)
    wc, vc = _vg_certify(mu, sd, y, _VG_LAM_G, _VG_EPS, **_VG_CERT)
    crps = float(_crps_gauss(mu @ w, float(sd @ w), y).mean())
    rec = {"solve": label, "n_experts": len(idx), "iterations": iters,
           "final_step_sup_norm": step, "tolerance_met": int(met),
           "objective_best_iterate": v, "objective_certificate_slsqp": vc,
           "objective_gap": v - vc, "max_abs_weight_diff_vs_certificate": float(np.abs(w - wc).max()),
           "gini_w": _gini_vec(w), "mean_CRPS": crps}
    return w, rec


print("\n-- generating and solving the Section 6.6 vignette "
      "(fig6-12_hm_calsharp.xlsx) ...")
_vy, _vMU, _vSD = _vg_generate()
_vN = len(_VG_IDS)
_vall = list(range(_vN))
_vhum = [i for i in _vall if _VG_IDS[i].startswith("H")]
_vmac = [i for i in _vall if _VG_IDS[i].startswith("M")]
_vg_solves = []
_vw_full, _r = _vg_solve(_vy, _vMU, _vSD, _vall, "full panel")
_vg_solves.append(_r)
_vcrps_full = _r["mean_CRPS"]
_vw_hum_sub, _r = _vg_solve(_vy, _vMU, _vSD, _vhum, "human-only")
_vg_solves.append(_r)
_vcrps_hum = _r["mean_CRPS"]
_vw_hum = np.zeros(_vN)
_vw_hum[_vhum] = _vw_hum_sub
_vw_eq = np.full(_vN, 1.0 / _vN)
_vcrps_eq = float(_crps_gauss(_vMU @ _vw_eq, float(_vSD @ _vw_eq), _vy).mean())
_vWH = float(_vw_full[_vhum].sum())
_vWM = float(_vw_full[_vmac].sum())

# Hersbach split (L-member ensemble quantiles, outer bins scored) of the
# full aggregate, the leave-one-out aggregates, and each individual forecaster
_vzlev = _norm_ppf(np.arange(1, _VG_L + 1) / (_VG_L + 1.0))
_vUNC = float(0.5 * np.abs(_vy[:, None] - _vy[None, :]).mean())
_vch_full, _vrel_full, _vpot_full = _hersbach(
    _vMU @ _vw_full, np.full(_VG_T, float(_vSD @ _vw_full)), _vy, _vzlev)
_vloo_w = np.full((_vN, _vN), np.nan)
_vrows = []
for _i in _vall:
    _sub = [j for j in _vall if j != _i]
    _w_i, _r = _vg_solve(_vy, _vMU, _vSD, _sub, "leave-one-out %s" % _VG_IDS[_i])
    _vg_solves.append(_r)
    _vloo_w[_i, _sub] = _w_i
    _ch_i, _rel_i, _pot_i = _hersbach(
        _vMU[:, _sub] @ _w_i, np.full(_VG_T, float(_vSD[_sub] @ _w_i)), _vy, _vzlev)
    _c_ind, _r_ind, _p_ind = _hersbach(_vMU[:, _i], np.full(_VG_T, _vSD[_i]), _vy, _vzlev)
    _vrows.append({
        "id": _VG_IDS[_i], "group": _VG_GROUPS[_i],
        "color": _VG_COLOR[_i], "marker": _VG_MARKER[_i],
        "bias": float(_VG_BIAS[_i]), "error_scale_tau": float(_VG_TAU[_i]),
        "spread": float(_vSD[_i]),
        "spread_over_rmse": float(_vSD[_i] / math.sqrt(_VG_BIAS[_i] ** 2 + _VG_TAU[_i] ** 2)),
        "mean_CRPS_individual": float(_crps_gauss(_vMU[:, _i], _vSD[_i], _vy).mean()),
        "weight_full": float(_vw_full[_i]),
        "weight_human_only": float(_vw_hum[_i]),
        "weight_equal": float(_vw_eq[_i]),
        "crps_loo_resolve": _r["mean_CRPS"],
        "delta_loo": _r["mean_CRPS"] - _vcrps_full,
        "delta_cal": float(_rel_i - _vrel_full),
        "delta_res": float(_pot_i - _vpot_full),
        "delta_loo_hersbach": float(_ch_i - _vch_full),
        "frac_below_median": float((_vy < _vMU[:, _i]).mean()),
        "REL_i": float(_r_ind), "POT_i": float(_p_ind),
        "crps_i_hersbach": float(_c_ind),
        # the two columns the figure script plots
        "resolution": float(_vUNC - _p_ind), "reliability_error": float(_r_ind),
    })
_vF = pd.DataFrame(_vrows)

# ---- console summary ------------------------------------------------------
print("   vignette: human-only %.4f  equal-weight %.4f  optimized %.4f  W_H %.4f  W_M %.4f"
      % (_vcrps_hum, _vcrps_eq, _vcrps_full, _vWH, _vWM))
for _r in _vrows:
    print("   %-3s w %.3f  Delta %+.4f (cal %+.4f res %+.4f)  below-median %.3f  REL %.4f RES %.4f"
          % (_r["id"], _r["weight_full"], _r["delta_loo"], _r["delta_cal"], _r["delta_res"],
             _r["frac_below_median"], _r["REL_i"], _r["resolution"]))
for _r in _vg_solves:
    print("   solve %-20s iters %6d  tol met %d  gap %.1e  |dw| %.1e"
          % (_r["solve"], _r["iterations"], _r["tolerance_met"], _r["objective_gap"],
             _r["max_abs_weight_diff_vs_certificate"]))
for _r in _vg_solves:
    assert abs(_r["objective_gap"]) < _VG_CERT_GAP, "vignette solve %r not certified: gap %.2e" % (
        _r["solve"], _r["objective_gap"])

# ---- figure geometry, derived from the solved points ----------------------
_vres = _vF["resolution"].to_numpy(float)
_vrel = _vF["reliability_error"].to_numpy(float)
_vxspan = float(_vres.max() - _vres.min())
_vx0 = round(float(_vres.min() - 0.12 * _vxspan), 3)
_vx1 = round(float(_vres.max() + 0.12 * _vxspan), 3)
_vy1 = round(1.42 * float(_vrel.max()), 3)
_vy0 = round(-0.04 * _vy1, 3)
_vcut = 0.2 * _vUNC                    # visual guide: REL below a fifth of UNC
_vover = _vF[_vF["group"] == "overconfident machines"]
_vcall_x = float(_vover["resolution"].mean())
_vcall_y = float(_vover["reliability_error"].mean())

write("fig6-12_hm_calsharp.xlsx", {
    "config": cfg({
        "case": "vignette V -- human-machine forecast aggregation (Section 6.6)",
        "figures": "fig6-12_hm_calsharp",
        "labels": "fig:hm-calsharp; tab:hm-vignette",
        "synthetic": 1,
        "seed": NEW_SEED,
        "generator": "build_workbooks.py, vignette block (_vg_generate / _vg_solve / _hersbach)",
        "n_human": len(_vhum), "n_machine": len(_vmac), "horizon_T": _VG_T,
        "target_law": "stationary AR(1): y_1 ~ N(c, sigma^2/(1-phi^2)), y_t = c + phi (y_{t-1} - c) + sigma e_t",
        "target_c": _VG_AR["c"], "target_phi": _VG_AR["phi"], "target_sigma": _VG_AR["sigma"],
        "forecast_model": "mu_it = y_t + bias_i + tau_i xi_it, xi iid N(0,1); predictive N(mu_it, spread_i^2)",
        "spread_rule_humans_and_calibrated": "spread_i = sqrt(bias_i^2 + tau_i^2) (commensurate with the error)",
        "spread_rule_overconfident": "spread_i = %s (far below the error)" % list(map(float, _VG_SPREAD_OVER)),
        "draw_order": "(1) T standard normals for the AR(1) innovations, first scaled to the stationary law; (2) T x 8 forecast-noise matrix, quarter-major",
        "pool": "quantile averaging eq:hm-qa; normal aggregate N(w.mu_t, (w.spread)^2)",
        "crps": "closed form for normals (def:crps), evaluated exactly (_crps_gauss; Phi by Abramowitz-Stegun 7.1.26, |err| < 1.5e-7)",
        "objective": "mean CRPS + lambda_G Gini(w) + eps_ridge/2 ||w||^2 over the simplex (eq:hm-crps)",
        "lambda_G": _VG_LAM_G, "eps_ridge": _VG_EPS,
        "solver": "Algorithm 4.2 projected subgradient descent, analytic subgradient, equal-weight start, best iterate returned",
        "step_size_rule": "eta_r = eta0 / (1 + r / r0)",
        "eta0": _VG_SOLVER["eta0"], "r0": _VG_SOLVER["r0"],
        "tie_breaking_rule": "sign(0) = 0 for every vanishing weight difference in the Gini subgradient",
        "stopping_rule": "sup-norm change of the iterate < tol after at least r_min iterations; r_max is a guard",
        "tol": _VG_SOLVER["tol"], "r_min": _VG_SOLVER["r_min"], "r_max": _VG_SOLVER["r_max"],
        "certificate": "scipy SLSQP over the simplex from the equal-weight vector plus K Dirichlet(1) starts drawn from a fresh default_rng(seed) per solve; best value over starts; gap and weight difference in sheet 'solves'",
        "certificate_K": _VG_CERT["K"], "certificate_ftol": _VG_CERT["ftol"], "certificate_maxiter": _VG_CERT["maxiter"],
        "certificate_gap_bound": _VG_CERT_GAP,
        "comparators": "human-only re-solve (same program), equal-weight pool, eight leave-one-out re-solves",
        "loo_definition": "delta_loo = mean CRPS of the re-solved pool without i minus mean CRPS of the full optimized pool (exact CRPS); delta_cal / delta_res are the Hersbach channels REL_-i - REL and POT_-i - POT, summing to delta_loo_hersbach",
        "calibration_diagnostic": "frac_below_median = fraction of the T outcomes below the forecaster's median (its mean)",
        "hersbach_levels_L": _VG_L,
        "hersbach_convention": "L ensemble members at the normal quantiles l/(L+1); interior bins between consecutive members and the two outer bins scored (as the ex:hmpanel block)",
        "uncertainty_UNC": _vUNC,
        "resolution_definition": "RES_i = UNC - POT_i, UNC = 0.5 mean |y - y'| over the T outcomes",
        "x_label": "resolution $\\mathrm{RES}_i$ (informativeness) $\\rightarrow$",
        "y_label": "reliability error $\\mathrm{REL}_i$ (miscalibration) $\\rightarrow$",
        "x_min": _vx0, "x_max": _vx1, "y_min": _vy0, "y_max": _vy1,
        "well_calibrated_cut": _vcut,
        "well_calibrated_rule": "band top = 0.2 * UNC (a visual guide, not a diagnostic threshold)",
        "band_label": "well-calibrated region",
        "band_label_x": round(_vx0 + 0.58 * (_vx1 - _vx0), 4),
        "band_label_y": round(0.55 * _vcut, 4),
        "callout_text": "high resolution,\nmiscalibrated",
        "callout_xy_x": round(_vcall_x, 4), "callout_xy_y": round(_vcall_y, 4),
        "callout_text_x": round(_vcall_x - 0.30 * (_vx1 - _vx0), 4),
        "callout_text_y": round(_vcall_y - 0.10 * _vy1, 4),
    }),
    "forecasters": _vF,
    "outcomes": pd.DataFrame({"t": np.arange(1, _VG_T + 1), "y": _vy}),
    "forecast_mu": pd.DataFrame(_vMU, columns=_VG_IDS),
    "weights": pd.DataFrame({"id": _VG_IDS, "weight_full": _vw_full,
                             "weight_human_only": _vw_hum, "weight_equal": _vw_eq}),
    "loo_weights": pd.DataFrame(_vloo_w, columns=_VG_IDS).assign(withheld=_VG_IDS)[["withheld"] + _VG_IDS],
    "solves": pd.DataFrame(_vg_solves),
    "aggregates": pd.DataFrame([
        {"quantity": "optimized human-only mean CRPS", "value": _vcrps_hum, "printed": round(_vcrps_hum, 2)},
        {"quantity": "equal-weight human-machine mean CRPS", "value": _vcrps_eq, "printed": round(_vcrps_eq, 2)},
        {"quantity": "optimized human-machine mean CRPS", "value": _vcrps_full, "printed": round(_vcrps_full, 2)},
        {"quantity": "human weight share W_H", "value": _vWH, "printed": round(_vWH, 2)},
        {"quantity": "machine weight share W_M", "value": _vWM, "printed": round(_vWM, 2)},
        {"quantity": "full-pool Hersbach REL", "value": _vrel_full, "printed": round(_vrel_full, 3)},
        {"quantity": "full-pool Hersbach POT", "value": _vpot_full, "printed": round(_vpot_full, 3)},
        {"quantity": "full-pool Hersbach CRPS", "value": _vch_full, "printed": round(_vch_full, 3)},
        {"quantity": "uncertainty UNC (sample climatology)", "value": _vUNC, "printed": round(_vUNC, 3)},
    ]),
})


# =====================================================================
# FIGURE 5.4  Expert-dependence network of Example ex:corr-lineage
#             (fig5-4_depnet)
# Five independent human experts; five fine-tuned variants of one base
# model with within-lineage error correlation about 0.85.  Node layout
# is deterministic (coordinates stored); edge opacity in the figure is
# proportional to the pairwise correlation, so the lineage block reads
# as a dense clique.
# =====================================================================
_rngd = np.random.default_rng(NEW_SEED)
_dep_ids = ["H1", "H2", "H3", "H4", "H5", "M1", "M2", "M3", "M4", "M5"]
_dep_grp = ["human"] * 5 + ["lineage"] * 5
_R = np.eye(10)
for _i in range(10):
    for _j in range(_i + 1, 10):
        if _dep_grp[_i] == "lineage" and _dep_grp[_j] == "lineage":
            r = 0.85 + _rngd.uniform(-0.03, 0.03)
        elif _dep_grp[_i] == "human" and _dep_grp[_j] == "human":
            r = _rngd.uniform(0.05, 0.20)
        else:
            r = _rngd.uniform(0.02, 0.10)
        _R[_i, _j] = _R[_j, _i] = round(r, 3)
# exact block mean 0.85 for the lineage clique
_lin = [i for i, gse in enumerate(_dep_grp) if gse == "lineage"]
_pairs = [(i, j) for i in _lin for j in _lin if i < j]
_off = 0.85 - np.mean([_R[i, j] for i, j in _pairs])
for _i, _j in _pairs:
    _R[_i, _j] = _R[_j, _i] = round(_R[_i, _j] + _off, 3)

# deterministic layout: humans on a wide left pentagon, lineage on a
# tight right pentagon (its density is the visual point)
_dep_nodes = []
for _k in range(5):
    _ang = math.pi / 2 + 2 * math.pi * _k / 5
    _dep_nodes.append({"id": _dep_ids[_k], "group": "human",
                       "x": -1.75 + 1.05 * math.cos(_ang),
                       "y": 1.05 * math.sin(_ang)})
for _k in range(5):
    _ang = math.pi / 2 + 2 * math.pi * _k / 5
    _dep_nodes.append({"id": _dep_ids[5 + _k], "group": "lineage",
                       "x": 1.75 + 0.52 * math.cos(_ang),
                       "y": 0.52 * math.sin(_ang)})

_w_eq = np.full(10, 0.1)
_neff_panel = float(1.0 / (_w_eq @ _R @ _w_eq))
_wl = np.full(5, 0.2)
_Rl = _R[np.ix_(_lin, _lin)]
_neff_lineage = float(1.0 / (_wl @ _Rl @ _wl))
write("fig5-4_depnet.xlsx", {
    "config": cfg({
        "figure": "5.4", "label": "fig:depnet",
        "example": "ex:corr-lineage (Section 5.6)",
        "synthetic": 1, "seed": NEW_SEED,
        "lineage_mean_corr": 0.85,
        "neff_lineage_equalweight": _neff_lineage,
        "neff_panel_equalweight": _neff_panel,
        "edge_note": "edge opacity and width proportional to the pairwise error correlation",
        "human_legend": "human experts (weakly correlated)",
        "lineage_legend": "fine-tuned variants of one base model",
    }),
    "nodes": pd.DataFrame(_dep_nodes),
    "correlation": pd.DataFrame(_R, columns=_dep_ids).assign(id=_dep_ids)[
        ["id"] + _dep_ids],
})


# =====================================================================
# CASE STUDY IV (Section 6.5, rail-transit station accessibility)
#   Urban rail-transit station accessibility with stakeholder equity
#   (mirrors chen2024railtransit at the level of MECHANISM only: equity
#   weighting reorders priorities).  One workbook backs the whole case.
#   -> Figure fig6-11_rt_equity (fig:rt-equity), Table tab:rt-results
#
#   Everything the book prints for this case is SOLVED here from the
#   stated inputs (tab:rt-stations, rho, vartheta, sigma, seed 202603)
#   by the stated formulas:
#     overlap      def:consensus, closed form for equal-variance normals
#                  over the real line, 2 Phi(-|mu_i - m| / (2 sigma))
#     consensus    the mean overlap (a positive rescaling of the
#                  cumulative overlap; single objective, same argmax)
#     equity       Sen's abbreviated welfare form Ubar (1 - G(U)) of the
#                  parabolic-normalized Fehr-Schmidt utilities (kappa = 2)
#     confidence   constant over the simplex (common sigma) -> dropped
#     solver       multi-start SQP (scipy SLSQP) over the simplex from the
#                  uniform vector and K = 40 Dirichlet(1) starts, best
#                  objective retained; certified against a dense 1-D scan
#                  of the aggregate mean (every objective depends on w only
#                  through m = w.mu)
#     reporting    the representative of the optimal level set nearest to
#                  the uniform vector (convex QP, KKT cross-check)
#     priority     ascending collective mean
#     robustness   40 re-seeded panels and a 22-point Fehr-Schmidt grid,
#                  solved by the certified 1-D scan
# =====================================================================
print("\n-- generating and solving Case IV (fig6-11_rt_case.xlsx) ...")
from scipy.optimize import minimize, minimize_scalar, least_squares
from scipy.special import ndtr

_RT_STATIONS = [
    {"id": "S1",  "name": "Central Exchange",      "ops": 8.0, "pas": 7.8, "adv": 7.6},
    {"id": "S2",  "name": "Civic Plaza",           "ops": 7.4, "pas": 7.2, "adv": 7.0},
    {"id": "S3",  "name": "Riverside",             "ops": 6.7, "pas": 6.6, "adv": 6.4},
    {"id": "S4",  "name": "Northgate Interchange", "ops": 6.5, "pas": 6.3, "adv": 4.5},
    {"id": "S5",  "name": "University Park",       "ops": 6.0, "pas": 5.9, "adv": 5.8},
    {"id": "S6",  "name": "Harbor View",           "ops": 5.4, "pas": 5.3, "adv": 5.2},
    {"id": "S7",  "name": "Meadow East",           "ops": 4.9, "pas": 4.8, "adv": 4.7},
    {"id": "S8",  "name": "Old Town",              "ops": 4.4, "pas": 4.3, "adv": 4.2},
    {"id": "S9",  "name": "Westfield Depot",       "ops": 3.9, "pas": 3.8, "adv": 3.6},
    {"id": "S10", "name": "Airport South",         "ops": 3.3, "pas": 3.2, "adv": 3.1},
]
_RT_CONST = [("operators", "ops", 8), ("passenger representatives", "pas", 10),
             ("accessibility advocates", "adv", 6)]
_RT_RHO, _RT_THETA = 0.4, 0.2            # Fehr-Schmidt rho_i, vartheta_i (chapter 6)
_RT_LENIENCY_SD, _RT_NOISE_SD = 0.15, 0.25
_RT_SIGMA = 1.0                          # the common reported dispersion
# solver settings (all recorded in the config sheet)
_RT_K_STARTS = 40                        # Dirichlet(1) starts in addition to the uniform vector
_RT_SQP_FTOL, _RT_SQP_MAXITER = 1e-12, 500
_RT_SCAN_POINTS, _RT_SCAN_XATOL = 8001, 1e-12
_RT_CERT_OBJ_TOL, _RT_CERT_M_TOL = 1e-8, 1e-4   # observed SQP-vs-scan gaps are ~1e-6
_RT_PRINT_DP = 2                          # the book prints means to 2 dp; SQP and scan must agree there
_RT_GAP_THRESHOLD = 0.1                   # the prose counts uncontested gaps below this
_RT_RESEED_N = 40                        # re-seeded panels: seeds 202604 .. 202643
_RT_FS_RHO = (0.2, 0.3, 0.4, 0.5, 0.6)
_RT_FS_THETA = (0.0, 0.1, 0.2, 0.3, 0.4)  # combinations with vartheta <= rho

_rt_N = sum(c[2] for c in _RT_CONST)
_rt_cid = sum([[c[0]] * c[2] for c in _RT_CONST], [])
_rt_ckey = sum([[c[1]] * c[2] for c in _RT_CONST], [])
_rt_adv = np.array([k == "adv" for k in _rt_ckey])


def _rt_generate_panel(rng):
    """Draw order (recorded in the config sheet): first the 24 leniency
    draws N(0, 0.15^2), one per stakeholder; then, station by station
    (S1 .. S10) and within a station stakeholder by stakeholder (1 .. 24),
    one scalar noise draw N(0, 0.25^2).  Every mean is clipped to [0, 10]
    (the clip does not bind under seed 202603; the config records this)."""
    len_ = rng.normal(0.0, _RT_LENIENCY_SD, _rt_N)
    MU = np.empty((_rt_N, 10))
    for j, st in enumerate(_RT_STATIONS):
        for i in range(_rt_N):
            MU[i, j] = np.clip(st[_rt_ckey[i]] + len_[i]
                               + rng.normal(0.0, _RT_NOISE_SD), 0.0, 10.0)
    return MU, len_


_rngr = np.random.default_rng(NEW_SEED)
_rt_MU, _rt_len = _rt_generate_panel(_rngr)
_rt_clip_binding = bool((_rt_MU <= 0.0).any() or (_rt_MU >= 10.0).any())
# the SQP starts are the next draws of the SAME stream: the uniform vector
# plus K Dirichlet(1, ..., 1) vectors, drawn once and shared by every
# station and both regimes
_rt_starts = [np.full(_rt_N, 1.0 / _rt_N)] + \
    [_rngr.dirichlet(np.ones(_rt_N)) for _ in range(_RT_K_STARTS)]
# a common reported dispersion: the aggregate sd under QA, sum w sigma, is
# the same for every weight vector, so the confidence objective is constant
# over the simplex and is DROPPED from both programs (chapter 6, Section
# 6.6); this also frees the level sets of the aggregate mean, along which
# both regimes' reported representatives are selected (_rt_project_uniform)
_rt_SD = np.full(_rt_N, _RT_SIGMA)


def _rt_overlap(mus, m):
    """The overlap of def:consensus for equal-variance normals, in closed
    form over the real line: int min{f_i, f_QA} dx = 2 Phi(-|mu_i - m| / (2 sigma)).
    m: scalar or (M,) -> (M, n)."""
    m = np.atleast_1d(np.asarray(m, float))
    return 2.0 * ndtr(-np.abs(mus[None, :] - m[:, None]) / (2.0 * _RT_SIGMA))


def _rt_objective(m, mus, regime, rho=_RT_RHO, theta=_RT_THETA):
    """Regime objective as a function of the aggregate mean m (vectorized).
    'eff': the consensus objective, the mean overlap.  'eq4': Sen's
    abbreviated welfare form Ubar (1 - G(U)) of the parabolic-normalized
    Fehr-Schmidt utilities of the overlaps (kappa = 2, via _fs_phi) with
    G the I_4 Gini of the utility profile.  No confidence term."""
    A = _rt_overlap(mus, m)
    if regime == "eff":
        return A.mean(axis=1)
    _, Ut = _fs_phi(A, rho, theta)
    gini = np.array([_gini_vec(u) for u in Ut])
    return Ut.mean(axis=1) * (1.0 - gini)


def _rt_scan(mus, regime, rho=_RT_RHO, theta=_RT_THETA, npts=_RT_SCAN_POINTS):
    """Certificate of global optimality.  Because sigma is common, every
    objective depends on w only through m = w.mu, and m ranges exactly over
    [min mu, max mu] on the simplex, so a dense scan of m (npts points) with
    a bounded refinement around the best grid point is a global solver of
    the one-dimensional problem.  Returns (m*, value, number of local maxima)."""
    lo, hi = float(mus.min()), float(mus.max())
    grid = np.linspace(lo, hi, npts)
    vals = np.concatenate([_rt_objective(grid[k:k + 1024], mus, regime, rho, theta)
                           for k in range(0, npts, 1024)])
    k = int(np.argmax(vals))
    a, b = grid[max(k - 2, 0)], grid[min(k + 2, npts - 1)]
    res = minimize_scalar(lambda m: -float(_rt_objective([m], mus, regime, rho, theta)[0]),
                          bounds=(a, b), method="bounded", options={"xatol": _RT_SCAN_XATOL})
    if -res.fun >= vals[k]:
        m_star, v_star = float(res.x), float(-res.fun)
    else:
        m_star, v_star = float(grid[k]), float(vals[k])
    n_loc = int(sum(1 for i in range(1, npts - 1)
                    if vals[i] > vals[i - 1] and vals[i] >= vals[i + 1]))
    return m_star, v_star, n_loc


def _rt_sqp(mus, regime):
    """The solver the book states: multi-start sequential quadratic
    programming (scipy SLSQP, finite-difference gradients) over the simplex
    {w >= 0, sum w = 1} from the uniform vector and the K Dirichlet(1)
    starts; every start's terminal point is accepted whatever its exit
    status (the objective is nonsmooth at the Gini kinks) and the best
    objective value over the starts is retained."""
    n = mus.size
    f = lambda w: -float(_rt_objective([float(w @ mus)], mus, regime)[0])
    cons = ({"type": "eq", "fun": lambda w: w.sum() - 1.0,
             "jac": lambda w: np.ones(n)},)
    best = None
    finals = []
    for w0 in _rt_starts:
        r = minimize(f, w0, method="SLSQP", bounds=[(0.0, 1.0)] * n, constraints=cons,
                     options={"ftol": _RT_SQP_FTOL, "maxiter": _RT_SQP_MAXITER})
        w = np.clip(r.x, 0.0, None)
        w = w / w.sum()
        v = -f(w)
        finals.append((v, float(w @ mus)))
        if best is None or v > best[1]:
            best = (w, v)
    return best[0], best[1], finals


def _rt_project_uniform(mus, m_star):
    """The reporting rule of chapter 6: the representative of the optimal
    level set {w in simplex : w.mu = m*} closest to the uniform vector
    (min sum w_i^2), a convex QP solved by SLSQP and cross-checked against
    its KKT form w_i = max(0, 1/n + a + b mu_i)."""
    n = mus.size
    u = np.full(n, 1.0 / n)
    cons = ({"type": "eq", "fun": lambda w: w.sum() - 1.0, "jac": lambda w: np.ones(n)},
            {"type": "eq", "fun": lambda w: w @ mus - m_star, "jac": lambda w: mus})
    r = minimize(lambda w: float(((w - u) ** 2).sum()), u, jac=lambda w: 2.0 * (w - u),
                 method="SLSQP", bounds=[(0.0, 1.0)] * n, constraints=cons,
                 options={"ftol": 1e-16, "maxiter": 1000})
    w = np.clip(r.x, 0.0, None)

    def kkt(p):
        ww = np.clip(1.0 / n + p[0] + p[1] * mus, 0.0, None)
        return [ww.sum() - 1.0, ww @ mus - m_star]
    ls = least_squares(kkt, [0.0, 0.0], xtol=1e-15, ftol=1e-15, gtol=1e-15)
    wk = np.clip(1.0 / n + ls.x[0] + ls.x[1] * mus, 0.0, None)
    kkt_err = float(np.abs(w - wk).max())
    assert abs(w.sum() - 1.0) < 1e-9 and abs(float(w @ mus) - m_star) < 1e-9, \
        "projection left the level set (m* %.6f)" % m_star
    assert kkt_err < 1e-6, "projection disagrees with its KKT form by %.2e" % kkt_err
    return w, kkt_err


def _rt_solve(j, regime):
    """Per-station solve of one regime: multi-start SQP, certification by
    the 1-D scan (the build aborts if the SQP best is not the global
    optimum), then the nearest-to-uniform representative and its
    diagnostics.  regime 'eff' = consensus only; 'eq4' = Sen welfare."""
    mus = _rt_MU[:, j]
    w_sqp, v_sqp, finals = _rt_sqp(mus, regime)
    m_sqp = float(w_sqp @ mus)
    m_scan, v_scan, n_loc = _rt_scan(mus, regime)
    assert abs(v_sqp - v_scan) <= _RT_CERT_OBJ_TOL and abs(m_sqp - m_scan) <= _RT_CERT_M_TOL, \
        "%s %s: multi-start SQP best %.8f at m %.5f is not the 1-D global optimum %.8f at m %.5f" % (
            _RT_STATIONS[j]["id"], regime, v_sqp, m_sqp, v_scan, m_scan)
    assert round(m_sqp, _RT_PRINT_DP) == round(m_scan, _RT_PRINT_DP), \
        "%s %s: SQP mean %.6f and scan mean %.6f print differently at %d dp" % (
            _RT_STATIONS[j]["id"], regime, m_sqp, m_scan, _RT_PRINT_DP)
    w, kkt_err = _rt_project_uniform(mus, m_sqp)
    A = _rt_overlap(mus, m_sqp)[0]
    _, Ut = _fs_phi(A[None, :], _RT_RHO, _RT_THETA)
    n_at_best = int(sum(1 for v, _ in finals if v >= v_sqp - 1e-7))
    return {"w": w, "mu": m_sqp, "obj": v_sqp, "sd": float(w @ _rt_SD),
            "Abar": float(A.mean()), "Amin": float(A.min()),
            "Ubar": float(Ut[0].mean()), "gini_U": _gini_vec(Ut[0]),
            "gini_w": _gini_vec(w), "adv_share": float(w[_rt_adv].sum()),
            "m_scan": m_scan, "obj_scan": v_scan, "n_local_maxima": n_loc,
            "n_starts_at_best": n_at_best,
            "start_m_min": min(m for _, m in finals), "start_m_max": max(m for _, m in finals),
            "kkt_err": kkt_err}


_rt_rows, _rt_cert = [], []
_rt_W = {"eff": [], "eq": []}
for _j, _st in enumerate(_RT_STATIONS):
    _re = _rt_solve(_j, "eff")
    _rq = _rt_solve(_j, "eq4")
    _rt_W["eff"].append(_re["w"])
    _rt_W["eq"].append(_rq["w"])
    _rt_rows.append({"station": _st["id"], "name": _st["name"],
                     "mean_eff": _re["mu"], "mean_eq": _rq["mu"],
                     "sd_eff": _re["sd"], "sd_eq": _rq["sd"],
                     "weight_gini_eff": _re["gini_w"], "weight_gini_eq": _rq["gini_w"],
                     "adv_share_eff": _re["adv_share"], "adv_share_eq": _rq["adv_share"],
                     "Ubar_eff": _re["Ubar"], "Ubar_eq": _rq["Ubar"],
                     "gini_U_eff": _re["gini_U"], "gini_U_eq": _rq["gini_U"],
                     "Abar_eff": _re["Abar"], "Abar_eq": _rq["Abar"],
                     "Amin_eff": _re["Amin"], "Amin_eq": _rq["Amin"],
                     "objective_eff": _re["obj"], "objective_eq": _rq["obj"]})
    for _reg, _r in (("eff", _re), ("eq4", _rq)):
        _rt_cert.append({"station": _st["id"], "regime": _reg,
                         "m_sqp": _r["mu"], "objective_sqp": _r["obj"],
                         "m_scan": _r["m_scan"], "objective_scan": _r["obj_scan"],
                         "n_local_maxima_scan": _r["n_local_maxima"],
                         "n_starts_at_best": _r["n_starts_at_best"],
                         "start_terminal_m_min": _r["start_m_min"],
                         "start_terminal_m_max": _r["start_m_max"],
                         "projection_kkt_maxdiff": _r["kkt_err"]})
    print("   %-4s eff %.4f  eq %.4f  (w-gini %.2f -> %.2f, adv share %.2f -> %.2f, "
          "Ubar %.3f -> %.3f)  local maxima %d/%d, starts at best %d/%d"
          % (_st["id"], _re["mu"], _rq["mu"], _re["gini_w"], _rq["gini_w"],
             _re["adv_share"], _rq["adv_share"], _re["Ubar"], _rq["Ubar"],
             _re["n_local_maxima"], _rq["n_local_maxima"],
             _re["n_starts_at_best"], _rq["n_starts_at_best"]))

# priority order for upgrading = ascending collective accessibility
_ord_eff = sorted(range(10), key=lambda j: _rt_rows[j]["mean_eff"])
_ord_eq = sorted(range(10), key=lambda j: _rt_rows[j]["mean_eq"])
for _p, _j in enumerate(_ord_eff, 1):
    _rt_rows[_j]["priority_eff"] = _p
for _p, _j in enumerate(_ord_eq, 1):
    _rt_rows[_j]["priority_eq"] = _p
_swapped = [r["station"] for r in _rt_rows if r["priority_eff"] != r["priority_eq"]]
# the designed contested station is the one whose constituency means are
# furthest apart (tab:rt-stations); the design target of the case is that
# it, and only it, exchanges places with its neighbour in the queue
_rt_contested = max(_RT_STATIONS, key=lambda s: max(s["ops"], s["pas"], s["adv"])
                    - min(s["ops"], s["pas"], s["adv"]))["id"]
assert len(_swapped) == 2 and _rt_contested in _swapped, \
    "the designed priority swap at the contested station is lost: %r" % _swapped
_rt_wg_eff = float(np.mean([r["weight_gini_eff"] for r in _rt_rows]))
_rt_wg_eq = float(np.mean([r["weight_gini_eq"] for r in _rt_rows]))
# "uncontested" as the book uses it: the nine stations other than the
# contested one (the swap partner S5 is uncontested; its means agree)
_rt_unc_gaps = {r["station"]: abs(r["mean_eff"] - r["mean_eq"]) for r in _rt_rows
                if r["station"] != _rt_contested}
_rt_unc_gap = max(_rt_unc_gaps.values())
_rt_unc_gap_station = max(_rt_unc_gaps, key=_rt_unc_gaps.get)
_rt_unc_below = sum(1 for g in _rt_unc_gaps.values() if g < _RT_GAP_THRESHOLD)
print("   swapped stations:", _swapped, " weight-gini eff %.3f vs eq %.3f;"
      " largest uncontested |cons - equity| %.3f at %s, %d/%d below %g"
      % (_rt_wg_eff, _rt_wg_eq, _rt_unc_gap, _rt_unc_gap_station, _rt_unc_below,
         len(_rt_unc_gaps), _RT_GAP_THRESHOLD))

# ---- robustness (a): re-seeded panels, same generator and draw order -----
# solved by the certified 1-D scan (the global solver of this
# one-dimensional problem), which is why 40 panels x 20 solves are cheap
_rt_j4 = [s["id"] for s in _RT_STATIONS].index(_rt_contested)
_rt_j5 = _ord_eff[_ord_eff.index(_rt_j4) - 1]      # the station just ahead of it in the consensus queue
_rt_j6 = _ord_eff[_ord_eff.index(_rt_j4) - 2]      # and the next one ahead
assert sorted(_swapped) == sorted([_RT_STATIONS[_rt_j4]["id"], _RT_STATIONS[_rt_j5]["id"]]), \
    "the swap %r is not the contested station and its consensus neighbour" % _swapped
_rt_seed_rows = []
for _s in range(1, _RT_RESEED_N + 1):
    _MUs, _ = _rt_generate_panel(np.random.default_rng(NEW_SEED + _s))
    _mc = [_rt_scan(_MUs[:, j], "eff")[0] for j in range(10)]
    _me = [_rt_scan(_MUs[:, j], "eq4")[0] for j in range(10)]
    _pc = np.argsort(np.argsort(_mc)) + 1
    _pe = np.argsort(np.argsort(_me)) + 1
    _dir = bool(_mc[_rt_j4] > _mc[_rt_j5] and _me[_rt_j4] < _me[_rt_j5])
    _chg = [_RT_STATIONS[k]["id"] for k in range(10) if _pc[k] != _pe[k]]
    _rt_seed_rows.append({"seed": NEW_SEED + _s,
                          "S4_mean_eff": _mc[_rt_j4], "S4_mean_eq": _me[_rt_j4],
                          "S5_mean_eff": _mc[_rt_j5], "S5_mean_eq": _me[_rt_j5],
                          "S6_mean_eff": _mc[_rt_j6], "S6_mean_eq": _me[_rt_j6],
                          "swap_direction_preserved": int(_dir),
                          "other_orders_unchanged": int(all(k in _swapped for k in _chg)),
                          "contested_places_moved": int(_pc[_rt_j4] - _pe[_rt_j4]),
                          "S5_S6_order_unchanged": int((_pc[_rt_j5] > _pc[_rt_j6]) == (_pe[_rt_j5] > _pe[_rt_j6])),
                          "stations_reordered": ",".join(_chg)})
_rt_seed_dir = sum(r["swap_direction_preserved"] for r in _rt_seed_rows)
_rt_seed_oth = sum(r["other_orders_unchanged"] for r in _rt_seed_rows)
_rt_seed_two = sum(1 for r in _rt_seed_rows
                   if r["contested_places_moved"] == 2 and r["S5_S6_order_unchanged"])
print("   re-seeded panels: swap direction preserved %d/%d, every other order unchanged %d/%d"
      % (_rt_seed_dir, _RT_RESEED_N, _rt_seed_oth, _RT_RESEED_N))

# ---- robustness (b): the Fehr-Schmidt grid on the seed-202603 panel -----
_rt_fs_rows = []
_mc0 = [r["mean_eff"] for r in _rt_rows]
for _rho in _RT_FS_RHO:
    for _th in _RT_FS_THETA:
        if _th > _rho:
            continue
        _me = [_rt_scan(_rt_MU[:, j], "eq4", _rho, _th)[0] for j in range(10)]
        _pc = np.argsort(np.argsort(_mc0)) + 1
        _pe = np.argsort(np.argsort(_me)) + 1
        _w4, _ = _rt_project_uniform(_rt_MU[:, _rt_j4], _me[_rt_j4])
        _chg = [_RT_STATIONS[k]["id"] for k in range(10) if _pc[k] != _pe[k]]
        _rt_fs_rows.append({"rho": _rho, "theta": _th,
                            "S4_mean_eq": _me[_rt_j4], "S5_mean_eq": _me[_rt_j5],
                            "swap_direction_preserved": int(_me[_rt_j4] < _me[_rt_j5]),
                            "S4_adv_share_eq": float(_w4[_rt_adv].sum()),
                            "S4_weight_gini_eq": _gini_vec(_w4),
                            "other_orders_unchanged": int(all(k in _swapped for k in _chg)),
                            "stations_reordered": ",".join(_chg)})
_rt_fs_dir = sum(r["swap_direction_preserved"] for r in _rt_fs_rows)
_rt_fs_adv = (min(r["S4_adv_share_eq"] for r in _rt_fs_rows),
              max(r["S4_adv_share_eq"] for r in _rt_fs_rows))
print("   Fehr-Schmidt grid: swap direction preserved %d/%d, S4 advocate share in [%.3f, %.3f]"
      % (_rt_fs_dir, len(_rt_fs_rows), _rt_fs_adv[0], _rt_fs_adv[1]))

_rt_ids = [s["id"] for s in _RT_STATIONS]
write("fig6-11_rt_case.xlsx", {
    "config": cfg({
        "case": "V -- rail-transit station accessibility with stakeholder equity (Section 6.6)",
        "figures": "fig6-11_rt_equity",
        "labels": "fig:rt-equity, tab:rt-results",
        "source_paper": "chen2024railtransit",
        "mechanism_only": ("synthetic instrument and panel; mirrors the source "
                           "study at the level of MECHANISM only -- equity "
                           "weighting reorders priorities -- and none of its "
                           "findings"),
        "synthetic": 1, "seed": NEW_SEED,
        "n_stakeholders": _rt_N, "n_stations": 10,
        "scale_min": 0.0, "scale_max": 10.0,
        "rho": _RT_RHO, "theta": _RT_THETA, "kappa": 2,
        "leniency_sd": _RT_LENIENCY_SD, "noise_sd": _RT_NOISE_SD,
        "common_sigma": _RT_SIGMA,
        "generator_draw_order": ("numpy default_rng(202603): 24 leniency draws N(0, 0.15^2), "
                                 "one per stakeholder; then 240 scalar noise draws N(0, 0.25^2) "
                                 "station-major (S1 stakeholders 1..24, then S2, ...); then the "
                                 "40 Dirichlet(1,...,1) SQP start vectors"),
        "generator_clip": "each mean clipped to [0, 10]",
        "generator_clip_binding": int(_rt_clip_binding),
        "overlap": ("def:consensus for equal-variance normals, closed form over the real "
                    "line: 2 Phi(-|mu_i - m| / (2 sigma)); no truncation, no quadrature"),
        "regime_eff": "consensus only -- the mean overlap; the confidence objective is dropped",
        "regime_eq": ("EQ4 -- Sen's abbreviated welfare form, mean parabolic-normalized "
                      "Fehr-Schmidt utility times one minus the Gini of the utilities, "
                      "Ubar (1 - G(U)); the confidence objective is dropped"),
        "confidence_objective": ("dropped from both programs: with a common sigma the "
                                 "aggregate sd is constant over the simplex"),
        "solver": ("multi-start sequential quadratic programming: scipy.optimize.minimize "
                   "method SLSQP, finite-difference gradients, bounds [0,1], equality "
                   "constraint sum w = 1; both regimes; best objective over the starts retained"),
        "solver_starts": "uniform vector plus %d Dirichlet(1,...,1) draws (see generator_draw_order), shared by every station and regime" % _RT_K_STARTS,
        "solver_ftol": _RT_SQP_FTOL, "solver_maxiter": _RT_SQP_MAXITER,
        "certification": ("every objective depends on w only through m = w.mu (common sigma); "
                          "a dense scan of m over [min mu, max mu] with %d points and a bounded "
                          "refinement (xatol %g) is the global solver of the 1-D problem; the build "
                          "aborts unless the SQP best is within %g (objective) and %g (m) of it"
                          % (_RT_SCAN_POINTS, _RT_SCAN_XATOL, _RT_CERT_OBJ_TOL, _RT_CERT_M_TOL)),
        "reporting_rule": ("each regime reports the point of its optimal level set "
                           "{w in simplex : w.mu = m*} nearest to the uniform vector "
                           "(min sum w_i^2), a convex QP solved by SLSQP (ftol 1e-16) and "
                           "cross-checked against its KKT form w_i = max(0, 1/n + a + b mu_i)"),
        "priority_rule": "ascending collective mean (worst station first)",
        "robustness_reseed": ("%d further panels under seeds %d..%d, same generator and draw "
                              "order, both regimes solved by the certified 1-D scan"
                              % (_RT_RESEED_N, NEW_SEED + 1, NEW_SEED + _RT_RESEED_N)),
        "robustness_reseed_swap_direction": "%d/%d" % (_rt_seed_dir, _RT_RESEED_N),
        "robustness_reseed_other_orders_unchanged": "%d/%d" % (_rt_seed_oth, _RT_RESEED_N),
        "robustness_reseed_contested_moves_two_places": "%d/%d (S5 and S6 keep their order)" % (_rt_seed_two, _RT_RESEED_N),
        "robustness_fs_grid": ("rho in {%s}, vartheta in {%s}, vartheta <= rho, %d combinations, "
                               "seed-202603 panel, equity regime solved by the certified 1-D scan"
                               % (", ".join(str(x) for x in _RT_FS_RHO),
                                  ", ".join(str(x) for x in _RT_FS_THETA), len(_rt_fs_rows))),
        "robustness_fs_swap_direction": "%d/%d" % (_rt_fs_dir, len(_rt_fs_rows)),
        "robustness_fs_S4_adv_share_range": "%.4f .. %.4f" % _rt_fs_adv,
        "x_label": "aggregation regime",
        "y_label": "collective accessibility index",
        "eff_tick": "consensus only",
        "eq_tick": "equity aware (EQ4)",
        "contested_station": _rt_contested,
        "swapped": ",".join(_swapped),
        "weight_gini_eff_avg": _rt_wg_eff,
        "weight_gini_eq_avg": _rt_wg_eq,
        "max_uncontested_mean_gap": _rt_unc_gap,
        "max_uncontested_mean_gap_station": _rt_unc_gap_station,
        "uncontested_gaps_below_threshold": "%d/%d below %g (uncontested = every station but the contested one)"
                                            % (_rt_unc_below, len(_rt_unc_gaps), _RT_GAP_THRESHOLD),
        "print_dp_check": "SQP and scan means agree when rounded to %d dp at every solve" % _RT_PRINT_DP,
    }),
    "constituencies": pd.DataFrame(
        [{"constituency": c[0], "key": c[1], "size": c[2]} for c in _RT_CONST]),
    "stations": pd.DataFrame(_RT_STATIONS),
    "panel": pd.DataFrame({"expert": np.arange(1, _rt_N + 1),
                           "constituency": _rt_cid, "leniency": _rt_len,
                           "sigma": _rt_SD}),
    "panel_mu": pd.DataFrame(_rt_MU, columns=_rt_ids),
    "results": pd.DataFrame(_rt_rows),
    "weights_eff": pd.DataFrame(np.column_stack(_rt_W["eff"]), columns=_rt_ids),
    "weights_eq": pd.DataFrame(np.column_stack(_rt_W["eq"]), columns=_rt_ids),
    "sqp_starts": pd.DataFrame(np.vstack(_rt_starts),
                               columns=["w%d" % i for i in range(1, _rt_N + 1)]),
    "certification": pd.DataFrame(_rt_cert),
    "robustness_seeds": pd.DataFrame(_rt_seed_rows),
    "robustness_fs": pd.DataFrame(_rt_fs_rows),
})

# =====================================================================
# CASE STUDY III (Section 6.4, building digital twin maturity, FA-LSCOG)
#   -> Figure fig6-8_bdt_q1agg        (fig:bdt-q1agg)
#   -> Figure fig6-9_bdt_profile      (fig:bdt-profile)
#   -> Figure fig6-10_bdt_sensitivity (fig:bdt-sensitivity)
#   -> Tables tab:bdt-groups, tab:bdt-results
#
# GENERATED AND SOLVED (since 2026-09-14; before that every number of the
# case was a typed constant).  Every printed number of the case is computed
# here from the stated inputs under seed 202603:
#   1. a 15-expert x 22-indicator panel of truncated Weibull densities
#      (eq:bdt-weibull-trunc) generated from stated dimension design
#      levels, stratum offsets, a per-expert leniency and a per-cell noise,
#      with the shape drawn uniformly on a stated range and the scale
#      solved so that the TRUNCATED mean equals the target;
#   2. a stated 15 x 3 professional-attribute matrix clustered by k-means
#      (Lloyd's algorithm, standardized columns, seeded restarts) into the
#      three strata, and TOPSIS on the raw cluster centroids (vector
#      normalization, equal criterion weights, benefit criteria) giving
#      the inter-group weights Omega = closeness / sum of closeness;
#   3. the intra-group program of eq:bdt-intra as the book prints it,
#         max_w  delta*Phi~(w) - (1-delta)*V~(w) - lambda_G*G(w)
#      (Bonferroni(1,1) collective fairness of the power-normalized
#      Fehr-Schmidt utilities of the overlaps, the quantile-average
#      variance, both min-max normalized over a sampled simplex, and the
#      weight-Gini influence-dispersion regularizer of Chapter 4), solved
#      for each (subgroup, indicator) and each delta in {0, ..., 0.5} by
#      multi-start SLSQP;
#   4. quantile averaging under Omega (inter-group), equal indicator
#      weights inside a dimension, and best-worst (BWM linear model)
#      dimension weights from stated comparison vectors, up to the global
#      maturity distribution F_G;
#   5. the delta sweep of Phi, V, Gini(w) and the global maturity.
# Random draws, in order: rng_panel (leniency 15, noise 15x22, shape
# 15x22); rng_kmeans (20 restarts x 3 initial centroids); rng_solve (per
# program, group-major then indicator: 300 Dirichlet(1) normalization
# points; then per delta, group, indicator: 12 Dirichlet(1) starts).
# =====================================================================
print("\n-- generating and solving Case III (fig6-8_bdt_case.xlsx) ...")
from scipy.optimize import minimize as _sp_minimize, linprog as _sp_linprog
from scipy.special import gamma as _sp_gamma, gammainc as _sp_gammainc

_BDT = dict(
    seed=NEW_SEED,
    N=15, K=3,
    scale_min=0.0, scale_max=5.0, n_levels=5,
    dim_names=("D1 Instrumented Asset", "D2 BDT Model", "D3 BDT Data",
               "D4 Connection & Interaction", "D5 Function & Service",
               "D6 System Perspective", "D7 Organization Perspective"),
    dim_kind=("tech", "tech", "tech", "tech", "tech", "system", "org"),
    dim_sizes=(3, 3, 4, 3, 3, 3, 3),                     # tab:bdt-instrument
    # generator: stated design inputs
    dim_design_level=(2.75, 2.65, 2.70, 2.55, 2.50, 2.40, 2.80),
    indicator_pattern_halfwidth=0.05,   # within a dimension the indicator targets run
                                        # from level-0.05 to level+0.05 (zero mean)
    stratum_offset=(-0.20, -0.05, +0.20),   # G1 mixed, G2 junior, G3 senior
    leniency_sd=0.10,                   # per-expert leniency, N(0, sd)
    noise_sd=0.08,                      # per-(expert, indicator) noise, N(0, sd)
    shape_range=(4.5, 6.0),             # kappa ~ U(a, b): member sd about 0.50-0.66
    target_clip=(1.0, 4.5),             # target means clipped to this range
    # behavioral parameters and the fairness normalization
    rho=0.4, vartheta=0.2, power_kappa=2.0, bonferroni_order=(1, 1),
    # the intra-group program
    lambda_G=0.5,                       # weight-Gini regularizer coefficient
    deltas=(0.0, 0.1, 0.2, 0.3, 0.4, 0.5),
    operating_delta=0.5,
    # numerics
    L=257,                              # quantile grid, midpoints (l-0.5)/L
    L_fig=4001,                         # finer quantile grid on which the Figure 6.8 densities are drawn
    NX=501,                             # x grid on [0,5] for the overlap integrals (trapezoid)
    norm_sample=300,                    # Dirichlet(1) points for the min-max ranges (+ vertices + uniform)
    n_random_starts=12,                 # Dirichlet(1) starts per program (+ uniform + best sampled point)
    slsqp_ftol=1e-10, slsqp_maxiter=300,
    # k-means and TOPSIS
    kmeans_restarts=20, kmeans_maxiter=100,
    topsis_weights=(1.0 / 3.0, 1.0 / 3.0, 1.0 / 3.0),
    # best-worst method (linear model): best D1, worst D6
    bwm_best="D1", bwm_worst="D6",
    bwm_best_to_others=(1, 2, 1, 2, 2, 3, 2),
    bwm_others_to_worst=(3, 2, 3, 2, 2, 1, 2),
    bwm_consistency_index=1.00,         # Rezaei (2015) CI for a_BW = 3
)
_BDT_HI = _BDT["scale_max"]
_BDT_SIZES = (4, 6, 5)                  # designed strata; k-means must recover them
_BDT_STRATA = ("mixed experience", "junior, broad but shallow project record",
               "senior, deep digital-twin experience")
_BDT_COLORS = ("blue", "amber", "teal")
# the stated 15 x 3 professional-attribute matrix: years of experience,
# credential level (1-5), digital-twin project count (rows e1..e15)
_BDT_ATTR = np.array([
    [12, 4, 3], [8, 3, 3], [14, 4, 4], [10, 4, 4],                        # e1-e4
    [3, 2, 6], [4, 2, 7], [2, 2, 6], [5, 3, 8], [3, 2, 6], [4, 3, 7],     # e5-e10
    [18, 5, 5], [15, 4, 5], [22, 5, 6], [17, 4, 5], [20, 4, 6],           # e11-e15
], float)
_BDT_ATTR_NAMES = ("years_experience", "credential_level", "dt_projects")


# ---- truncated Weibull on [0, 5]  (eq:bdt-weibull-trunc) ---------------------
def _bdt_H(x, k, lam):
    return 1.0 - np.exp(-(x / lam) ** k)


def _bdt_h(x, k, lam):
    x = np.asarray(x, float)
    with np.errstate(divide="ignore", invalid="ignore"):
        v = (k / lam) * (x / lam) ** (k - 1) * np.exp(-(x / lam) ** k)
    return np.where(x > 0, v, 0.0)


def _bdt_pdf(x, k, lam):
    return _bdt_h(x, k, lam) / _bdt_H(_BDT_HI, k, lam)


def _bdt_quantile(p, k, lam):
    return lam * (-np.log1p(-p * _bdt_H(_BDT_HI, k, lam))) ** (1.0 / k)


def _bdt_trunc_mean(k, lam):
    """closed form: lambda Gamma(1+1/k) P(1+1/k, (5/lambda)^k) / H(5)."""
    a = 1.0 + 1.0 / k
    z = (_BDT_HI / lam) ** k
    return lam * _sp_gamma(a) * _sp_gammainc(a, z) / (1.0 - np.exp(-z))


def _bdt_scale_for_mean(k, target):
    """vectorized bisection: the scale at which the TRUNCATED mean equals target."""
    lo = np.full_like(k, 0.5, dtype=float)
    hi = np.full_like(k, 8.0, dtype=float)
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        below = _bdt_trunc_mean(k, mid) < target
        lo = np.where(below, mid, lo)
        hi = np.where(below, hi, mid)
    return 0.5 * (lo + hi)


# ---- 1. the panel ---------------------------------------------------------------
_rng_bdt_panel = np.random.default_rng(_BDT["seed"])
_bdt_N, _bdt_K = _BDT["N"], _BDT["K"]
_bdt_group_of = np.repeat(np.arange(_bdt_K), _BDT_SIZES)
_bdt_dim_of = np.repeat(np.arange(7), _BDT["dim_sizes"])
_bdt_M = len(_bdt_dim_of)
_bdt_ind_target = np.zeros(_bdt_M)
for _b in range(7):
    _idx = np.where(_bdt_dim_of == _b)[0]
    _hw = _BDT["indicator_pattern_halfwidth"]
    _bdt_ind_target[_idx] = _BDT["dim_design_level"][_b] + np.linspace(-_hw, _hw, len(_idx))
_bdt_leniency = _rng_bdt_panel.normal(0.0, _BDT["leniency_sd"], _bdt_N)
_bdt_noise = _rng_bdt_panel.normal(0.0, _BDT["noise_sd"], (_bdt_N, _bdt_M))
_bdt_shape = _rng_bdt_panel.uniform(_BDT["shape_range"][0], _BDT["shape_range"][1],
                                    (_bdt_N, _bdt_M))
_bdt_target = (_bdt_ind_target[None, :]
               + np.array(_BDT["stratum_offset"])[_bdt_group_of][:, None]
               + _bdt_leniency[:, None] + _bdt_noise)
_bdt_target = np.clip(_bdt_target, _BDT["target_clip"][0], _BDT["target_clip"][1])
_bdt_scale = _bdt_scale_for_mean(_bdt_shape, _bdt_target)
_bdt_P = (np.arange(_BDT["L"]) + 0.5) / _BDT["L"]
_bdt_X = np.linspace(0.0, _BDT_HI, _BDT["NX"])
_bdt_DX = float(_bdt_X[1] - _bdt_X[0])
_bdt_member_sd = np.zeros((_bdt_N, _bdt_M))
for _i in range(_bdt_N):
    for _m in range(_bdt_M):
        _q = _bdt_quantile(_bdt_P, _bdt_shape[_i, _m], _bdt_scale[_i, _m])
        _bdt_member_sd[_i, _m] = float(np.sqrt(np.mean((_q - _q.mean()) ** 2)))
assert np.allclose(_bdt_trunc_mean(_bdt_shape, _bdt_scale), _bdt_target, atol=1e-6), \
    "BDT panel: the truncated means do not hit their targets"
print("   panel: %d experts x %d indicators; member sd %.3f-%.3f (mean %.3f)"
      % (_bdt_N, _bdt_M, _bdt_member_sd.min(), _bdt_member_sd.max(), _bdt_member_sd.mean()))


# ---- 2. k-means on the attribute matrix, TOPSIS on the centroids ----------------
def _bdt_kmeans(Xr, K, rng, restarts, maxiter):
    """Lloyd's algorithm on standardized columns; `restarts` seeded random
    initializations (K distinct rows), the lowest inertia kept."""
    Z = (Xr - Xr.mean(0)) / Xr.std(0)
    best = None
    for r in range(restarts):
        c = Z[rng.choice(len(Z), K, replace=False)]
        for _ in range(maxiter):
            lab = np.argmin(((Z[:, None, :] - c[None, :, :]) ** 2).sum(-1), axis=1)
            newc = np.array([Z[lab == k].mean(0) if np.any(lab == k) else c[k]
                             for k in range(K)])
            if np.allclose(newc, c):
                break
            c = newc
        inertia = float(sum(((Z[lab == k] - c[k]) ** 2).sum() for k in range(K)))
        if best is None or inertia < best[0] - 1e-12:
            best = (inertia, lab.copy(), r)
    inertia, lab, r = best
    # clusters are numbered in order of first appearance along e1..e15
    order = []
    for l in lab:
        if l not in order:
            order.append(l)
    lab = np.array([order.index(l) for l in lab])
    return inertia, lab, r


_rng_bdt_kmeans = np.random.default_rng(_BDT["seed"])
_bdt_inertia, _bdt_lab, _bdt_best_restart = _bdt_kmeans(
    _BDT_ATTR, _bdt_K, _rng_bdt_kmeans, _BDT["kmeans_restarts"], _BDT["kmeans_maxiter"])
_bdt_sizes = np.bincount(_bdt_lab, minlength=_bdt_K)
assert tuple(int(s) for s in _bdt_sizes) == _BDT_SIZES, \
    "k-means did not recover the designed 4/6/5 strata: %r" % (_bdt_sizes,)
assert np.array_equal(_bdt_lab, _bdt_group_of), "k-means membership differs from the design"
_bdt_cent = np.array([_BDT_ATTR[_bdt_lab == k].mean(0) for k in range(_bdt_K)])
# TOPSIS: vector normalization, stated criterion weights, all benefit criteria
_bdt_Xn = _bdt_cent / np.sqrt((_bdt_cent ** 2).sum(0))
_bdt_Vt = _bdt_Xn * np.array(_BDT["topsis_weights"])
_bdt_ideal, _bdt_anti = _bdt_Vt.max(0), _bdt_Vt.min(0)
_bdt_dpos = np.sqrt(((_bdt_Vt - _bdt_ideal) ** 2).sum(1))
_bdt_dneg = np.sqrt(((_bdt_Vt - _bdt_anti) ** 2).sum(1))
_bdt_close = _bdt_dneg / (_bdt_dpos + _bdt_dneg)
_bdt_Omega = _bdt_close / _bdt_close.sum()
print("   k-means strata %s (restart %d, inertia %.3f); TOPSIS Omega = %s"
      % (tuple(int(s) for s in _bdt_sizes), _bdt_best_restart, _bdt_inertia,
         np.round(_bdt_Omega, 3)))


# ---- 4a. best-worst method, linear model (Rezaei 2016) -------------------------
def _bdt_bwm(aB, aW, best, worst):
    n = len(aB)
    c = np.zeros(n + 1); c[-1] = 1.0
    A_ub, b_ub = [], []
    for j in range(n):
        if j != best:
            for sgn in (1.0, -1.0):
                row = np.zeros(n + 1); row[best] = sgn; row[j] = -sgn * aB[j]; row[-1] = -1.0
                A_ub.append(row); b_ub.append(0.0)
        if j != worst:
            for sgn in (1.0, -1.0):
                row = np.zeros(n + 1); row[j] = sgn; row[worst] = -sgn * aW[j]; row[-1] = -1.0
                A_ub.append(row); b_ub.append(0.0)
    A_eq = np.r_[np.ones(n), 0.0][None, :]
    res = _sp_linprog(c, A_ub=np.array(A_ub), b_ub=np.array(b_ub), A_eq=A_eq, b_eq=[1.0],
                      bounds=[(0.0, None)] * (n + 1), method="highs")
    assert res.success, "BWM linear program failed: %s" % res.message
    return res.x[:n], float(res.x[-1])


_bdt_dim_ids = ["D%d" % (b + 1) for b in range(7)]
_bdt_dw, _bdt_xi = _bdt_bwm(np.array(_BDT["bwm_best_to_others"], float),
                            np.array(_BDT["bwm_others_to_worst"], float),
                            _bdt_dim_ids.index(_BDT["bwm_best"]),
                            _bdt_dim_ids.index(_BDT["bwm_worst"]))
_bdt_dw = _bdt_dw / _bdt_dw.sum()
_bdt_CR = _bdt_xi / _BDT["bwm_consistency_index"]
print("   BWM weights %s (xi %.4f, consistency ratio %.4f)" % (np.round(_bdt_dw, 4), _bdt_xi, _bdt_CR))


# ---- 3. the intra-group program ----------------------------------------------------
class _BdtProgram:
    """max_w delta*Phi~(w) - (1-delta)*V~(w) - lambda_G*G(w) on the simplex of one
    subgroup for one indicator (eq:bdt-intra)."""

    def __init__(self, members, ks, lams):
        self.members = members
        self.n = len(ks)
        self.Q = np.array([_bdt_quantile(_bdt_P, k, l) for k, l in zip(ks, lams)])   # n x L
        fq = np.array([_bdt_pdf(self.Q[i], ks[i], lams[i]) for i in range(self.n)])
        self.inv_fq = 1.0 / np.maximum(fq, 1e-300)
        self.fx = np.array([_bdt_pdf(_bdt_X, k, l) for k, l in zip(ks, lams)])     # n x NX

    def qa(self, w):
        return w @ self.Q

    def density_on_x(self, w):
        # f_QA(Q(p)) = 1 / (dQ/dp),  dQ/dp = sum_i w_i / f_i(Q_i(p))
        q = w @ self.Q
        dq = w @ self.inv_fq
        return np.interp(_bdt_X, q, 1.0 / dq, left=0.0, right=0.0)

    def overlaps(self, w):
        f = self.density_on_x(w)
        return _trapz(np.minimum(f[None, :], self.fx), dx=_bdt_DX, axis=1)

    def raw(self, w):
        q = w @ self.Q
        v = float(np.mean((q - q.mean()) ** 2))
        A = self.overlaps(w)
        Phi, _ = _fs_phi(A[None, :], _BDT["rho"], _BDT["vartheta"])
        return float(Phi[0]), v, A

    def set_range(self, rng):
        n = self.n
        S = rng.dirichlet(np.ones(n), _BDT["norm_sample"])
        S = np.vstack([S, np.eye(n), np.ones((1, n)) / n])
        vals = np.array([self.raw(w)[:2] for w in S])
        self.sample, self.sample_vals = S, vals
        self.phi_min, self.phi_max = float(vals[:, 0].min()), float(vals[:, 0].max())
        self.v_min, self.v_max = float(vals[:, 1].min()), float(vals[:, 1].max())

    def tilde(self, phi, v):
        pt = (phi - self.phi_min) / (self.phi_max - self.phi_min) if self.phi_max > self.phi_min else 0.0
        vt = (v - self.v_min) / (self.v_max - self.v_min) if self.v_max > self.v_min else 0.0
        return pt, vt

    def objective(self, w, delta):
        w = np.clip(w, 0.0, None)
        s = w.sum()
        w = w / s if s > 0 else np.ones(self.n) / self.n
        phi, v, _ = self.raw(w)
        pt, vt = self.tilde(phi, v)
        return delta * pt - (1.0 - delta) * vt - _BDT["lambda_G"] * _gini_vec(w)

    def solve(self, delta, rng):
        n = self.n
        starts = list(rng.dirichlet(np.ones(n), _BDT["n_random_starts"]))
        starts.append(np.ones(n) / n)
        sv = np.array([delta * self.tilde(p, v)[0] - (1.0 - delta) * self.tilde(p, v)[1]
                       - _BDT["lambda_G"] * _gini_vec(w)
                       for (p, v), w in zip(self.sample_vals, self.sample)])
        starts.append(self.sample[int(np.argmax(sv))])
        best_w, best_f, best_s = None, -np.inf, -1
        cons = ({"type": "eq", "fun": lambda w: w.sum() - 1.0},)
        for s_idx, w0 in enumerate(starts):
            res = _sp_minimize(lambda w: -self.objective(w, delta), w0, method="SLSQP",
                               bounds=[(0.0, 1.0)] * n, constraints=cons,
                               options={"ftol": _BDT["slsqp_ftol"],
                                        "maxiter": _BDT["slsqp_maxiter"]})
            w = np.clip(res.x, 0.0, None)
            w /= w.sum()
            f = self.objective(w, delta)
            if f > best_f:
                best_f, best_w, best_s = f, w, s_idx
        return best_w, best_f, best_s, len(starts)


_rng_bdt_solve = np.random.default_rng(_BDT["seed"])
_bdt_progs = {}
for _k in range(_bdt_K):
    _mem = np.where(_bdt_group_of == _k)[0]
    for _m in range(_bdt_M):
        _Pm = _BdtProgram(_mem, _bdt_shape[_mem, _m], _bdt_scale[_mem, _m])
        _Pm.set_range(_rng_bdt_solve)
        _bdt_progs[(_k, _m)] = _Pm

_bdt_rows_w, _bdt_rows_ind, _bdt_rows_dim, _bdt_rows_sweep = [], [], [], []
_bdt_store = {}
import time as _time
for _delta in _BDT["deltas"]:
    _t1 = _time.time()
    _repQ = np.zeros((_bdt_K, _bdt_M, _BDT["L"]))
    _repW = {}
    _phis, _phis_t, _ginis, _vgroup = [], [], [], []
    for _k in range(_bdt_K):
        for _m in range(_bdt_M):
            _Pm = _bdt_progs[(_k, _m)]
            _w, _f, _s, _ns = _Pm.solve(_delta, _rng_bdt_solve)
            _phi, _v, _A = _Pm.raw(_w)
            _pt, _vt = _Pm.tilde(_phi, _v)
            _g = _gini_vec(_w)
            _phis.append(_phi); _phis_t.append(_pt); _ginis.append(_g); _vgroup.append(_v)
            _repQ[_k, _m] = _Pm.qa(_w)
            _repW[(_k, _m)] = _w
            _row = {"delta": _delta, "group": "G%d" % (_k + 1), "indicator": "q%d" % (_m + 1),
                    "dimension": "D%d" % (_bdt_dim_of[_m] + 1)}
            for _i in range(_bdt_N):
                _row["w_e%d" % (_i + 1)] = (float(_w[list(_Pm.members).index(_i)])
                                           if _i in _Pm.members else np.nan)
            for _j, _i in enumerate(_Pm.members):
                _row["A_e%d" % (_i + 1)] = float(_A[_j])
            _row.update({"Phi": _phi, "Phi_tilde": _pt, "V_group": _v, "V_tilde": _vt,
                         "gini_w": _g, "objective": _f,
                         "Phi_min": _Pm.phi_min, "Phi_max": _Pm.phi_max,
                         "V_min": _Pm.v_min, "V_max": _Pm.v_max,
                         "n_starts": _ns, "best_start": _s,
                         "group_rep_mean": float(_repQ[_k, _m].mean())})
            _bdt_rows_w.append(_row)
    # inter-group quantile averaging under Omega, then the indicator hierarchy
    _indQ = np.einsum("k,kml->ml", _bdt_Omega, _repQ)
    _dimQ = np.array([_indQ[_bdt_dim_of == b].mean(axis=0) for b in range(7)])   # equal indicator weights
    _globQ = _bdt_dw @ _dimQ
    _gmu = float(_globQ.mean())
    _gvar = float(np.mean((_globQ - _gmu) ** 2))
    _dmu = _dimQ.mean(axis=1)
    _dvar = ((_dimQ - _dmu[:, None]) ** 2).mean(axis=1)
    _imu = _indQ.mean(axis=1)
    _ivar = ((_indQ - _imu[:, None]) ** 2).mean(axis=1)
    _gm = _repQ.mean(axis=2)                                        # K x M group rep means
    _mass2 = float(np.mean(_globQ < 2.0))
    _level = int(min(np.floor(_gmu) + 1, 5))
    _bdt_store[_delta] = dict(repQ=_repQ, repW=_repW, indQ=_indQ, dimQ=_dimQ, globQ=_globQ,
                              gmu=_gmu, gvar=_gvar, dmu=_dmu, dvar=_dvar, imu=_imu, gm=_gm)
    _bdt_rows_sweep.append({"delta": _delta, "global_maturity": _gmu, "aggregate_variance": _gvar,
                            "fairness_Phi": float(np.mean(_phis)),
                            "fairness_Phi_tilde": float(np.mean(_phis_t)),
                            "weight_gini": float(np.mean(_ginis)),
                            "mean_group_variance": float(np.mean(_vgroup)),
                            "max_group_variance": float(np.max(_vgroup)),
                            "mass_below_2": _mass2, "level_band": _level,
                            "n_vertex_solutions": int(sum(1 for (k, m), w in _repW.items() if w.max() > 0.999))})
    for _m in range(_bdt_M):
        _bdt_rows_ind.append({"delta": _delta, "indicator": "q%d" % (_m + 1),
                              "dimension": "D%d" % (_bdt_dim_of[_m] + 1),
                              "G1_mean": float(_gm[0, _m]), "G2_mean": float(_gm[1, _m]),
                              "G3_mean": float(_gm[2, _m]),
                              "collective_mean": float(_imu[_m]), "collective_variance": float(_ivar[_m])})
    for _b in range(7):
        _bdt_rows_dim.append({"delta": _delta, "dimension": _bdt_dim_ids[_b], "weight": float(_bdt_dw[_b]),
                              "mean": float(_dmu[_b]), "variance": float(_dvar[_b])})
    print("   delta %.1f  maturity %.4f  V %.4f  Phi %.4f  Gini(w) %.4f  q1 groups %s -> %.4f  [%.0fs]"
          % (_delta, _gmu, _gvar, np.mean(_phis), np.mean(_ginis), np.round(_gm[:, 0], 3), _imu[0],
             _time.time() - _t1))

_bdt_op = _bdt_store[_BDT["operating_delta"]]
# Figure 6.8 data: q1 group representatives and the inter-group collective at the
# operating point, as quantile functions and as densities 1/(dQ/dp) on the x grid
# (the solved weights are applied on a finer quantile grid so that the drawn
# tails reach the ends of the support instead of stopping at the first and last
# midpoint of the solution grid)
_bdt_Pf = (np.arange(_BDT["L_fig"]) + 0.5) / _BDT["L_fig"]
_bdt_q1_Q = np.zeros((_bdt_K, _BDT["L_fig"]))
_bdt_q1_dQ = np.zeros((_bdt_K, _BDT["L_fig"]))
for _k in range(_bdt_K):
    _Pm = _bdt_progs[(_k, 0)]
    _w = _bdt_op["repW"][(_k, 0)]
    for _j, _i in enumerate(_Pm.members):
        _Qi = _bdt_quantile(_bdt_Pf, _bdt_shape[_i, 0], _bdt_scale[_i, 0])
        _bdt_q1_Q[_k] += _w[_j] * _Qi
        _bdt_q1_dQ[_k] += _w[_j] / np.maximum(_bdt_pdf(_Qi, _bdt_shape[_i, 0], _bdt_scale[_i, 0]), 1e-300)
assert np.allclose(_bdt_q1_Q.mean(axis=1), _bdt_op["repQ"][:, 0, :].mean(axis=1), atol=2e-3)
_bdt_q1_Qc = _bdt_Omega @ _bdt_q1_Q
_bdt_q1_dQc = _bdt_Omega @ _bdt_q1_dQ
_bdt_q1_f = [np.interp(_bdt_X, _bdt_q1_Q[k], 1.0 / _bdt_q1_dQ[k], left=0.0, right=0.0)
             for k in range(_bdt_K)]
_bdt_q1_fc = np.interp(_bdt_X, _bdt_q1_Qc, 1.0 / _bdt_q1_dQc, left=0.0, right=0.0)
_bdt_q1_mu = [float(_bdt_op["repQ"][k, 0, :].mean()) for k in range(_bdt_K)]   # means on the solution grid
_bdt_q1_muc = float(np.dot(_bdt_Omega, _bdt_q1_mu))            # QA mean identity
assert abs(_bdt_q1_muc - float(_bdt_q1_Qc.mean())) < 2e-3
for _k in range(_bdt_K):
    _mass = float(_trapz(_bdt_q1_f[_k], dx=_bdt_DX))
    _mx = float(_trapz(_bdt_X * _bdt_q1_f[_k], dx=_bdt_DX))
    assert abs(_mass - 1.0) < 0.01 and abs(_mx - _bdt_q1_mu[_k]) < 0.01, \
        "q1 density of G%d: mass %.4f mean %.4f vs %.4f" % (_k + 1, _mass, _mx, _bdt_q1_mu[_k])
assert abs(float(_trapz(_bdt_q1_fc, dx=_bdt_DX)) - 1.0) < 0.01
assert abs(float(_trapz(_bdt_X * _bdt_q1_fc, dx=_bdt_DX)) - _bdt_q1_muc) < 0.01

_bdt_level_names = ["Digital Model", "Digital Shadow", "Primary BDT", "Enhanced BDT", "Ideal BDT"]
_bdt_glob_level = _bdt_level_names[int(min(np.floor(_bdt_op["gmu"]), 4))]
print("   operating point: global maturity %.4f (%s), V %.4f, Phi %.4f, Gini(w) %.4f, P(F_G < 2) %.3f"
      % (_bdt_op["gmu"], _bdt_glob_level, _bdt_op["gvar"],
         _bdt_rows_sweep[-1]["fairness_Phi"], _bdt_rows_sweep[-1]["weight_gini"],
         _bdt_rows_sweep[-1]["mass_below_2"]))

_bdt_cfg = {
    "case": "III -- building digital twin maturity (Section 6.4)",
    "figures": "fig6-8_bdt_q1agg, fig6-9_bdt_profile, fig6-10_bdt_sensitivity",
    "labels": "fig:bdt-q1agg, fig:bdt-profile, fig:bdt-sensitivity",
    "source_paper": "chen2024bdt",
    "synthetic": 1,
    "seed": NEW_SEED,
    "generator": ("build_workbooks.py Case III block: generated panel, k-means + TOPSIS, "
                  "BWM, multi-start SLSQP intra-group solves, quantile-averaged hierarchy"),
    "rng_order": ("rng_panel(seed): leniency[15], noise[15x22], shape[15x22]; "
                  "rng_kmeans(seed): 20 restarts x choice of 3 rows; "
                  "rng_solve(seed): per program (group-major, indicator) 300 Dirichlet(1) "
                  "normalization points, then per delta/group/indicator 12 Dirichlet(1) starts"),
    "n_experts": _bdt_N, "n_indicators": _bdt_M, "n_dimensions": 7, "n_groups": _bdt_K,
    "scale_min": _BDT["scale_min"], "scale_max": _BDT["scale_max"], "n_levels": _BDT["n_levels"],
    "density_family": "two-parameter Weibull truncated to [0,5], eq:bdt-weibull-trunc",
    "dim_design_level": ",".join("%.2f" % v for v in _BDT["dim_design_level"]),
    "indicator_pattern": "linspace(level-%.2f, level+%.2f, n_b) inside dimension b" % (
        _BDT["indicator_pattern_halfwidth"], _BDT["indicator_pattern_halfwidth"]),
    "stratum_offset_G1_G2_G3": ",".join("%+.2f" % v for v in _BDT["stratum_offset"]),
    "leniency_sd": _BDT["leniency_sd"], "noise_sd": _BDT["noise_sd"],
    "shape_range": "U(%.1f, %.1f)" % _BDT["shape_range"],
    "target_clip": "[%.1f, %.1f]" % _BDT["target_clip"],
    "scale_rule": "lambda solved by bisection so that the truncated mean equals the target",
    "member_sd_min": float(_bdt_member_sd.min()), "member_sd_max": float(_bdt_member_sd.max()),
    "member_sd_mean": float(_bdt_member_sd.mean()),
    "program": ("max_w delta*Phi~(w) - (1-delta)*V~(w) - lambda_G*G(w), w in the subgroup simplex; "
                "no consensus term (alpha = 0, beta = 1 - delta in eq:fair-scalarized)"),
    "Phi": "Bonferroni mean of order (1,1) of the power-normalized (kappa=2) Fehr-Schmidt utilities of the overlaps",
    "V": "variance of the quantile-averaged aggregate (quantile form, midpoint rule on the p grid)",
    "G": "Gini coefficient of the weight vector (influence-dispersion regularizer, Chapter 4)",
    "rho": _BDT["rho"], "vartheta": _BDT["vartheta"], "power_kappa": _BDT["power_kappa"],
    "bonferroni_order": "(1,1)",
    "lambda_G": _BDT["lambda_G"],
    "deltas": ",".join("%.1f" % d for d in _BDT["deltas"]),
    "operating_delta": _BDT["operating_delta"],
    "normalization": ("min-max per program over 300 Dirichlet(1) points + the vertices + the uniform "
                      "point; ranges in intra_group_solutions (Phi_min, Phi_max, V_min, V_max)"),
    "solver": "scipy SLSQP, ftol %g, maxiter %d, finite-difference gradients" % (
        _BDT["slsqp_ftol"], _BDT["slsqp_maxiter"]),
    "starts": "%d Dirichlet(1) random starts + the uniform point + the best sampled point; best objective kept" % (
        _BDT["n_random_starts"]),
    "quantile_grid": "L = %d midpoints (l-1/2)/L" % _BDT["L"],
    "figure_quantile_grid": "L_fig = %d midpoints for the q1_quantiles and q1_densities sheets (Figure 6.8)" % _BDT["L_fig"],
    "x_grid": "%d equispaced points on [0,5]; overlaps by the trapezoid rule" % _BDT["NX"],
    "qa_density": "f(Q(p)) = 1 / sum_i w_i / f_i(Q_i(p)), interpolated onto the x grid",
    "inter_group": "quantile averaging under Omega (TOPSIS on the k-means centroids)",
    "indicator_weights": "equal inside a dimension",
    "dimension_weights": "best-worst method, linear model (Rezaei 2016), best %s, worst %s" % (
        _BDT["bwm_best"], _BDT["bwm_worst"]),
    "bwm_best": _BDT["bwm_best"], "bwm_worst": _BDT["bwm_worst"],
    "bwm_best_to_others": ",".join(str(v) for v in _BDT["bwm_best_to_others"]),
    "bwm_others_to_worst": ",".join(str(v) for v in _BDT["bwm_others_to_worst"]),
    "bwm_xi": _bdt_xi, "bwm_consistency_index": _BDT["bwm_consistency_index"],
    "bwm_consistency_ratio": _bdt_CR,
    "kmeans": "Lloyd's algorithm on standardized attribute columns, %d seeded restarts, min inertia kept" % (
        _BDT["kmeans_restarts"]),
    "kmeans_best_restart": _bdt_best_restart, "kmeans_inertia": _bdt_inertia,
    "kmeans_labeling": "clusters numbered in order of first appearance along e1..e15",
    "topsis": "vector normalization, criterion weights %s, all benefit criteria, Omega = closeness / sum" % (
        ",".join("%.4f" % v for v in _BDT["topsis_weights"])),
    "attribute_columns": ",".join(_BDT_ATTR_NAMES),
    "global_maturity": _bdt_op["gmu"], "global_level": _bdt_glob_level,
    "aggregate_variance": _bdt_op["gvar"],
    "fairness_Phi": _bdt_rows_sweep[-1]["fairness_Phi"],
    "weight_gini": _bdt_rows_sweep[-1]["weight_gini"],
    "mass_below_2": _bdt_rows_sweep[-1]["mass_below_2"],
    "indicator": "q1 -- Response and Control",
    "band_lo": 2.0, "band_hi": 3.0,
    "x_label_q1": "maturity level, Response and Control ($q_1$)",
    "x_label_profile": "maturity level",
    "y_label_q1": "probability density",
    "x_label_sensitivity": "fairness weight $\\delta$ in the intra-group program",
    "y_label_sensitivity": "value",
    "profile_offset": 2.0,
    "grid_points": _BDT["NX"],
}
_bdt_panel_rows = []
for _i in range(_bdt_N):
    for _m in range(_bdt_M):
        _bdt_panel_rows.append({"expert": "e%d" % (_i + 1), "group": "G%d" % (_bdt_group_of[_i] + 1),
                                "indicator": "q%d" % (_m + 1), "dimension": "D%d" % (_bdt_dim_of[_m] + 1),
                                "indicator_design_target": float(_bdt_ind_target[_m]),
                                "target_mean": float(_bdt_target[_i, _m]),
                                "kappa": float(_bdt_shape[_i, _m]), "lambda": float(_bdt_scale[_i, _m]),
                                "truncated_mean": float(_bdt_trunc_mean(_bdt_shape[_i, _m], _bdt_scale[_i, _m])),
                                "truncated_sd": float(_bdt_member_sd[_i, _m])})
_bdt_expert_rows = [{"expert": "e%d" % (_i + 1),
                     _BDT_ATTR_NAMES[0]: _BDT_ATTR[_i, 0], _BDT_ATTR_NAMES[1]: _BDT_ATTR[_i, 1],
                     _BDT_ATTR_NAMES[2]: _BDT_ATTR[_i, 2],
                     "group_design": "G%d" % (_bdt_group_of[_i] + 1),
                     "group_kmeans": "G%d" % (_bdt_lab[_i] + 1),
                     "leniency": float(_bdt_leniency[_i])} for _i in range(_bdt_N)]
_bdt_topsis_rows = []
for _k in range(_bdt_K):
    _bdt_topsis_rows.append({"group": "G%d" % (_k + 1),
                             "centroid_" + _BDT_ATTR_NAMES[0]: float(_bdt_cent[_k, 0]),
                             "centroid_" + _BDT_ATTR_NAMES[1]: float(_bdt_cent[_k, 1]),
                             "centroid_" + _BDT_ATTR_NAMES[2]: float(_bdt_cent[_k, 2]),
                             "norm_" + _BDT_ATTR_NAMES[0]: float(_bdt_Xn[_k, 0]),
                             "norm_" + _BDT_ATTR_NAMES[1]: float(_bdt_Xn[_k, 1]),
                             "norm_" + _BDT_ATTR_NAMES[2]: float(_bdt_Xn[_k, 2]),
                             "d_plus": float(_bdt_dpos[_k]), "d_minus": float(_bdt_dneg[_k]),
                             "closeness": float(_bdt_close[_k]), "Omega": float(_bdt_Omega[_k])})
_bdt_groups_rows = [{"group": "G%d" % (_k + 1), "stratum": _BDT_STRATA[_k], "size": int(_bdt_sizes[_k]),
                     "Omega": float(_bdt_Omega[_k]), "q1_mu": _bdt_q1_mu[_k],
                     "q1_variance": float(np.mean((_bdt_q1_Q[_k] - _bdt_q1_mu[_k]) ** 2)),
                     "color": _BDT_COLORS[_k]} for _k in range(_bdt_K)]
_bdt_dims_rows = [{"dimension": _BDT["dim_names"][_b], "id": _bdt_dim_ids[_b], "kind": _BDT["dim_kind"][_b],
                   "n_indicators": int(_BDT["dim_sizes"][_b]),
                   "mu": float(_bdt_op["dmu"][_b]), "variance": float(_bdt_op["dvar"][_b]),
                   "weight": float(_bdt_dw[_b]),
                   "level": _bdt_level_names[int(min(np.floor(_bdt_op["dmu"][_b]), 4))],
                   "bwm_best_to_others": _BDT["bwm_best_to_others"][_b],
                   "bwm_others_to_worst": _BDT["bwm_others_to_worst"][_b]} for _b in range(7)]
_bdt_q1_quant = pd.DataFrame({"p": _bdt_Pf, "Q_G1": _bdt_q1_Q[0], "Q_G2": _bdt_q1_Q[1], "Q_G3": _bdt_q1_Q[2],
                              "Q_collective": _bdt_q1_Qc})
_bdt_q1_dens = pd.DataFrame({"x": _bdt_X, "f_G1": _bdt_q1_f[0], "f_G2": _bdt_q1_f[1], "f_G3": _bdt_q1_f[2],
                             "f_collective": _bdt_q1_fc})
_bdt_glob_rows = [{"delta": d, "p": float(p), "Q_global": float(q)}
                  for d in _BDT["deltas"] for p, q in zip(_bdt_P, _bdt_store[d]["globQ"])]
write("fig6-8_bdt_case.xlsx", {
    "config": cfg(_bdt_cfg),
    "groups": _bdt_groups_rows,
    "dimensions": _bdt_dims_rows,
    "levels": [{"level": 1, "name": "Digital\nModel"}, {"level": 2, "name": "Digital\nShadow"},
               {"level": 3, "name": "Primary\nBDT"}, {"level": 4, "name": "Enhanced\nBDT"},
               {"level": 5, "name": "Ideal\nBDT"}],
    "sensitivity": _bdt_rows_sweep,
    "expert_attributes": _bdt_expert_rows,
    "kmeans_topsis": _bdt_topsis_rows,
    "panel_weibull": _bdt_panel_rows,
    "intra_group_solutions": _bdt_rows_w,
    "indicator_collectives": _bdt_rows_ind,
    "dimension_collectives": _bdt_rows_dim,
    "q1_quantiles": _bdt_q1_quant,
    "q1_densities": _bdt_q1_dens,
    "global_quantiles": _bdt_glob_rows,
})

print("\nAll workbooks written to", DATA)

# =====================================================================
# SELF-CHECKS (audit rule 12) -- run on the workbooks just written, so
# they hold for the artifacts themselves, not only for in-memory values.
# Dimensions, weight normalizations, probability normalizations, and the
# invariants of the solved outputs.  Any failure aborts the build.
# =====================================================================
print("\n-- rule-12 self-checks on the written workbooks ...")


def _wb(name):
    return pd.read_excel(os.path.join(DATA, name), sheet_name=None)


def _cfgd(sheets, sheet="config"):
    c = sheets[sheet]
    return dict(zip(c["key"].astype(str), c["value"]))


def _sums_to_one(v, what, tol=1e-9):
    s = float(np.asarray(v, float).sum())
    assert abs(s - 1.0) < tol, "%s sums to %.9f, not 1" % (what, s)


# (0) every workbook carries a config or provenance sheet with generator+seed
for _f in sorted(os.listdir(DATA)):
    if not _f.endswith(".xlsx"):
        continue
    _s = _wb(_f)
    _sheet = "config" if "config" in _s else ("provenance" if "provenance" in _s else None)
    assert _sheet is not None, "%s has neither a config nor a provenance sheet" % _f
    _d = _cfgd(_s, _sheet)
    for _k in ("generator", "seed", "synthetic"):
        assert _k in _d, "%s: %s sheet lacks the %r key" % (_f, _sheet, _k)
print("   provenance: every workbook names generator, seed, synthetic")

# (1) Chapter 2 running example: the written workbooks against the definitions
#     of chapter2.tex and the invariants of Algorithm 2.2.  Nothing here is
#     pinned to a printed constant; every expected value is recomputed from
#     the expert rows the workbooks carry.
def _ch2_overlap_from_rows(w, mus, sds):
    """def:consensus recomputed from workbook rows, each overlap exact (crossing points)."""
    m, s = float(w @ mus), float(w @ sds)
    return float(sum(_ch2_overlap_normal(mi, si, m, s) for mi, si in zip(mus, sds)))


def _ch2_overlap_from_rows_trapz(w, mus, sds):
    """def:consensus recomputed from workbook rows by an independent rule, the trapezoid
    rule on the recorded grid (cross-check of the exact form, tolerance 1e-6)."""
    m, s = float(w @ mus), float(w @ sds)
    fqa = _norm.pdf(CH2_X_GRID, m, s)
    return float(sum(_trapz(np.minimum(fqa, _norm.pdf(CH2_X_GRID, mi, si)), CH2_X_GRID) for mi, si in zip(mus, sds)))


# (1a) Table 2.1: the fits are the least squares of the elicited percentiles on
#      Phi^{-1}(p), rounded to one decimal, and the percentiles are the
#      one-decimal quantiles of the rounded fits (internal consistency)
_t21c = _wb("tab2-1_running_example_percentiles.xlsx")["table_2_1"]
_z5c = _norm.ppf([0.05, 0.25, 0.50, 0.75, 0.95])
for _, _r in _t21c.iterrows():
    _xh = _r[["p05", "p25", "p50", "p75", "p95"]].to_numpy(float)
    _c, *_ = np.linalg.lstsq(np.column_stack([np.ones(5), _z5c]), _xh, rcond=None)
    assert round(float(_c[0]), 1) == float(_r["fitted_mu"]) and round(float(_c[1]), 1) == float(_r["fitted_sigma"]), \
        "Table 2.1 %s: LS fit (%.3f, %.3f) does not round to the recorded (%.1f, %.1f)" % (
            _r["expert"], _c[0], _c[1], _r["fitted_mu"], _r["fitted_sigma"])
    assert abs(float(_c[0]) - float(_r["ls_mu_exact"])) < 1e-9 and abs(float(_c[1]) - float(_r["ls_sigma_exact"])) < 1e-9
    assert np.allclose(np.round(float(_r["fitted_mu"]) + float(_r["fitted_sigma"]) * _z5c, 1), _xh), \
        "Table 2.1 %s: elicited values are not the one-decimal quantiles of the fitted normal" % _r["expert"]
_t21_mu = _t21c["fitted_mu"].to_numpy(float)
_t21_sd = _t21c["fitted_sigma"].to_numpy(float)

# (1b) Figures 2.1 and 2.2: expert weights sum to one; the quantile-average row is
#      (w.mu, w.sigma) of the expert rows (prop:qa-properties(iii)); the
#      logarithmic-pool row is the normalized product of def:log-pool, checked both
#      by its precision-average closed form and by numerical normalization
for _f in ("fig2-1_linear_pool_vs_qa.xlsx", "fig2-2_three_pooling_operators.xlsx"):
    _g = _wb(_f)["gaussians"]
    _e = _g[_g["role"].astype(str).str.startswith("expert")]
    _sums_to_one(_e["weight"], "%s expert weights" % _f)
    _ew = _e["weight"].to_numpy(float); _em = _e["mu"].to_numpy(float); _es = _e["sigma"].to_numpy(float)
    _qa = _g[_g["legend"] == "quantile average"].iloc[0]
    assert abs(float(_qa["mu"]) - float(_ew @ _em)) < 1e-9 and abs(float(_qa["sigma"]) - float(_ew @ _es)) < 1e-9, \
        "%s: quantile-average row is not (w.mu, w.sigma) of the expert rows" % _f
    if "logarithmic pool" in set(_g["legend"].astype(str)):
        _lo = _g[_g["legend"] == "logarithmic pool"].iloc[0]
        _prec = float(np.sum(_ew / _es ** 2))
        assert abs(float(_lo["mu"]) - float(np.sum(_ew * _em / _es ** 2) / _prec)) < 1e-9
        assert abs(float(_lo["sigma"]) - _prec ** -0.5) < 1e-9
        _gx = np.exp(sum(wi * _norm.logpdf(CH2_X_GRID, mi, si) for wi, mi, si in zip(_ew, _em, _es)))
        _gx = _gx / _trapz(_gx, CH2_X_GRID)
        _mnum = float(_trapz(CH2_X_GRID * _gx, CH2_X_GRID))
        _snum = float(np.sqrt(_trapz((CH2_X_GRID - _mnum) ** 2 * _gx, CH2_X_GRID)))
        assert abs(_mnum - float(_lo["mu"])) < 1e-3 and abs(_snum - float(_lo["sigma"])) < 1e-3, \
            "%s: normalized product (%.4f, %.4f) disagrees with the recorded log pool" % (_f, _mnum, _snum)
        assert np.max(np.abs(_gx - _norm.pdf(CH2_X_GRID, float(_lo["mu"]), float(_lo["sigma"])))) < 1e-3
        # the Figure 2.2 panel is the rounded fit of Table 2.1
        assert np.allclose(_em, _t21_mu) and np.allclose(_es, _t21_sd), "Figure 2.2 experts differ from Table 2.1 fits"
print("   Chapter 2 figures: QA and log-pool rows agree with the definitions applied to the expert rows")

# (1c) Table 2.5: the solve of Algorithm 2.2 read back from the workbook
_t25s = _wb("tab2-5_biobjective_example.xlsx")
_t25c = _t25s["table_2_5"]; _bnd = _t25s["bounds"].set_index("bound"); _lvl = _t25s["level_set_alpha_star"].set_index("point")
_swp = _t25s["alpha_sweep"].sort_values("alpha").reset_index(drop=True); _cfg25 = _cfgd(_t25s)
_alpha_s = float(_cfg25["alpha_star"])
_W25 = _t25c[["w1", "w2", "w3", "w4"]].to_numpy(float)
_Amin_c, _Amax_c = float(_bnd.loc["A_min", "value"]), float(_bnd.loc["A_max", "value"])
_Vmin_c, _Vmax_c = float(_bnd.loc["V_min", "value"]), float(_bnd.loc["V_max", "value"])


def _ch2_obj_from_rows(w, alpha=_alpha_s):
    _a = _ch2_overlap_from_rows(w, _t21_mu, _t21_sd); _v = float(w @ _t21_sd) ** 2
    return alpha * (_a - _Amin_c) / (_Amax_c - _Amin_c) - (1 - alpha) * (_v - _Vmin_c) / (_Vmax_c - _Vmin_c)


for _k, _r in _t25c.iterrows():
    _w = _W25[_k]
    _sums_to_one(_w, "Table 2.5 row %d weights" % _k)
    assert np.all(_w >= -1e-12)
    assert abs(float(_r["A"]) - _ch2_overlap_from_rows(_w, _t21_mu, _t21_sd)) < 1e-9, "Table 2.5 row %d: A is not the overlap of def:consensus" % _k
    assert abs(float(_r["A"]) - _ch2_overlap_from_rows_trapz(_w, _t21_mu, _t21_sd)) < 1e-6, "Table 2.5 row %d: A disagrees with the independent trapezoid rule" % _k
    assert abs(float(_r["V"]) - float(_w @ _t21_sd) ** 2) < 1e-12, "Table 2.5 row %d: V is not (w.sigma)^2" % _k
    assert abs(float(_r["fQA_mu"]) - float(_w @ _t21_mu)) < 1e-12 and abs(float(_r["fQA_sigma"]) - float(_w @ _t21_sd)) < 1e-12
    assert _Amin_c - 1e-9 <= float(_r["A"]) <= _Amax_c + 1e-9 and _Vmin_c - 1e-9 <= float(_r["V"]) <= _Vmax_c + 1e-9
# the confidence bounds are attained at the vertices of the sharpest and the most diffuse expert (V = (w.sigma)^2 with w.sigma linear)
assert abs(_Vmin_c - float(np.min(_t21_sd)) ** 2) < 1e-9 and abs(_Vmax_c - float(np.max(_t21_sd)) ** 2) < 1e-9
assert int(np.argmax(_bnd.loc["V_min", ["w1", "w2", "w3", "w4"]].to_numpy(float))) == int(np.argmin(_t21_sd))
# the consensus bounds are attained at vertices and bracket the vertex overlaps
_vertA = [_ch2_overlap_from_rows(np.eye(4)[i], _t21_mu, _t21_sd) for i in range(4)]
assert abs(_Amax_c - max(_vertA)) < 1e-9 and abs(_Amin_c - min(_vertA)) < 1e-9, "consensus bounds are not attained at the vertices found"
assert np.max(_bnd.loc["A_max", ["w1", "w2", "w3", "w4"]].to_numpy(float)) > 0.999
_emph = list(_t25c["emphasis"].astype(str))
assert _emph[1] == "maximum consensus" and abs(float(_t25c.loc[1, "A"]) - _Amax_c) < 1e-9
assert _emph[2] == "minimum variance" and abs(float(_t25c.loc[2, "V"]) - _Vmin_c) < 1e-9
# the alpha* row: its objective dominates every other row, every start, 2000 seeded
# simplex probes, and the endpoints of its level set; the level set is flat and its
# endpoints induce the same aggregate; the reported vector is their midpoint
_wstar = _W25[3]; _fstar = _ch2_obj_from_rows(_wstar)
assert abs(_fstar - float(_cfg25["alpha_star_objective"])) < 1e-9
for _k in range(3):
    assert _fstar >= _ch2_obj_from_rows(_W25[_k]) - 1e-12, "Table 2.5 row %d beats the alpha* row" % _k
_starts_c = _t25s["starts"][["w1", "w2", "w3", "w4"]].to_numpy(float)
assert len(_starts_c) == int(str(_cfg25["starts"]).split("plus")[0].split()[0]) + 5
assert len(CH2_PROBES) == int(str(_cfg25["probes"]).split()[0])
for _w0 in np.vstack([_starts_c, CH2_PROBES]):
    assert _fstar >= _ch2_obj_from_rows(_w0) - 1e-12, "a start or probe point beats the alpha* row"
_e1 = _lvl.loc["endpoint 1", ["w1", "w2", "w3", "w4"]].to_numpy(float)
_e2 = _lvl.loc["endpoint 2", ["w1", "w2", "w3", "w4"]].to_numpy(float)
assert np.min(_e1) < 1e-9 and np.min(_e2) < 1e-9, "level-set endpoints must lie on the boundary of the simplex"
assert abs(float(_e1 @ _t21_mu) - float(_e2 @ _t21_mu)) < 1e-9 and abs(float(_e1 @ _t21_sd) - float(_e2 @ _t21_sd)) < 1e-9
assert np.allclose(_wstar, 0.5 * (_e1 + _e2), atol=1e-9), "the reported alpha* vector is not the segment midpoint"
for _t in np.linspace(0, 1, 11):
    assert abs(_ch2_obj_from_rows((1 - _t) * _e1 + _t * _e2) - _fstar) < 1e-9, "the objective is not flat along the optimal segment"
assert np.max(_wstar) < 0.999, "the alpha* optimizer is not interior"
# the alpha sweep: the optimal value g(alpha) = max_w [alpha (A~ + V~) - V~] is a
# maximum of affine functions with nonnegative slopes, hence nondecreasing and
# convex in alpha, with g(0) = 0 and g(1) = 1 under min-max normalization
_ga = _swp["alpha"].to_numpy(float); _gv = _swp["objective"].to_numpy(float)
assert len(np.unique(np.round(_ga, 6))) == len(_ga), "alpha sweep has duplicate levels"
assert abs(_gv[0]) < 1e-9 and abs(_gv[-1] - 1.0) < 1e-9 and _ga[0] == 0.0 and _ga[-1] == 1.0
assert np.all(np.diff(_gv) >= -1e-9), "g(alpha) must be nondecreasing"
for _i in range(1, len(_ga) - 1):
    if _ga[_i + 1] > _ga[_i] > _ga[_i - 1]:
        _lin = _gv[_i - 1] + (_gv[_i + 1] - _gv[_i - 1]) * (_ga[_i] - _ga[_i - 1]) / (_ga[_i + 1] - _ga[_i - 1])
        assert _gv[_i] <= _lin + 1e-9, "g(alpha) must be convex (violated at alpha=%.2f)" % _ga[_i]
for _, _r in _swp.iterrows():
    _w = _r[["w1", "w2", "w3", "w4"]].to_numpy(float)
    _sums_to_one(_w, "alpha sweep row alpha=%.2f" % _r["alpha"])
    assert abs(float(_r["objective"]) - _ch2_obj_from_rows(_w, float(_r["alpha"]))) < 1e-9
_int = _swp[_swp["interior"] == 1]["alpha"].to_numpy(float)
assert len(_int) > 0 and _alpha_s in set(np.round(_int, 2)), "alpha* must lie in the interior window"
assert str(_cfg25["interior_alpha_window_on_grid"]) == "[%.2f, %.2f]" % (_int.min(), _int.max())
print("   Table 2.5: bounds at vertices, alpha* row dominates rows, starts, probes, and its level set; g(alpha) monotone convex")

# (2) BIM full assessment: stated inputs are probability vectors, and the
#     COMPUTED quantile averages of the 'derived' sheet satisfy the quantile
#     identity of Prop. qa-properties(iii), checked at three probability
#     levels with the standard-normal quantile (an invariant independent of
#     the mean/sd formula used to compute them).  The elicitation fit is
#     re-derived from the profile by a second route (E[x^2] - mu^2).
_bim = _wb("fig6-1_bim_case.xlsx")
_sums_to_one(_bim["groups"]["Omega"], "BIM group Omega")
_sums_to_one(_bim["dimensions"]["weight"], "BIM dimension weights")
_sums_to_one(_bim["elicitation_q4"]["probability"], "BIM q4 elicited profile")
assert len(_bim["elicitation_q4"]) == 10, "BIM q4 profile must have 10 levels"
_bder = _bim["derived"].set_index("quantity")
for _lab, _sheet, _wcol, _row in (("q4 collective", "groups", "Omega",
                                   "q4 collective (inter-group QA under Omega)"),
                                  ("global maturity", "dimensions", "weight",
                                   "global maturity (QA of dimensions under BWM weights)")):
    _S = _bim[_sheet]
    _wv = _S[_wcol].to_numpy(float)
    _mv, _sv = _S["mu"].to_numpy(float), _S["sigma"].to_numpy(float)
    _dm, _ds = float(_bder.loc[_row, "mu"]), float(_bder.loc[_row, "sigma"])
    for _p in (0.05, 0.5, 0.95):
        _z = float(_norm_ppf(np.array([_p]))[0])
        _qa = float(np.sum(_wv * (_mv + _sv * _z)))      # sum_k w_k F_k^{-1}(p)
        assert abs(_qa - (_dm + _ds * _z)) < 1e-9, \
            "BIM %s: quantile identity fails at p=%.2f (%.6f vs %.6f)" % (_lab, _p, _qa, _dm + _ds * _z)
_bel = _bim["elicitation_q4"]
_bp = _bel["probability"].to_numpy(float)
_bp = _bp / _bp.sum()
_bm = _bel["level_mid"].to_numpy(float)
_fit_mu2 = float(np.sum(_bp * _bm))
_fit_sd2 = math.sqrt(float(np.sum(_bp * _bm ** 2)) - _fit_mu2 ** 2)
_frow = "tab:bim-elicit normal fit of the q4 profile"
assert abs(float(_bder.loc[_frow, "mu"]) - _fit_mu2) < 1e-12 and \
    abs(float(_bder.loc[_frow, "sigma"]) - _fit_sd2) < 1e-9, "BIM elicitation fit is not the midpoint moment match"
assert 4.0 <= _fit_mu2 <= 6.0, "BIM elicitation fit mean must lie in the managed-defined bands"
print("   BIM full assessment: quantile identity holds for the computed q4 collective and global maturity;"
      " elicitation fit == midpoint moment match")

# (3) BIM fairness panel: the SOLVED sweep of fig6-4_bim_tradeoff.xlsx is
#     checked against invariants of the program eq:bim-triobjective, never
#     against typed result constants.
_bsw = _wb("fig6-4_bim_tradeoff.xlsx")
_bcfg = _cfgd(_bsw)
_bser = _bsw["series"].set_index("delta")
_bwt = _bsw["weights"].set_index("delta")
_bov = _bsw["overlaps"].set_index("delta")
_bbd = _bsw["bounds"].set_index("objective")
_bimg = _wb("fig6-3_bim_densities.xlsx")
_bexp = _bimg["gaussians"][_bimg["gaussians"]["role"].astype(str).str.startswith("expert")]
assert len(_bexp) == 7, "BIM densities: expected the 7-expert panel"
_bmu = _bexp["mu"].to_numpy(float)
_bsd = _bexp["sigma"].to_numpy(float)
assert np.allclose(_bmu, _BIM_MU) and np.allclose(_bsd, _BIM_SD), "fig6-3 expert rows differ from eq:bim-panel-mu/sigma"
_bW = np.column_stack([_bwt["w%d" % (i + 1)].to_numpy(float) for i in range(7)])
_bdel = _bwt.index.to_numpy(float)
assert list(np.round(_bdel, 6)) == [round(d, 6) for d in _BIM_DELTAS], "fig6-4 sweep grid is not {0,0.1,...,0.6}"
for _k, _d in enumerate(_bdel):
    _sums_to_one(_bW[_k], "BIM w(delta=%.1f)" % _d)
    assert (_bW[_k] >= -1e-12).all(), "BIM w(delta=%.1f) has a negative weight" % _d
# (3a) the recorded bounds are attained/bracketed: the confidence V = (w.sigma)^2
#      is a square of a linear form, so its extremes over the simplex are
#      vertex values; the mean-overlap and fairness bounds must bracket every
#      vertex and every sweep solution.
assert abs(float(_bbd.loc["V", "min"]) - _BIM_SD.min() ** 2) < 1e-6 and \
    abs(float(_bbd.loc["V", "max"]) - _BIM_SD.max() ** 2) < 1e-6, "solved V bounds are not the vertex extremes"
_bcand = np.vstack([np.eye(7), _bW])
for _name, _f in (("Abar", _bim_Abar), ("Phi", _bim_Phi), ("V", _bim_V)):
    _lo, _hi = float(_bbd.loc[_name, "min"]), float(_bbd.loc[_name, "max"])
    _vals = np.array([_f(w) for w in _bcand])
    assert _vals.min() >= _lo - 1e-6 and _vals.max() <= _hi + 1e-6, \
        "BIM %s bounds [%.6f, %.6f] do not bracket the vertices and sweep solutions" % (_name, _lo, _hi)
    assert _hi - _lo > 1e-3, "BIM %s is constant over the simplex; min-max normalization undefined" % _name
    assert abs(float(_bcfg["%s_min" % _name]) - _lo) < 1e-12 and abs(float(_bcfg["%s_max" % _name]) - _hi) < 1e-12, \
        "config bounds for %s disagree with the bounds sheet" % _name
# (3b) the recorded diagnostics are recomputed from the recorded weights
#      (mean overlap, minimum overlap, fairness, aggregate, objective).
for _k, _d in enumerate(_bdel):
    _w = _bW[_k]
    _A = _bim_overlaps(_w)
    _P = _bim_Phi(_w)
    assert abs(float(_bser.loc[_d, "consensus_Abar"]) - _A.mean()) < 1e-9
    assert abs(float(_bser.loc[_d, "minimum_overlap"]) - _A.min()) < 1e-9
    assert abs(float(_bser.loc[_d, "fairness_Phibar"]) - _P) < 1e-9
    assert abs(float(_bser.loc[_d, "agg_mu"]) - float(_w @ _bmu)) < 1e-9
    assert abs(float(_bser.loc[_d, "agg_sd"]) - float(_w @ _bsd)) < 1e-9
    assert abs(float(_bser.loc[_d, "objective"]) - _bim_scalarized(_w, _d)) < 1e-9
    assert np.allclose(_bov.loc[_d, ["A%d" % (i + 1) for i in range(7)]].to_numpy(float), _A, atol=1e-9)
    # closed-form overlap of the aggregate with every expert vs the trapezoid rule
    for _i in range(7):
        assert abs(_A[_i] - _bim_overlap_trapz(_bmu[_i], _bsd[_i], float(_w @ _bmu), float(_w @ _bsd))) < 1e-7
# (3c) optimality against a candidate set: at every delta the recorded
#      solution scores at least as high as every vertex and every other
#      sweep solution under that delta's scalarization.
for _k, _d in enumerate(_bdel):
    _best = _bim_scalarized(_bW[_k], _d)
    for _c in _bcand:
        assert _bim_scalarized(_c, _d) <= _best + 1e-9, \
            "BIM delta=%.1f: candidate %s beats the recorded solution" % (_d, np.round(_c, 3))
# (3d) the qualitative finding the text asserts, checked on the solved
#      outputs: the delta = 0 solution is a vertex (all weight on one expert),
#      and from delta = 0 to delta = 0.5 the dissenter's weight, the minimum
#      overlap and the collective fairness rise while the mean overlap and
#      the aggregate mean fall.
_i0 = list(_bdel).index(0.0)
_i5 = list(_bdel).index(0.5)
assert _bW[_i0].max() > 1 - 1e-6, "BIM delta=0 solution is not a vertex"
assert float(_bser.loc[0.5, "weight_on_dissenter"]) > float(_bser.loc[0.0, "weight_on_dissenter"]) + 0.05
assert float(_bser.loc[0.5, "minimum_overlap"]) > float(_bser.loc[0.0, "minimum_overlap"])
assert float(_bser.loc[0.5, "fairness_Phibar"]) > float(_bser.loc[0.0, "fairness_Phibar"])
assert float(_bser.loc[0.5, "consensus_Abar"]) < float(_bser.loc[0.0, "consensus_Abar"])
assert float(_bser.loc[0.5, "agg_mu"]) < float(_bser.loc[0.0, "agg_mu"])
# (3e) fig6-3 aggregates and tab6-9 are the solved delta = 0 / 0.5 rows
_bagg = _bimg["gaussians"][_bimg["gaussians"]["role"] == "aggregate"].reset_index(drop=True)
for _j, _d in ((0, 0.0), (1, 0.5)):
    assert abs(float(_bagg.loc[_j, "mu"]) - float(_bser.loc[_d, "agg_mu"])) < 1e-12
    assert abs(float(_bagg.loc[_j, "sigma"]) - float(_bser.loc[_d, "agg_sd"])) < 1e-12
_t69 = _wb("tab6-9_bim_results.xlsx")
_t69v = _t69["table_6_9"].set_index("quantity")
_t69p = _t69["table_6_9_printed"].set_index("quantity")
for _q, _col in (("minimum overlap", "minimum_overlap"),
                 ("mean overlap (consensus)", "consensus_Abar"),
                 ("collective fairness", "fairness_Phibar"),
                 ("weight on dissenter (exp 5)", "weight_on_dissenter")):
    for _tc, _d in (("consensus_confidence_d0", 0.0), ("fairness_weighted_d0.5", 0.5)):
        assert abs(float(_t69v.loc[_q, _tc]) - float(_bser.loc[_d, _col])) < 1e-12, \
            "tab6-9 %r disagrees with the fig6-4 sweep at delta=%.1f" % (_q, _d)
        assert float(_t69p.loc[_q, _tc]) == round(float(_bser.loc[_d, _col]), 3)
for _tc, _d in (("consensus_confidence_d0", 0.0), ("fairness_weighted_d0.5", 0.5)):
    assert str(_t69p.loc["aggregate distribution", _tc]) == "N(%.2f, %.2f^2)" % (
        round(float(_bser.loc[_d, "agg_mu"]), 2), round(float(_bser.loc[_d, "agg_sd"]), 2))
# (3f) solver settings are recorded
for _key in ("seed", "n_starts", "start_law", "ftol", "tie_rule", "overlap_rule", "bounds_method", "delta_grid", "draw_order"):
    assert _key in _bcfg, "fig6-4 config lacks the solver setting %r" % _key
assert int(_bcfg["seed"]) == NEW_SEED and int(_bcfg["n_starts"]) == _BIM_N_STARTS
print("   BIM fairness panel: solved sweep verified (bounds bracket vertices, diagnostics recomputed from the"
      " weights, closed form == trapezoid, optimal over vertices and sweep solutions, qualitative finding holds,"
      " fig6-3 aggregates and tab6-9 == solved rows, settings recorded)")

# (4) DT case (Case II): the generated panel, the 70 solved programs, and
#     the 14 x 5 matrix are checked against invariants only (simplex,
#     probability normalization, the identities the book states, bounds
#     of the min-max normalization, and internal consistency between the
#     sheets); nothing is compared with a typed printed constant.
_dt = _wb("fig6-5_dt_case.xlsx")
_dtc = _cfgd(_dt)
_dtN, _dtM = int(_dtc["N_experts"]), int(_dtc["M_barriers"])
_dtb = _dt["barriers"]
_dtids = list(_dtb["id"].astype(str))
_dteq = list(_dt["equity_objectives"]["eq"].astype(str))
assert _dteq == ["EQ1", "EQ2", "EQ3", "EQ4", "EQ5"], _dteq
# the elicited profile of tab:dt-elicit and its recorded fit
_sums_to_one(_dt["elicitation_b1"]["probability"], "DT B1 elicited profile")
_b1k, _b1l = float(_dtc["b1_fit_kappa"]), float(_dtc["b1_fit_lambda"])
assert _b1k > 0 and _b1l > 0
_b1H5 = 1.0 - math.exp(-(5.0 / _b1l) ** _b1k)
assert abs(_b1H5 - float(_dtc["b1_fit_H5"])) < 1e-9
_b1pg = (np.arange(2000) + 0.5) / 2000
_b1mean = float(np.mean(_b1l * (-np.log(1.0 - _b1pg * _b1H5)) ** (1.0 / _b1k)))
assert abs(_b1mean - float(_dtc["b1_fit_mean"])) < 1e-6, (_b1mean, _dtc["b1_fit_mean"])
# the panel: 420 fitted truncated Weibulls, proper profiles, positive parameters
_dtp = _dt["panel"]
assert len(_dtp) == _dtN * _dtM, len(_dtp)
_dtprof = _dtp[["p1", "p2", "p3", "p4", "p5"]].to_numpy(float)
assert np.allclose(_dtprof.sum(axis=1), 1.0, atol=1e-9) and (_dtprof >= 0).all()
assert (_dtp["kappa"] > 0).all() and (_dtp["lambda"] > 0).all()
assert ((_dtp["H5"] > 0) & (_dtp["H5"] <= 1)).all()
assert ((_dtp["rating"] >= 0) & (_dtp["rating"] <= 5)).all()
# generator identities: rating = clip(tau + leniency + bias + noise), and
# the equal-weight quantile-averaged mean equals the average of the fitted
# expert means (QA means are linear, thm:qa-moments) and the design mean
_dtr = np.clip(_dtp["tau"] + _dtp["leniency"] + _dtp["bias"] + _dtp["noise"], 0.0, 5.0)
assert np.allclose(_dtr, _dtp["rating"], atol=1e-12)
_dtfm = _dtp.pivot(index="expert", columns="barrier", values="fitted_mean")[_dtids].to_numpy(float)
assert np.allclose(_dtfm.mean(axis=0), _dtb["equal_weight_mean"], atol=1e-9)
assert np.allclose(_dtb["equal_weight_mean"], _dtb["design_mean"], atol=1e-3), \
    "DT calibration off by more than 1e-3"
# the 70 solved weight vectors lie on the simplex, and the recorded
# collective mean of each solve is the weighted fitted-expert mean
_dtw = _dt["weights"].set_index("expert")
_dts = _dt["solves"]
assert len(_dts) == _dtM * 5 and _dtw.shape == (_dtN, _dtM * 5)
for _, _row in _dts.iterrows():
    _col = "%s_%s" % (_row["barrier"], _row["eq"])
    _w = _dtw[_col].to_numpy(float)
    assert (_w >= 0).all()
    _sums_to_one(_w, "DT weights %s" % _col, tol=1e-8)
    _mu_lin = float(_w @ _dtfm[:, _dtids.index(str(_row["barrier"]))])
    assert abs(_mu_lin - float(_row["mu"])) < 1e-6, (_col, _mu_lin, _row["mu"])
    assert int((_w > float(_dtc["active_threshold"])).sum()) == int(_row["n_active"])
    assert abs(float(_w.max()) - float(_row["w_max"])) < 1e-12
# min-max bounds and normalized terms: V and W within their solved bounds
# (the welfare bounds having been refined from the program's own solution
# whenever it exceeded them, see the config sheet), so V~ and W~ lie in [0,1]
assert (_dts["V_min"] < _dts["V_max"]).all() and (_dts["W_min"] < _dts["W_max"]).all()
assert ((_dts["V"] >= _dts["V_min"] - 1e-9) & (_dts["V"] <= _dts["V_max"] + 1e-9)).all()
assert ((_dts["V_tilde"] >= -1e-9) & (_dts["V_tilde"] <= 1 + 1e-9)).all()
assert ((_dts["W"] >= _dts["W_min"] - 1e-9) & (_dts["W"] <= _dts["W_max"] + 1e-9)).all()
assert ((_dts["W_tilde"] >= -1e-6) & (_dts["W_tilde"] <= 1 + 1e-6)).all(), float(_dts["W_tilde"].max())
assert (_dts["bound_refinements"] <= int(_dtc["bound_refine_max"])).all()
assert np.allclose(_dts["objective"], _dts["W_tilde"] - _dts["V_tilde"], atol=1e-9)
# the retained optimum is at least as good as the barycentre start
assert (_dts["objective"] >= _dts["objective_barycentre"] - 1e-9).all()
# the welfare identity W = Ubar (1 - I) and the recorded utilities
assert np.allclose(_dts["W"], _dts["Ubar"] * (1.0 - _dts["I"]), atol=1e-12)
_dtU = _dt["utilities"].set_index("expert")
_dtA = _dt["overlaps"].set_index("expert")
assert ((_dtU >= 0) & (_dtU <= 1)).all().all() and ((_dtA >= 0) & (_dtA <= 1)).all().all()
for _, _row in _dts.iterrows():
    _col = "%s_%s" % (_row["barrier"], _row["eq"])
    assert abs(float(_dtU[_col].mean()) - float(_row["Ubar"])) < 1e-9
    assert abs(float(_dtA[_col].mean()) - float(_row["Abar"])) < 1e-9
    assert abs(float(_dtA[_col].min()) - float(_row["Amin"])) < 1e-9
# the 14 x 5 matrix, its average, and the ranking follow from the solves
_dtMx = _dt["matrix"].set_index("id")
assert list(_dtMx.index.astype(str)) == _dtids
for _, _row in _dts.iterrows():
    assert abs(float(_dtMx.loc[str(_row["barrier"]), str(_row["eq"])]) - float(_row["mu"])) < 1e-12
assert np.allclose(_dtMx["avg"], _dtMx[_dteq].mean(axis=1), atol=1e-12)
assert np.allclose(_dtMx["spread"], _dtMx[_dteq].max(axis=1) - _dtMx[_dteq].min(axis=1), atol=1e-12)
_dtorder = [_dtids[r] for r in sorted(range(_dtM), key=lambda r: -float(_dtMx["avg"].iloc[r]))]
assert _dtorder == list(_dt["ranking"]["id"].astype(str)), _dtorder
assert list(_dtMx.sort_values("rank").index.astype(str)) == _dtorder
_dttriad = str(_dtc["triad"]).split(",")
assert _dttriad == _dtorder[:3], (_dttriad, _dtorder[:3])
# the triad densities of Figure 6.7 integrate to one on [0,5]
_dtd = _dt["triad_density"]
for _b in _dttriad:
    _area = float(_trapz(_dtd["f_" + _b].to_numpy(float), _dtd["x"].to_numpy(float)))
    assert abs(_area - 1.0) < 2e-3, (_b, _area)
print("   DT case: panel identities, 70 simplex weight vectors, min-max bounds, "
      "W = Ubar(1 - I), matrix/average/ranking consistency, triad densities verified")

# (5) BDT case (generated and solved): invariants of the solved outputs, never
#     typed constants.  Simplex and normalization identities, the quantile-
#     averaging mean identity at every layer and every delta, the hierarchical
#     variance bound (prop:hier-variance), the k-means / TOPSIS / BWM records,
#     the panel targets, and the Figure 6.8 densities.
_bdt = _wb("fig6-8_bdt_case.xlsx")
_bdtc = _cfgd(_bdt)
_sums_to_one(_bdt["groups"]["Omega"], "BDT group Omega")
_sums_to_one(_bdt["dimensions"]["weight"], "BDT dimension weights")
_bgrp = _bdt["groups"]
_bsizes = [int(s) for s in _bgrp["size"]]
assert sum(_bsizes) == int(_bdtc["n_experts"]) == 15
_batt = _bdt["expert_attributes"]
assert len(_batt) == 15 and _batt.shape[1] >= 6
assert list(_batt["group_kmeans"].value_counts().reindex(["G1", "G2", "G3"])) == _bsizes, \
    "k-means membership counts differ from the groups sheet"
assert (_batt["group_kmeans"] == _batt["group_design"]).all()
_bkt = _bdt["kmeans_topsis"]
assert ((_bkt["closeness"] >= 0) & (_bkt["closeness"] <= 1)).all()
assert np.allclose(_bkt["Omega"], _bkt["closeness"] / _bkt["closeness"].sum())
assert np.allclose(_bkt["Omega"], _bgrp["Omega"])
_bOmega = _bgrp["Omega"].to_numpy(float)
assert _bOmega[2] > _bOmega[0] > _bOmega[1], "designed Omega ordering G3 > G1 > G2 lost: %r" % (_bOmega,)
# BWM linear model: the recorded xi bounds every comparison deviation
_bdim = _bdt["dimensions"]
_bw = _bdim["weight"].to_numpy(float)
_baB = _bdim["bwm_best_to_others"].to_numpy(float)
_baW = _bdim["bwm_others_to_worst"].to_numpy(float)
_bids = [str(v) for v in _bdim["id"]]
_bbi = _bids.index(str(_bdtc["bwm_best"]))
_bwi = _bids.index(str(_bdtc["bwm_worst"]))
assert _bw[_bbi] == _bw.max() and _bw[_bwi] == _bw.min()
_bxi = float(_bdtc["bwm_xi"])
assert (np.abs(_bw[_bbi] - _baB * _bw) <= _bxi + 1e-7).all(), "BWM best-to-others deviations exceed xi"
assert (np.abs(_bw - _baW * _bw[_bwi]) <= _bxi + 1e-7).all(), "BWM others-to-worst deviations exceed xi"
assert _bxi < 0.1 * float(_bdtc["bwm_consistency_index"]), "BWM consistency ratio too large"
# panel: every truncated mean equals its target, shapes inside the stated range
_bpan = _bdt["panel_weibull"]
assert len(_bpan) == 15 * 22
assert np.allclose(_bpan["truncated_mean"], _bpan["target_mean"], atol=1e-5)
assert ((_bpan["truncated_sd"] > 0.4) & (_bpan["truncated_sd"] < 0.8)).all()
# every solved weight vector is a probability vector over its subgroup only
_bsol = _bdt["intra_group_solutions"]
_wcols = ["w_e%d" % i for i in range(1, 16)]
assert len(_bsol) == 6 * 3 * 22
for _, _r in _bsol.iterrows():
    _wv = _r[_wcols].to_numpy(float)
    _mem = ~np.isnan(_wv)
    assert _mem.sum() == _bsizes[int(_r["group"][1]) - 1]
    _wv = _wv[_mem]
    assert (_wv >= -1e-12).all() and abs(_wv.sum() - 1.0) < 1e-8, "BDT weight vector off the simplex"
    assert abs(_gini_vec(np.clip(_wv, 0, None)) - float(_r["gini_w"])) < 1e-8
    assert 0.0 <= float(_r["Phi"]) <= 1.0 + 1e-12
    assert float(_r["Phi_min"]) <= float(_r["Phi_max"]) and float(_r["V_min"]) <= float(_r["V_max"])
# quantile-averaging mean identity at the inter-group, dimension and global layers
_bind = _bdt["indicator_collectives"]
_bdimc = _bdt["dimension_collectives"]
_bsen = _bdt["sensitivity"].set_index("delta")
for _d in sorted(_bsen.index):
    _ii = _bind[_bind["delta"] == _d].sort_values("indicator", key=lambda s: s.str[1:].astype(int))
    _pred = _bOmega[0] * _ii["G1_mean"].to_numpy() + _bOmega[1] * _ii["G2_mean"].to_numpy() \
        + _bOmega[2] * _ii["G3_mean"].to_numpy()
    assert np.allclose(_pred, _ii["collective_mean"].to_numpy(), atol=1e-9), \
        "BDT inter-group mean identity fails at delta %.1f" % _d
    _dd = _bdimc[_bdimc["delta"] == _d].sort_values("dimension")
    for _b, (_, _rr) in enumerate(_dd.iterrows()):
        _mm = _ii[_ii["dimension"] == _rr["dimension"]]["collective_mean"].to_numpy()
        assert abs(float(_mm.mean()) - float(_rr["mean"])) < 1e-9, "BDT dimension mean identity fails"
    _gm = float(np.dot(_dd["weight"], _dd["mean"]))
    assert abs(_gm - float(_bsen.loc[_d, "global_maturity"])) < 1e-9, \
        "BDT global maturity at delta %.1f is not the weighted mean of the dimension means" % _d
    # prop:hier-variance: aggregate variance <= largest subgroup variance
    assert float(_bsen.loc[_d, "aggregate_variance"]) <= float(_bsen.loc[_d, "max_group_variance"]) + 1e-12
    _sd = _bsol[_bsol["delta"] == _d]
    assert abs(float(_sd["Phi"].mean()) - float(_bsen.loc[_d, "fairness_Phi"])) < 1e-9
    assert abs(float(_sd["gini_w"].mean()) - float(_bsen.loc[_d, "weight_gini"])) < 1e-9
# the dimensions sheet is the delta = 0.5 row of dimension_collectives
_d5 = _bdimc[_bdimc["delta"] == 0.5].sort_values("dimension")
assert np.allclose(_d5["mean"].to_numpy(), _bdim["mu"].to_numpy(float))
assert abs(float(_bdtc["global_maturity"]) - float(_bsen.loc[0.5, "global_maturity"])) < 1e-12
# Figure 6.8: densities integrate to one and their means equal the legend means
_bq = _bdt["q1_densities"]
_bx = _bq["x"].to_numpy(float)
_bdx = float(_bx[1] - _bx[0])
for _k in range(3):
    _f = _bq["f_G%d" % (_k + 1)].to_numpy(float)
    assert abs(_trapz(_f, dx=_bdx) - 1.0) < 0.01
    assert abs(_trapz(_bx * _f, dx=_bdx) - float(_bgrp.loc[_k, "q1_mu"])) < 0.01
_fc = _bq["f_collective"].to_numpy(float)
assert abs(_trapz(_fc, dx=_bdx) - 1.0) < 0.01
assert abs(_trapz(_bx * _fc, dx=_bdx) - float(np.dot(_bOmega, _bgrp["q1_mu"]))) < 0.01
_bqq = _bdt["q1_quantiles"]
assert np.allclose(_bqq["Q_collective"], _bOmega[0] * _bqq["Q_G1"] + _bOmega[1] * _bqq["Q_G2"]
                   + _bOmega[2] * _bqq["Q_G3"])
for _c in ("Q_G1", "Q_G2", "Q_G3", "Q_collective"):
    assert (np.diff(_bqq[_c].to_numpy(float)) > 0).all(), "BDT quantile function %s not increasing" % _c
print("   BDT case: simplex/identity/variance-bound invariants hold at every delta;"
      " k-means, TOPSIS, BWM and the Figure 6.8 densities verified")

# (6) vignette IV: the solved outputs written to the workbook satisfy the
#     invariants the book states (nothing here is compared with a typed
#     printed constant): panel dimensions, weight vectors on the simplex,
#     W_H + W_M = 1, the leave-one-out identity delta_i = CRPS_-i - CRPS,
#     the Hersbach identities CRPS_h = REL + POT and delta = d_cal + d_res,
#     RES_i = UNC - POT_i, the calibration fractions in [0, 1], the spread
#     rules, every solve certified against SLSQP, and the optimized full-pool
#     objective no worse than the equal-weight start it descends from.
_hmc = _wb("fig6-12_hm_calsharp.xlsx")
_hmd = _cfgd(_hmc)
_hmF = _hmc["forecasters"]
_hmN = int(_hmd["n_human"]) + int(_hmd["n_machine"])
assert len(_hmF) == _hmN and _hmc["forecast_mu"].shape == (int(_hmd["horizon_T"]), _hmN)
assert len(_hmc["outcomes"]) == int(_hmd["horizon_T"])
_hmW = _hmc["weights"]
_sums_to_one(_hmW["weight_full"], "vignette full-pool weights", tol=1e-6)
_sums_to_one(_hmW["weight_human_only"], "vignette human-only weights", tol=1e-6)
_sums_to_one(_hmW["weight_equal"], "vignette equal weights", tol=1e-9)
assert (_hmW["weight_full"] >= -1e-12).all() and (_hmW["weight_human_only"] >= -1e-12).all()
assert (_hmW.loc[_hmW["id"].astype(str).str.startswith("M"), "weight_human_only"] == 0).all()
for _k, _row in _hmc["loo_weights"].iterrows():
    _wv = _row.drop("withheld").astype(float)
    assert np.isnan(_wv[_row["withheld"]]), "loo row %s keeps the withheld expert" % _row["withheld"]
    _sums_to_one(_wv.dropna(), "vignette loo weights without %s" % _row["withheld"], tol=1e-6)
_hmA = _hmc["aggregates"].set_index("quantity")["value"]
assert abs(float(_hmA["human weight share W_H"]) + float(_hmA["machine weight share W_M"]) - 1.0) < 1e-9
assert abs(float(_hmA["human weight share W_H"])
           - float(_hmW.loc[_hmW["id"].astype(str).str.startswith("H"), "weight_full"].sum())) < 1e-9
# leave-one-out identity and the Hersbach identities, per forecaster
_hm_full = float(_hmA["optimized human-machine mean CRPS"])
_hm_ch_full = float(_hmA["full-pool Hersbach CRPS"])
_hm_unc = float(_hmA["uncertainty UNC (sample climatology)"])
assert abs(float(_hmA["full-pool Hersbach REL"]) + float(_hmA["full-pool Hersbach POT"]) - _hm_ch_full) < 1e-9
assert abs(float(_hmd["uncertainty_UNC"]) - _hm_unc) < 1e-9
for _k, _r in _hmF.iterrows():
    assert abs(float(_r["delta_loo"]) - (float(_r["crps_loo_resolve"]) - _hm_full)) < 1e-9
    assert abs(float(_r["delta_cal"]) + float(_r["delta_res"]) - float(_r["delta_loo_hersbach"])) < 1e-9
    assert abs(float(_r["REL_i"]) + float(_r["POT_i"]) - float(_r["crps_i_hersbach"])) < 1e-9
    assert abs(float(_r["resolution"]) - (_hm_unc - float(_r["POT_i"]))) < 1e-9
    assert abs(float(_r["reliability_error"]) - float(_r["REL_i"])) < 1e-12
    assert 0.0 <= float(_r["frac_below_median"]) <= 1.0
    _rmse = math.sqrt(float(_r["bias"]) ** 2 + float(_r["error_scale_tau"]) ** 2)
    if str(_r["group"]) == "overconfident machines":
        assert float(_r["spread"]) < _rmse, "%s is not overconfident" % _r["id"]
    else:
        assert abs(float(_r["spread"]) - _rmse) < 1e-12, "%s spread not commensurate" % _r["id"]
# the recomputed exact CRPS of each stored weight vector equals the stored one
_hm_mu = _hmc["forecast_mu"].to_numpy(float)
_hm_y = _hmc["outcomes"]["y"].to_numpy(float)
_hm_sd = _hmF["spread"].to_numpy(float)
for _col, _key in (("weight_full", "optimized human-machine mean CRPS"),
                   ("weight_human_only", "optimized human-only mean CRPS"),
                   ("weight_equal", "equal-weight human-machine mean CRPS")):
    _wv = _hmW[_col].to_numpy(float)
    _c = float(_crps_gauss(_hm_mu @ _wv, float(_hm_sd @ _wv), _hm_y).mean())
    assert abs(_c - float(_hmA[_key])) < 1e-9, "vignette %s CRPS %.6f != stored %.6f" % (_col, _c, float(_hmA[_key]))
# every solve certified, and the full-pool optimum no worse than its start
_hmS = _hmc["solves"]
assert len(_hmS) == 2 + _hmN
assert (_hmS["objective_gap"].abs() < float(_hmd["certificate_gap_bound"])).all(), "a vignette solve is not certified"
assert (_hmS["tolerance_met"] == 1).all(), "a vignette solve hit the iteration guard"
_hm_eq_obj = float(_hmA["equal-weight human-machine mean CRPS"]) + 0.5 * float(_hmd["eps_ridge"]) / _hmN
assert float(_hmS.loc[_hmS["solve"] == "full panel", "objective_best_iterate"].iloc[0]) <= _hm_eq_obj + 1e-12
print("   vignette IV: simplex, share, leave-one-out, Hersbach and spread"
      " identities hold; %d solves certified" % len(_hmS))

# (7) ex:hmpanel study (fig5-3_loo, fig5-2_calibration_sharpness, tab5-3):
#     the WRITTEN workbooks are tested against invariants recomputed from
#     the data they store, never against typed constants.
_loo = _wb("fig5-3_loo.xlsx")
_lcfg = _cfgd(_loo)
_T7 = int(_lcfg["T"])
assert _loo["forecast_mu"].shape == (_T7, 10)
assert len(_loo["outcomes"]) == _T7
_sums_to_one(_loo["weights"]["weight_full_panel"], "loo full-panel weights", tol=1e-9)
_sums_to_one(_loo["weights"]["weight_human_only"], "loo human-only weights", tol=1e-9)
assert (_loo["weights"]["weight_full_panel"] >= 0).all() and (_loo["weights"]["weight_human_only"] >= 0).all()
assert len(_loo["loo"]) == 10 and len(_loo["individual"]) == 10
_y7 = _loo["outcomes"]["y"].to_numpy(float)
_MU7 = _loo["forecast_mu"].to_numpy(float)
_SD7 = _loo["experts"]["reported_sd"].to_numpy(float)
_lamG7, _lamC7 = float(_lcfg["lambda_G"]), float(_lcfg["lambda_C"])
_res7 = dict(zip(_loo["results"]["quantity"].astype(str), _loo["results"]["value"].astype(float)))
_wf7 = _loo["weights"]["weight_full_panel"].to_numpy(float)
_wh7 = _loo["weights"]["weight_human_only"].to_numpy(float)[:5]
_Pf7 = _hm_program(_y7, _MU7, _SD7, list(range(10)), _lamG7, _lamC7)
_Ph7 = _hm_program(_y7, _MU7, _SD7, list(range(5)), _lamG7, _lamC7)
# (7a) the stored objective and mean CRPS are recomputed from the stored data
_Lf7, _cf7, _, _ = _Pf7["terms"](_wf7)
_Lh7, _ch7, _, _ = _Ph7["terms"](_wh7)
assert abs(_Lf7 - _res7["full-panel objective"]) < 1e-9, "full objective not reproducible from the workbook"
assert abs(_cf7 - _res7["collaborative mean CRPS"]) < 1e-9, "collaborative CRPS not reproducible"
assert abs(_Lh7 - _res7["human-only objective"]) < 1e-9, "human-only objective not reproducible"
assert abs(_ch7 - _res7["human-only mean CRPS"]) < 1e-9, "human-only CRPS not reproducible"
assert abs(_res7["human weight share W_H"] - _wf7[:5].sum()) < 1e-12
assert abs(_res7["machine weight share W_M"] - _wf7[5:].sum()) < 1e-12
assert abs(_res7["CRPS gain (collab vs human-only, pct)"] - 100.0 * (_cf7 / _ch7 - 1.0)) < 1e-9
# (7b) the solver log certifies every solve: converged under the recorded
#      settings and matched by the independent SLSQP solve
_slog = _loo["solver_log"]
assert len(_slog) == 12, "expected 12 solves (full, human-only, 10 leave-one-out)"
assert (_slog["objective_gap"] <= float(_HM_VERIFY["obj_gap"])).all(), "a solve is beaten by SLSQP"
assert (_slog["weights_inf_gap_vs_slsqp"] <= float(_HM_VERIFY["w_gap"])).all()
assert (_slog["alg42_last_dw_inf"] < float(_lcfg["solver_tolerance"])).all()
assert (_slog["alg42_iterations"] >= int(_lcfg["solver_r_min"])).all()
assert (_slog["alg42_iterations"] < int(_lcfg["solver_r_max_cap"])).all()
# (7c) optimality invariant of the convex program: the returned full-panel
#      vector is no worse than every other feasible point the study stored
#      (equal weights, the vertices, the embedded human-only solution, the
#      embedded leave-one-out solutions), under the full-panel objective
_cands7 = [np.full(10, 0.1)] + [np.eye(10)[j] for j in range(10)] + [np.concatenate([_wh7, np.zeros(5)])]
for _, _srow in _slog.iterrows():
    if str(_srow["solve"]).startswith("leave-out"):
        _sidx = [int(v) for v in str(_srow["experts"]).split(",")]
        _sw = np.array([float(v) for v in str(_srow["weights"]).split(",")])
        _emb = np.zeros(10)
        _emb[_sidx] = _sw
        _cands7.append(_emb)
for _cw in _cands7:
    assert _Lf7 <= _Pf7["obj"](_cw) + 1e-12, "a stored feasible point beats the returned full-panel optimum"
# (7d) the channel identity is exact, and the full-panel Hersbach terms
#      are reproduced from the stored aggregate on the recorded grid
_lrows = _loo["loo"]
assert np.allclose(_lrows["delta_cal"] + _lrows["delta_res"], _lrows["delta_total"], atol=1e-12)
_L7 = int(_lcfg["hersbach_levels_L"])
_z7 = _norm_ppf(np.arange(1, _L7 + 1) / (_L7 + 1.0))
_chf7, _relf7, _potf7 = _hersbach(_MU7 @ _wf7, np.full(_T7, float(_SD7 @ _wf7)), _y7, _z7)
assert abs(_relf7 - _res7["full-panel Hersbach REL"]) < 1e-12
assert abs(_potf7 - _res7["full-panel Hersbach POT"]) < 1e-12
assert abs(_chf7 - _res7["full-panel Hersbach CRPS"]) < 1e-12
_Xc7 = np.tile(np.quantile(_y7, np.arange(1, _L7 + 1) / (_L7 + 1.0)), (_T7, 1))
assert abs(_hersbach_X(_Xc7, _y7)[2] - float(_lcfg["uncertainty_UNC_grid"])) < 1e-12
_ind7 = _loo["individual"]
assert np.allclose(_ind7["RES_i"] + _ind7["POT_i"], float(_lcfg["uncertainty_UNC_grid"]), atol=1e-12)
assert np.allclose(_ind7["crps_i_hersbach"], _ind7["REL_i"] + _ind7["POT_i"], atol=1e-12)
_bs7 = _loo["binning_sensitivity"]
_bs19 = _bs7[_bs7["L"] == _L7].set_index("id").loc[list(_lrows["id"].astype(str))]
assert np.allclose(_bs19["delta_total"].to_numpy(float), _lrows["delta_total"].to_numpy(float), atol=1e-12)
_unst7 = [k for k in _lrows["id"].astype(str)
          if len(set(np.sign(_bs7.loc[_bs7["id"] == k, "delta_total"].to_numpy(float)))) > 1]
assert ",".join(_unst7) == str(_lcfg["total_sign_unstable_across_L"]) or (not _unst7 and str(_lcfg["total_sign_unstable_across_L"]) == "none")
# (7e) the design invariant the figure is built to show: both overconfident
#      machines in the (-, +) cell on the recorded grid
_over7 = _lrows[_lrows["group"].astype(str) == "machine overconfident"]
assert len(_over7) == 2 and (_over7["delta_cal"] < 0).all() and (_over7["delta_res"] > 0).all()
# (7f) Figure 5.2 is the individual sheet, point for point, with the same UNC
_cs7 = _wb("fig5-2_calibration_sharpness.xlsx")
_cs7c = _cfgd(_cs7)
assert abs(float(_cs7c["uncertainty_UNC_grid"]) - float(_lcfg["uncertainty_UNC_grid"])) < 1e-15
_pts7 = _cs7["points"].set_index("id")
_ind7i = _ind7.set_index("id")
assert list(_pts7.index) == list(_ind7i.index)
assert np.allclose(_pts7["RES"], _ind7i["RES_i"], atol=1e-15) and np.allclose(_pts7["REL"], _ind7i["REL_i"], atol=1e-15)
# (7g) Table 5.3 is the rounded results sheet
_t53 = _wb("tab5-3_hm_panel.xlsx")
_t53r = _t53["table_5_3"]
_t53p = _cfgd(_t53, "provenance")
assert float(_t53r.loc[0, "mean_CRPS"]) == round(_res7["human-only mean CRPS"], 2)
assert float(_t53r.loc[1, "mean_CRPS"]) == round(_res7["collaborative mean CRPS"], 2)
assert float(_t53r.loc[2, "optimized_weight_share"]) == round(_res7["human weight share W_H"], 2)
assert float(_t53r.loc[3, "optimized_weight_share"]) == round(_res7["machine weight share W_M"], 2)
assert int(_t53p["gain_pct_printed"]) == round(_res7["CRPS gain (collab vs human-only, pct)"])
assert int(_t53p["seed"]) == int(_lcfg["seed"])
print("   ex:hmpanel study: objectives and scores recomputed from the stored data; 12 solves"
      " certified by the solver log; optimality against %d stored feasible points;"
      " exact channel identity; UNC on the grid; fig5-2 == individual sheet; tab5-3 == rounded results"
      % len(_cands7))

# (8) Case IV: invariants of the SOLVED outputs, re-read from the workbook.
#     Nothing here is pinned to a typed result constant: the panel must
#     regenerate from the recorded seed and draw order, the reported weights
#     must lie on the simplex, reproduce the stored means and satisfy the
#     KKT form of the nearest-to-uniform projection, the Gini / advocate-share
#     / Ubar columns must follow from the stored weights and means, the
#     priorities must be the ranks of the means, the swap pair must be the
#     contested station (derived from the stations sheet) and its consensus
#     neighbour, the multi-start SQP must agree with the 1-D certificate,
#     and the robustness sheets must be complete and consistent.
_rtw = _wb("fig6-11_rt_case.xlsx")
_rtd = _cfgd(_rtw)
_rtn, _rtk = int(_rtd["n_stakeholders"]), int(_rtd["n_stations"])
assert _rtw["panel_mu"].shape == (_rtn, _rtk)
assert len(_rtw["panel"]) == _rtn
_rtmu = _rtw["panel_mu"].to_numpy(float)
_rtr = _rtw["results"].reset_index(drop=True)
_rtids = list(_rtr["station"].astype(str))
assert _rtids == list(_rtw["panel_mu"].columns.astype(str)) == list(_rtw["stations"]["id"].astype(str))
_rtadv = (_rtw["panel"]["constituency"].astype(str) == "accessibility advocates").to_numpy()
assert int(_rtadv.sum()) == int(_rtw["constituencies"].set_index("key").loc["adv", "size"])
# (8a) the panel regenerates from the recorded seed under the recorded draw order
_rtchk, _ = _rt_generate_panel(np.random.default_rng(int(_rtd["seed"])))
assert float(np.abs(_rtchk - _rtmu).max()) < 1e-12, "Case IV panel does not regenerate from the seed"
assert (_rtmu >= float(_rtd["scale_min"])).all() and (_rtmu <= float(_rtd["scale_max"])).all()
assert int(_rtd["generator_clip_binding"]) == int((_rtmu <= 0).any() or (_rtmu >= 10).any())
# (8b) the SQP starts are 1 + K points of the simplex, the first the uniform vector
_rts = _rtw["sqp_starts"].to_numpy(float)
assert _rts.shape == (1 + _RT_K_STARTS, _rtn) and (_rts >= 0).all()
assert np.allclose(_rts.sum(axis=1), 1.0, atol=1e-9) and np.allclose(_rts[0], 1.0 / _rtn)
# (8c) per regime: reported weights on the simplex, reproducing the stored
#      mean, with the diagnostics recomputed from them, and the KKT form of
#      the nearest-to-uniform projection (positive entries affine in mu,
#      zero entries where that affine form is nonpositive)
for _reg in ("eff", "eq"):
    _W = _rtw["weights_" + _reg].to_numpy(float)
    assert _W.shape == (_rtn, _rtk) and (_W >= -1e-12).all()
    for _j in range(_rtk):
        _w = np.clip(_W[:, _j], 0.0, None)
        _m = float(_rtr.loc[_j, "mean_" + _reg])
        _mus = _rtmu[:, _j]
        _sums_to_one(_w, "Case IV %s weights at %s" % (_reg, _rtids[_j]), tol=1e-8)
        assert _mus.min() - 1e-9 <= _m <= _mus.max() + 1e-9
        assert abs(float(_w @ _mus) - _m) < 1e-7, "Case IV %s: weights do not reproduce the mean at %s" % (_reg, _rtids[_j])
        assert abs(_gini_vec(_w) - float(_rtr.loc[_j, "weight_gini_" + _reg])) < 1e-8
        assert abs(float(_w[_rtadv].sum()) - float(_rtr.loc[_j, "adv_share_" + _reg])) < 1e-8
        _pos = _w > 1e-9
        assert _pos.sum() >= 2
        _cb = np.linalg.lstsq(np.column_stack([np.ones(_pos.sum()), _mus[_pos]]), _w[_pos], rcond=None)[0]
        assert float(np.abs(_cb[0] + _cb[1] * _mus[_pos] - _w[_pos]).max()) < 1e-6, \
            "Case IV %s at %s: reported weights are not the nearest-to-uniform point of the level set" % (_reg, _rtids[_j])
        assert (_cb[0] + _cb[1] * _mus[~_pos] <= 1e-6).all()
        # utility level and equity from the closed-form overlaps at the stored mean
        _A = _rt_overlap(_mus, _m)[0]
        _, _Ut = _fs_phi(_A[None, :], float(_rtd["rho"]), float(_rtd["theta"]))
        assert abs(float(_Ut[0].mean()) - float(_rtr.loc[_j, "Ubar_" + _reg])) < 1e-9
        assert abs(_gini_vec(_Ut[0]) - float(_rtr.loc[_j, "gini_U_" + _reg])) < 1e-9
        assert abs(float(_A.mean()) - float(_rtr.loc[_j, "Abar_" + _reg])) < 1e-9
        _regime = "eff" if _reg == "eff" else "eq4"
        assert abs(float(_rt_objective([_m], _mus, _regime)[0]) - float(_rtr.loc[_j, "objective_" + _reg])) < 1e-9
    _avg = float(np.mean(_rtr["weight_gini_" + _reg]))
    assert abs(_avg - float(_rtd["weight_gini_%s_avg" % _reg])) < 1e-9
# (8d) priorities are the ranks of the means; the swap pair is the contested
#      station of the stations sheet and its neighbour in the consensus queue
for _reg in ("eff", "eq"):
    _rank = np.argsort(np.argsort(_rtr["mean_" + _reg].to_numpy(float))) + 1
    assert list(_rank) == [int(v) for v in _rtr["priority_" + _reg]], "Case IV %s priorities are not the ranks" % _reg
_rswap = [s for s, a, b in zip(_rtids, _rtr["priority_eff"], _rtr["priority_eq"]) if int(a) != int(b)]
assert _rswap == [t.strip() for t in str(_rtd["swapped"]).split(",")], _rswap
_rtsp = _rtw["stations"]
_rtspread = (_rtsp[["ops", "pas", "adv"]].max(axis=1) - _rtsp[["ops", "pas", "adv"]].min(axis=1)).to_numpy(float)
_rtcont = str(_rtsp.loc[int(np.argmax(_rtspread)), "id"])
assert _rtcont == str(_rtd["contested_station"])
_rtq = list(_rtr.sort_values("priority_eff")["station"].astype(str))
_rtnb = _rtq[_rtq.index(_rtcont) - 1]
assert sorted(_rswap) == sorted([_rtcont, _rtnb]), "swap pair %r is not the contested station and its neighbour" % _rswap
_rt4 = _rtr.set_index("station")
assert float(_rt4.loc[_rtcont, "mean_eff"]) > float(_rt4.loc[_rtnb, "mean_eff"])
assert float(_rt4.loc[_rtcont, "mean_eq"]) < float(_rt4.loc[_rtnb, "mean_eq"])
assert float(_rt4.loc[_rtcont, "adv_share_eq"]) > float(_rt4.loc[_rtcont, "adv_share_eff"])
_rtgaps = {s: abs(float(_rt4.loc[s, "mean_eff"]) - float(_rt4.loc[s, "mean_eq"])) for s in _rtids if s != _rtcont}
assert len(_rtgaps) == _rtk - 1
assert abs(float(_rtd["max_uncontested_mean_gap"]) - max(_rtgaps.values())) < 1e-9
assert str(_rtd["max_uncontested_mean_gap_station"]) == max(_rtgaps, key=_rtgaps.get)
assert str(_rtd["uncontested_gaps_below_threshold"]).startswith(
    "%d/%d" % (sum(1 for g in _rtgaps.values() if g < _RT_GAP_THRESHOLD), len(_rtgaps)))
# (8e) the multi-start SQP agrees with the 1-D certificate at every solve
_rtc = _rtw["certification"]
assert len(_rtc) == 2 * _rtk
assert (np.abs(_rtc["objective_sqp"] - _rtc["objective_scan"]) <= _RT_CERT_OBJ_TOL).all()
assert (np.abs(_rtc["m_sqp"] - _rtc["m_scan"]) <= _RT_CERT_M_TOL).all()
assert (_rtc["m_sqp"].round(_RT_PRINT_DP) == _rtc["m_scan"].round(_RT_PRINT_DP)).all(), \
    "SQP and scan means print differently at %d dp" % _RT_PRINT_DP
assert (_rtc["projection_kkt_maxdiff"] < 1e-6).all()
for _, _cr in _rtc.iterrows():
    _col = "eff" if _cr["regime"] == "eff" else "eq"
    assert abs(float(_cr["m_sqp"]) - float(_rt4.loc[str(_cr["station"]), "mean_" + _col])) < 1e-12
# (8f) robustness sheets are complete and consistent with the config
_rsd = _rtw["robustness_seeds"]
assert len(_rsd) == _RT_RESEED_N and list(_rsd["seed"]) == list(range(int(_rtd["seed"]) + 1, int(_rtd["seed"]) + 1 + _RT_RESEED_N))
assert str(_rtd["robustness_reseed_swap_direction"]) == "%d/%d" % (int(_rsd["swap_direction_preserved"].sum()), _RT_RESEED_N)
assert str(_rtd["robustness_reseed_other_orders_unchanged"]) == "%d/%d" % (int(_rsd["other_orders_unchanged"].sum()), _RT_RESEED_N)
# every re-seeded panel either keeps every other order or moves the contested station
# exactly two places with its two neighbours keeping theirs
assert (((_rsd["other_orders_unchanged"] == 1) & (_rsd["contested_places_moved"] == 1))
        | ((_rsd["other_orders_unchanged"] == 0) & (_rsd["contested_places_moved"] == 2) & (_rsd["S5_S6_order_unchanged"] == 1))).all()
assert str(_rtd["robustness_reseed_contested_moves_two_places"]).startswith(
    "%d/%d" % (int((_rsd["contested_places_moved"] == 2).sum()), _RT_RESEED_N))
_rfs = _rtw["robustness_fs"]
assert len(_rfs) == sum(1 for a in _RT_FS_RHO for b in _RT_FS_THETA if b <= a)
assert (_rfs["theta"] <= _rfs["rho"]).all()
assert str(_rtd["robustness_fs_swap_direction"]) == "%d/%d" % (int(_rfs["swap_direction_preserved"].sum()), len(_rfs))
_rfs0 = _rfs[(np.abs(_rfs["rho"] - float(_rtd["rho"])) < 1e-12) & (np.abs(_rfs["theta"] - float(_rtd["theta"])) < 1e-12)]
assert len(_rfs0) == 1
assert abs(float(_rfs0["S4_mean_eq"].iloc[0]) - float(_rt4.loc[_rtcont, "mean_eq"])) <= _RT_CERT_M_TOL
assert abs(float(_rfs0["S5_mean_eq"].iloc[0]) - float(_rt4.loc[_rtnb, "mean_eq"])) <= _RT_CERT_M_TOL
print("   Case IV: panel regenerates from the seed; reported weights on the simplex, on the"
      " level sets and nearest to uniform (KKT); diagnostics recomputed; priorities are ranks;"
      " swap = contested station %s and neighbour %s; SQP == 1-D certificate at %d solves;"
      " robustness sheets consistent" % (_rtcont, _rtnb, len(_rtc)))

print("   all rule-12 self-checks passed")
