#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
gen_case_manifest.py -- writes case_manifest.json (beside the workbooks), the single source of
every number the Chapter 6 text will print for Case IV (rail-transit
station accessibility with stakeholder equity) and for Case III (building
digital twin maturity, generated and solved since 2026-09-14), plus the
roster of the new figures.  Everything is READ FROM THE WORKBOOKS, never typed by hand, so the
manifest cannot drift from the pack.

Run after build_workbooks.py:  python gen_case_manifest.py
"""
import json
import os
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = HERE                                     # simulation_data/
OUTP = os.path.join(HERE, "case_manifest.json")  # written beside the workbooks


def load(name):
    return pd.read_excel(os.path.join(DATA, name), sheet_name=None)


def cfgd(sheets):
    c = sheets["config"]
    return dict(zip(c["key"].astype(str), c["value"]))


def r2(x):
    return round(float(x), 2)


def r3(x):
    return round(float(x), 3)


# ===================================================================== Case IV
rt = load("fig6-11_rt_case.xlsx")
rtc = cfgd(rt)
rr = rt["results"]
st = rt["stations"]
cons = rt["constituencies"]
swapped = [t.strip() for t in str(rtc["swapped"]).split(",")]

case_v = {
    "case": "IV",
    "title": "Urban rail-transit station accessibility with stakeholder equity",
    "source_paper": "chen2024railtransit",
    "honesty": ("Synthetic instrument and panel under seed 202603. Mirrors the "
                "source study at the level of MECHANISM only -- equity "
                "weighting reorders priorities -- and must NOT be presented "
                "as reproducing any substantive finding of the source paper."),
    "seed": int(rtc["seed"]),
    "instrument": {
        "n_stations": 10,
        "scale": "continuous accessibility index on [0, 10], Gaussian fits",
        "stations": [{"id": str(r["id"]), "name": str(r["name"]),
                      "generator_means": {"operators": r2(r["ops"]),
                                          "passengers": r2(r["pas"]),
                                          "advocates": r2(r["adv"])}}
                     for _, r in st.iterrows()],
        "contested_station": swapped[0],
    },
    "panel": {
        "N": int(rtc["n_stakeholders"]),
        "constituencies": [{"constituency": str(r["constituency"]),
                            "size": int(r["size"])} for _, r in cons.iterrows()],
        "generator": {
            "leniency_sd": r2(rtc["leniency_sd"]),
            "noise_sd": r2(rtc["noise_sd"]),
            "common_reported_sd": float(rtc["common_sigma"]),
            "draw_order": str(rtc["generator_draw_order"]),
            "clip": str(rtc["generator_clip"]),
            "clip_binding": bool(int(rtc["generator_clip_binding"])),
            "note": ("all stakeholders share a common reported assessment "
                     "precision, so the confidence objective is constant over "
                     "the simplex and non-discriminating; it is DROPPED from "
                     "both regimes, each of which is a single-objective program"),
        },
    },
    "model": {
        "regime_efficiency": str(rtc["regime_eff"]),
        "regime_equity": str(rtc["regime_eq"]),
        "overlap": str(rtc["overlap"]),
        "fairness_utilities": ("Fehr-Schmidt utilities of the overlaps "
                               "(rho %.1f, vartheta %.1f), parabolic "
                               "normalization (kappa %d)") % (float(rtc["rho"]), float(rtc["theta"]), int(rtc["kappa"])),
        "solver": str(rtc["solver"]),
        "solver_starts": str(rtc["solver_starts"]),
        "solver_ftol": float(rtc["solver_ftol"]),
        "certification": str(rtc["certification"]),
        "weight_reporting": ("BOTH regimes report the nearest-to-uniform "
                             "weight vector of their own optimal level set "
                             "(the projection of the uniform vector onto the "
                             "set, a convex QP cross-checked against its KKT "
                             "form), the influence-dispersion principle applied "
                             "as one shared tie-break, so the weight-Gini and "
                             "constituency-share columns are comparable across "
                             "the regimes and any residual concentration is "
                             "forced by the level set, that is, by the "
                             "objective"),
        "priority_rule": "upgrading priority = ascending collective accessibility (worst station first)",
    },
    "results": {
        "stations": [{"id": str(r["station"]), "name": str(r["name"]),
                      "mean_efficiency": r2(r["mean_eff"]),
                      "mean_equity": r2(r["mean_eq"]),
                      "priority_efficiency": int(r["priority_eff"]),
                      "priority_equity": int(r["priority_eq"]),
                      "weight_gini_efficiency": r2(r["weight_gini_eff"]),
                      "weight_gini_equity": r2(r["weight_gini_eq"]),
                      "advocate_share_efficiency": r2(r["adv_share_eff"]),
                      "advocate_share_equity": r2(r["adv_share_eq"]),
                      "mean_utility_efficiency": r3(r["Ubar_eff"]),
                      "mean_utility_equity": r3(r["Ubar_eq"]),
                      "utility_gini_efficiency": r3(r["gini_U_eff"]),
                      "utility_gini_equity": r3(r["gini_U_eq"])}
                     for _, r in rr.iterrows()],
        "priority_order_efficiency": [str(r["station"]) for _, r in
                                      rr.sort_values("priority_eff").iterrows()],
        "priority_order_equity": [str(r["station"]) for _, r in
                                  rr.sort_values("priority_eq").iterrows()],
        "max_uncontested_mean_gap": r2(rtc["max_uncontested_mean_gap"]),
        "max_uncontested_mean_gap_station": str(rtc["max_uncontested_mean_gap_station"]),
        "uncontested_gaps_below_threshold": str(rtc["uncontested_gaps_below_threshold"]),
        "swap": {
            "stations": swapped,
            "statement": ("under the equity-aware regime %s moves ahead of %s "
                          "in upgrading priority; every other pairwise order "
                          "is unchanged") % (swapped[0], swapped[1]),
            "contested_means": {
                swapped[0]: {"efficiency": r2(rr.set_index("station").loc[swapped[0], "mean_eff"]),
                             "equity": r2(rr.set_index("station").loc[swapped[0], "mean_eq"])},
                swapped[1]: {"efficiency": r2(rr.set_index("station").loc[swapped[1], "mean_eff"]),
                             "equity": r2(rr.set_index("station").loc[swapped[1], "mean_eq"])},
            },
            "advocate_share_at_contested": {
                "efficiency": r2(rr.set_index("station").loc[swapped[0], "adv_share_eff"]),
                "equity": r2(rr.set_index("station").loc[swapped[0], "adv_share_eq"]),
            },
        },
        "weight_gini": {
            "average_efficiency": r2(rtc["weight_gini_eff_avg"]),
            "average_equity": r2(rtc["weight_gini_eq_avg"]),
            "statement": ("averaged over the ten stations, and with both "
                          "regimes reporting the nearest-to-uniform "
                          "representative of their optimal level sets, the "
                          "weight Gini stands at %.2f under the "
                          "efficiency-only regime and %.2f under the "
                          "equity-aware regime")
                         % (float(rtc["weight_gini_eff_avg"]),
                            float(rtc["weight_gini_eq_avg"])),
        },
    },
    "robustness": {
        "reseed": str(rtc["robustness_reseed"]),
        "reseed_swap_direction_preserved": str(rtc["robustness_reseed_swap_direction"]),
        "reseed_other_orders_unchanged": str(rtc["robustness_reseed_other_orders_unchanged"]),
        "reseed_reordered_pairs": sorted(set(str(x) for x in rt["robustness_seeds"]["stations_reordered"])),
        "reseed_contested_moves_two_places": str(rtc["robustness_reseed_contested_moves_two_places"]),
        "fehr_schmidt_grid": str(rtc["robustness_fs_grid"]),
        "fehr_schmidt_swap_direction_preserved": str(rtc["robustness_fs_swap_direction"]),
        "fehr_schmidt_S4_advocate_share_range": str(rtc["robustness_fs_S4_adv_share_range"]),
        "leveling_down": {
            "mean_utility_rises_at": [str(r["station"]) for _, r in rr.iterrows() if float(r["Ubar_eq"]) > float(r["Ubar_eff"])],
            "mean_utility_falls_at": {str(r["station"]): round(float(r["Ubar_eq"]) - float(r["Ubar_eff"]), 5)
                                      for _, r in rr.iterrows() if float(r["Ubar_eq"]) <= float(r["Ubar_eff"])},
            "max_abs_change_uncontested": round(max(abs(float(r["Ubar_eq"]) - float(r["Ubar_eff"]))
                                                    for _, r in rr.iterrows() if str(r["station"]) not in swapped), 5),
            "contested_mean_utility": {"efficiency": r3(rr.set_index("station").loc[swapped[0], "Ubar_eff"]),
                                       "equity": r3(rr.set_index("station").loc[swapped[0], "Ubar_eq"])},
            "contested_utility_gini": {"efficiency": r3(rr.set_index("station").loc[swapped[0], "gini_U_eff"]),
                                       "equity": r3(rr.set_index("station").loc[swapped[0], "gini_U_eq"])},
        },
    },
}

# =================================================================== Case III
bdt = load("fig6-8_bdt_case.xlsx")
bdtc = cfgd(bdt)
bgrp = bdt["groups"]
bdim = bdt["dimensions"]
bsen = bdt["sensitivity"]
bkt = bdt["kmeans_topsis"]
case_iii = {
    "case": "III",
    "title": "Building digital twin maturity via FA-LSCOG",
    "source_paper": "chen2024bdt",
    "honesty": ("Synthetic 15-expert x 22-indicator truncated-Weibull panel under "
                "seed 202603, generated and solved in build_workbooks.py. Mirrors "
                "the source study at the level of MECHANISM only and must NOT be "
                "presented as reproducing any elicited value."),
    "seed": int(bdtc["seed"]),
    "program": str(bdtc["program"]),
    "parameters": {"rho": float(bdtc["rho"]), "vartheta": float(bdtc["vartheta"]),
                   "power_kappa": float(bdtc["power_kappa"]), "lambda_G": float(bdtc["lambda_G"]),
                   "operating_delta": float(bdtc["operating_delta"]),
                   "solver": str(bdtc["solver"]), "starts": str(bdtc["starts"]),
                   "normalization": str(bdtc["normalization"])},
    "groups": [{"group": str(r["group"]), "stratum": str(r["stratum"]), "size": int(r["size"]),
                "Omega": r2(r["Omega"]), "Omega_3dp": r3(r["Omega"]),
                "q1_mean": r2(r["q1_mu"])} for _, r in bgrp.iterrows()],
    "q1_collective_mean": r2(sum(float(r["Omega"]) * float(r["q1_mu"]) for _, r in bgrp.iterrows())),
    "topsis_closeness": [r3(v) for v in bkt["closeness"]],
    "dimensions": [{"id": str(r["id"]), "dimension": str(r["dimension"]),
                    "weight": r2(r["weight"]), "weight_3dp": r3(r["weight"]),
                    "mean": r2(r["mu"]), "level": str(r["level"]),
                    "bwm_best_to_others": int(r["bwm_best_to_others"]),
                    "bwm_others_to_worst": int(r["bwm_others_to_worst"])}
                   for _, r in bdim.iterrows()],
    "bwm": {"best": str(bdtc["bwm_best"]), "worst": str(bdtc["bwm_worst"]),
            "xi": r3(bdtc["bwm_xi"]), "consistency_ratio": r3(bdtc["bwm_consistency_ratio"])},
    "global": {"maturity": r2(bdtc["global_maturity"]), "level": str(bdtc["global_level"]),
               "aggregate_variance": r3(bdtc["aggregate_variance"]),
               "fairness_Phi": r3(bdtc["fairness_Phi"]), "weight_gini": r2(bdtc["weight_gini"]),
               "mass_below_2": r3(bdtc["mass_below_2"])},
    "sweep": [{"delta": r2(r["delta"]), "global_maturity": r2(r["global_maturity"]),
               "fairness_Phi": r3(r["fairness_Phi"]), "aggregate_variance": r3(r["aggregate_variance"]),
               "weight_gini": r2(r["weight_gini"]), "mass_below_2": r3(r["mass_below_2"])}
              for _, r in bsen.iterrows()],
}

# ============================================================ hm-panel anchor
loo = load("fig5-3_loo.xlsx")
res = dict(zip(loo["results"]["quantity"].astype(str), loo["results"]["printed"]))
hm_anchor = {
    "purpose": ("cross-check only -- these numbers are ALREADY printed in "
                "Chapter 5 (Table tab:hmpanel) and are now backed by the "
                "generated panel of fig5-3_loo.xlsx"),
    "human_only_mean_crps": float(res["human-only mean CRPS"]),
    "collaborative_mean_crps": float(res["collaborative mean CRPS"]),
    "human_weight_share": float(res["human weight share W_H"]),
    "machine_weight_share": float(res["machine weight share W_M"]),
    "overconfident_machines_cell": "(-, +) -- beneficial resolution, miscalibrated (M4, M5)",
}

# ==================================================================== figures
figures = [
    {"file": "fig4-1_pipeline.pdf", "chapter": 4, "kind": "tikz",
     "suggested_label": "fig:pipeline", "promised": True,
     "caption": ("The end-to-end solver and data-processing pipeline of the "
                 "framework, from elicited summaries through fitting, "
                 "objective assembly, the nonconvex and convex solution "
                 "paths, diagnostics, and the reported aggregate with its "
                 "record.")},
    {"file": "fig4-3_scalability.pdf", "chapter": 4, "kind": "python+workbook",
     "suggested_label": "fig:scalability", "promised": True,
     "caption": ("Pairwise interaction counts of the flat single-stage "
                 "program versus the hierarchical two-stage program with "
                 "K* proportional to N to the two-thirds, on log-log axes, "
                 "computed from the stated formulas.")},
    {"file": "fig5-1_workflow.pdf", "chapter": 5, "kind": "tikz",
     "suggested_label": "fig:workflow", "promised": True,
     "caption": ("The human-machine collaborative aggregation workflow, "
                 "from the elicitation of virtual experts with their "
                 "provenance records through the pooled panel, the convex "
                 "CRPS solve, the leave-one-out diagnosis, and the "
                 "governance dispositions.")},
    {"file": "fig5-3_loo.pdf", "chapter": 5, "kind": "python+workbook",
     "suggested_label": "fig:loo", "promised": True,
     "caption": ("The leave-one-out contribution of each expert of the "
                 "synthetic panel of Example ex:hmpanel, split into its "
                 "calibration and resolution channels, in which the two "
                 "overconfident machines occupy the beneficial-resolution-"
                 "but-miscalibrated cell.")},
    {"file": "fig5-4_depnet.pdf", "chapter": 5, "kind": "python+workbook",
     "suggested_label": "fig:depnet", "promised": True,
     "caption": ("The expert-dependence network of Example ex:corr-lineage. "
                 "edge opacity is proportional to the pairwise error "
                 "correlation, and the five fine-tuned variants of one base "
                 "model form a dense block counting as about 1.1 voices.")},
    {"file": "fig5-5_govtree.pdf", "chapter": 5, "kind": "tikz",
     "suggested_label": "fig:govtree", "promised": True,
     "caption": ("The governance decision tree for machine judgments, from "
                 "admission with a complete provenance record through the "
                 "leave-one-out sign patterns of Table 5.2 to the "
                 "correlated-block cap and the human-weight floor.")},
    {"file": "fig6-11_rt_equity.pdf", "chapter": 6, "kind": "python+workbook",
     "suggested_label": "fig:rt-equity", "promised": False,
     "caption": ("Case IV, the collective accessibility of the ten stations "
                 "under the efficiency-only and the equity-aware regimes, where "
                 "the contested interchange and its neighbour swap places "
                 "in the upgrading priority.")},
]

manifest = {
    "_generated_by": "figure_code/simulation_data/gen_case_manifest.py -- do not edit by hand; regenerate after build_workbooks.py",
    "_seed": 202603,
    "_calibration_honesty_rule": (
        "The case is an ILLUSTRATIVE SYNTHETIC construction. It mirrors "
        "its source paper at the level of MECHANISM only (equity weighting "
        "reorders priorities). No number below is a finding of "
        "chen2024railtransit, and the prose must not attribute any of them "
        "to that study."),
    "case_iii": case_iii,
    "case_v": case_v,
    "hm_panel_anchor": hm_anchor,
    "figures": figures,
}

with open(OUTP, "w", encoding="utf-8", newline="\n") as f:
    json.dump(manifest, f, indent=2, ensure_ascii=False)
print("wrote", OUTP)
