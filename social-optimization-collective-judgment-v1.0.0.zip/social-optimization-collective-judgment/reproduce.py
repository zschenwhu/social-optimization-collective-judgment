#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""reproduce.py -- one command to regenerate and verify everything.

    python reproduce.py            # rebuild every workbook and figure, then verify
"""
import os, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
env = dict(os.environ, MPLBACKEND="Agg", PYTHONIOENCODING="utf-8")
r = subprocess.run([sys.executable, "run_all.py"], cwd=os.path.join(HERE, "drawing_code"), env=env)
if r.returncode != 0:
    sys.exit("run_all.py failed")
sys.exit(subprocess.run([sys.executable, "verify_figures.py"] + sys.argv[1:], cwd=HERE, env=env).returncode)
