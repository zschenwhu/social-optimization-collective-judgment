# Changelog

## v1.0.0 (2026-09-15)

First public release, matching the manuscript delivered to Elsevier.
